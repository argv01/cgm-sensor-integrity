#!/usr/bin/env python3
"""
load_nightscout_gz.py
======================
Loader for Nightscout CGM data exports (entries_*.json.gz format).
Used by the OpenAPS Data Commons and other Nightscout-based exports.

Entry record fields used:
  date    int   epoch milliseconds — wall-clock timestamp
  sgv     int   glucose mg/dL (sensor glucose value)
  type    str   filter to "sgv" only (skips calibrations, mbg, etc.)
  device  str   source device string (e.g. "AndroidAPS-DexcomG5")

Treatment record fields used:
  date      int    epoch milliseconds
  insulin   float  units delivered
  isSMB     bool   True = AID loop micro-bolus
  eventType str    "Correction Bolus", "Meal Bolus", "SMB", etc.

No transmitter serial is available in Nightscout format. Session boundaries
are inferred from time gaps (same heuristic as AndroidAPS loader).

Usage:
  python load_nightscout_gz.py <entries.json.gz> [output.csv] [donor_id]

  Optionally also loads treatments from same directory if
  treatments_*.json.gz is present alongside the entries file.
"""

import gzip, json, sys
from pathlib import Path
import pandas as pd


def load_nightscout_entries(path: str, donor_id: str = "donor") -> pd.DataFrame:
    """
    Load entries_*.json.gz.
    Returns DataFrame with columns: dt, glucose, transmitter_id
    """
    with gzip.open(path) as f:
        raw = json.load(f)

    rows, seen = [], set()
    for e in raw:
        if e.get("type") != "sgv":
            continue
        epoch_ms = e.get("date")
        glucose  = e.get("sgv")
        if epoch_ms is None or glucose is None:
            continue
        if epoch_ms in seen:
            continue
        seen.add(epoch_ms)
        try:
            g = float(glucose)
        except (TypeError, ValueError):
            continue
        if g < 30 or g > 600:
            continue
        rows.append({
            "dt":             pd.Timestamp(int(epoch_ms), unit="ms"),
            "glucose":        g,
            "transmitter_id": donor_id,
            "device":         e.get("device", ""),
        })

    df = pd.DataFrame(rows).sort_values("dt").reset_index(drop=True)
    return df[["dt", "glucose", "transmitter_id"]]


def load_nightscout_treatments(path: str) -> pd.DataFrame:
    """
    Load treatments_*.json.gz.
    Returns DataFrame with columns: dt, insulin, is_smb, event_type
    Only includes entries with insulin > 0.
    """
    if not Path(path).exists():
        return pd.DataFrame(columns=["dt", "insulin", "is_smb", "event_type"])

    with gzip.open(path) as f:
        raw = json.load(f)

    rows = []
    for e in raw:
        insulin = float(e.get("insulin") or 0)
        if insulin <= 0:
            continue
        epoch_ms = e.get("date") or e.get("NSCLIENT_ID")
        if epoch_ms is None:
            continue
        try:
            rows.append({
                "dt":         pd.Timestamp(int(epoch_ms), unit="ms"),
                "insulin":    insulin,
                "is_smb":     bool(e.get("isSMB", False)),
                "event_type": e.get("eventType", ""),
            })
        except (TypeError, ValueError):
            continue

    df = pd.DataFrame(rows).sort_values("dt").reset_index(drop=True)
    return df


def export_clarity_csv(df: pd.DataFrame, out_path: str,
                       patient_name: str = "Nightscout Donor") -> None:
    """Export Clarity-compatible CSV for use with cgm_render_report_v6.py."""
    out = df.copy()
    out["Timestamp (YYYY-MM-DDThh:mm:ss)"] = out["dt"].dt.strftime("%Y-%m-%dT%H:%M:%S")
    out["Glucose Value (mg/dL)"] = out["glucose"].apply(
        lambda g: "Low" if g <= 40 else ("High" if g >= 400 else str(int(g)))
    )
    out["Event Type"]     = "EGV"
    out["Transmitter ID"] = out["transmitter_id"]
    out["Patient Info"]   = f"OpenAPS|{patient_name}"
    cols = ["Timestamp (YYYY-MM-DDThh:mm:ss)", "Glucose Value (mg/dL)",
            "Event Type", "Transmitter ID", "Patient Info"]
    out[cols].to_csv(out_path, index=False)
    print(f"  Wrote: {out_path}  ({len(out):,} rows)")


def summarize(bg_df: pd.DataFrame, tx_df: pd.DataFrame, source: str) -> None:
    if bg_df.empty:
        print("No valid readings found.")
        return
    print(f"\n=== Nightscout Summary: {Path(source).name} ===")
    print(f"  CGM readings : {len(bg_df):,}")
    print(f"  Date range   : {bg_df['dt'].min().date()} → {bg_df['dt'].max().date()}")
    print(f"  Glucose      : {bg_df['glucose'].min():.0f}–{bg_df['glucose'].max():.0f} mg/dL  "
          f"(mean {bg_df['glucose'].mean():.1f})")
    if not tx_df.empty:
        smb  = tx_df[tx_df["is_smb"]]
        manual = tx_df[~tx_df["is_smb"]]
        print(f"  Boluses      : {len(tx_df)} total  "
              f"({len(smb)} SMB  |  {len(manual)} manual)")
        print(f"  Total insulin: {tx_df['insulin'].sum():.1f} U")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    src       = sys.argv[1]
    donor_id  = (sys.argv[3] if len(sys.argv) >= 4
                 else Path(src).parent.parent.name or "donor")

    # Auto-find matching treatments file
    src_path  = Path(src)
    tx_candidates = list(src_path.parent.glob("treatments_*.json.gz"))
    tx_path   = str(tx_candidates[0]) if tx_candidates else src.replace("entries_", "treatments_")

    bg_df = load_nightscout_entries(src, donor_id=donor_id)
    tx_df = load_nightscout_treatments(tx_path)
    summarize(bg_df, tx_df, src)

    if len(sys.argv) >= 3:
        export_clarity_csv(bg_df, sys.argv[2], patient_name=donor_id)
