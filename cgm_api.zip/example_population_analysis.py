"""
Example population analysis using CGM Sensor Integrity API v6.

This script assumes:
- The main package (cgm_sensor_integrity_detector.py + cgm_cluster_detector_v5.py)
  is in a sibling directory called 'main/', or CSID_MAIN_DIR is set.
- Your population data is a CSV with at least: user_id, timestamp, glucose_mgdl

Edit INPUT_FILE and the metadata_cols list to match your data schema.
"""

from pathlib import Path

import pandas as pd
import cgm_sensor_integrity_api_v6 as api


INPUT_FILE = Path("population_cgm_export.csv")
OUTPUT_DIR = Path("csid_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def main() -> None:
    df = pd.read_csv(INPUT_FILE)

    all_clusters = []
    all_events   = []

    for user_id, user_df in df.groupby("user_id"):
        result = api.analyze_user_dataframe(
            user_df,
            timestamp_col="timestamp",
            glucose_col="glucose_mgdl",
            user_id_col="user_id",
            metadata_cols=["sensor_type", "sensor_id", "transmitter_id"],
        )
        if not result["clusters_df"].empty:
            all_clusters.append(result["clusters_df"])
        if not result["events_df"].empty:
            all_events.append(result["events_df"])

    clusters_df = pd.concat(all_clusters, ignore_index=True) if all_clusters else pd.DataFrame()
    events_df   = pd.concat(all_events,   ignore_index=True) if all_events   else pd.DataFrame()
    summary_df  = api.aggregate_cluster_metrics(clusters_df, events_df, group_cols=["sensor_type"])

    clusters_df.to_csv(OUTPUT_DIR / "clusters.csv",              index=False)
    events_df.to_csv(  OUTPUT_DIR / "events.csv",                index=False)
    summary_df.to_csv( OUTPUT_DIR / "summary_by_sensor_type.csv", index=False)

    print("Wrote:")
    print(f"  {OUTPUT_DIR / 'clusters.csv'}")
    print(f"  {OUTPUT_DIR / 'events.csv'}")
    print(f"  {OUTPUT_DIR / 'summary_by_sensor_type.csv'}")


if __name__ == "__main__":
    main()
