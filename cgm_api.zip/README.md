# CGM Sensor Integrity API

> **Requires `cgm_ai_assistant.zip`** — extract both zips into the same folder before running any scripts. The core detector files (`cgm_cluster_detector_v5.py`, `cgm_sensor_integrity_detector.py`, `cgm_render_report_v6.py`) must be on the Python path.


This folder is for developers who want to run the cluster detector
programmatically against large datasets — Nightscout archives, OpenAPS data
commons exports, Tidepool research datasets, or any other source where you
have CGM data in bulk.

If you're not writing code to process many users' data at once, you probably
don't need this folder. Use an AI assistant with the main package instead.

---

## Files

| File | Description |
|------|-------------|
| `cgm_sensor_integrity_api_v6.py` | pandas-friendly API wrapper |
| `example_population_analysis.py` | Minimal example: iterate over users, aggregate results |
| `README.md` | This file |

---

## A note on versioning

The API wraps `cgm_cluster_detector_v5.py` — v5 is the detection algorithm
version, which is independent of the renderer version (v6). The algorithm and
renderer are versioned separately. The detector in this package is current.

---

## What the API does

`cgm_sensor_integrity_api_v6.py` wraps the core detector in a pandas-friendly
interface. Instead of rendering PNGs, it returns DataFrames of clusters and hypo
events that you can aggregate, filter, and join against other data.

```python
import cgm_sensor_integrity_api_v6 as api

result = api.analyze_user_dataframe(
    df,
    timestamp_col="timestamp",
    glucose_col="glucose_mgdl",
    user_id_col="user_id",
    metadata_cols=["sensor_type", "transmitter_id"],
)

print(result["clusters_df"])   # one row per cluster
print(result["events_df"])     # one row per cluster-linked hypo event
print(result["summary"])       # aggregate counts
```

---

## Data sources

### Nightscout

The `load_nightscout_gz.py` loader in `main/` handles `entries_*.json.gz` from
Nightscout direct-sharing exports, including the OpenAPS Data Commons format.

```python
from load_nightscout_gz import load_nightscout_entries
bg_df = load_nightscout_entries("entries_2023.json.gz", donor_id="user_001")
```

### AndroidAPS / Open Humans

The `load_androidaps_json.py` loader in `main/` handles `BgReadings.json` and
`Treatments.json` from AndroidAPS Open Humans exports.

```python
from load_androidaps_json import load_androidaps_bgreadings
bg_df = load_androidaps_bgreadings("BgReadings.json", donor_id="user_001")
```

### Tidepool

Parse the `cbg` event type from Tidepool JSON exports. Tidepool device metadata
maps cleanly to the `metadata_cols` parameter.

### Loop, iAPS, OpenAPS

All log through Nightscout. Use the Nightscout loader.

### Smartphone apps (Gluroo, Sugarmate, Spike, xDrip+)

Most can export CSV or sync to Nightscout. If your app exports a CSV with
timestamp and glucose columns, pass those column names directly to
`analyze_user_dataframe()`.

---

## Population analysis

```python
import pandas as pd
import cgm_sensor_integrity_api_v6 as api

df = pd.read_csv("population_data.csv")  # columns: user_id, timestamp, glucose_mgdl, sensor_type

all_clusters, all_events = [], []
for user_id, user_df in df.groupby("user_id"):
    result = api.analyze_user_dataframe(user_df, metadata_cols=["sensor_type"])
    if not result["clusters_df"].empty:
        all_clusters.append(result["clusters_df"])
    if not result["events_df"].empty:
        all_events.append(result["events_df"])

clusters_df = pd.concat(all_clusters, ignore_index=True)
events_df   = pd.concat(all_events,   ignore_index=True)

summary = api.aggregate_cluster_metrics(
    clusters_df, events_df, group_cols=["sensor_type"]
)
print(summary)
```

See `example_population_analysis.py` for a complete working example.

---

## Locating the main package

The API needs `cgm_cluster_detector_v5.py` from `main/` to be importable.
By default it searches sibling directories. You can be explicit:

```python
api.ensure_main_package_importable(main_package_dir="/path/to/main/")
```

Or set the environment variable `CSID_MAIN_DIR`.
