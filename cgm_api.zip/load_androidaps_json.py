"""
load_androidaps_json.py
=======================
Loader for AndroidAPS Open Humans export data (JSON format).

Each donor folder contains:
  BgReadings.json    — CGM glucose readings  (this loader's primary input)
  Treatments.json    — Boluses (SMB + meal)  (optional, for bolus overlay)

BgReadings entry fields used:
  date      int   epoch milliseconds — wall-clock timestamp
  value     int   glucose mg/dL
  isValid   bool  filter invalid readings
  direction str   trend arrow (SingleUp, Flat, etc.) — not used currently

Treatments entry fields used:
  date      int   epoch milliseconds
  insulin   float units delivered (0 if carb-only entry)
  isSMB     bool  True = AID loop micro-bolus, False = user meal bolus
  mealBolus bool  True = user-initiated meal bolus
  isDeletion bool  skip deleted entries

No transmitter serial is available in this format. Session boundaries are
inferred from time gaps (168h minimum session floor, same as Libre/G7).
The donor_id is used as the transmitter_id proxy.

Usage:
  python load_androidaps_json.py BgReadings.json [output_clarity.csv] [donor_id]
"""

import json, sys
from pathlib import Path
import pandas as pd


def load_androidaps_bgreadings(bg_path: str,
                                donor_id: str = "donor") -> pd.DataFrame:
    """
    Load BgReadings.json.
    Returns DataFrame with columns: dt, glucose, transmitter_id
    """
    with open(bg_path) as f:
        raw = json.load(f)

    rows = []
    seen_dates = set()
    for entry in raw:
        if not entry.get("isValid", True):
            continue
        epoch_ms = entry.get("date")
        glucose  = entry.get("value")
        if epoch_ms is None or glucose is None:
            continue
        if epoch_ms in seen_dates:          # deduplicate by timestamp
            continue
        seen_dates.add(epoch_ms)
        try:
            g = float(glucose)
        except (TypeError, ValueError):
            continue
        if g < 30 or g > 600:
            continue
        rows.append({
            "dt":             pd.Timestamp(int(epoch_ms), unit="ms"),
            "glucose":        g,
            "transmitter_id": donor_id,
            "direction":      entry.get("direction", ""),
        })

    df = pd.DataFrame(rows).sort_values("dt").reset_index(drop=True)
    return df[["dt", "glucose", "transmitter_id"]]


def load_androidaps_treatments(tx_path: str) -> pd.DataFrame:
    """
    Load Treatments.json.
    Returns DataFrame with columns: dt, insulin, is_smb, is_meal
    Only includes entries with insulin > 0 and isDeletion == False.
    """
    if not Path(tx_path).exists():
        return pd.DataFrame(columns=["dt", "insulin", "is_smb", "is_meal"])

    with open(tx_path) as f:
        raw = json.load(f)

    rows = []
    for entry in raw:
        if entry.get("isDeletion", False):
            continue
        insulin = float(entry.get("insulin", 0) or 0)
        if insulin <= 0:
            continue
        epoch_ms = entry.get("date")
        if epoch_ms is None:
            continue
        rows.append({
            "dt":      pd.Timestamp(int(epoch_ms), unit="ms"),
            "insulin": insulin,
            "is_smb":  bool(entry.get("isSMB", False)),
            "is_meal": bool(entry.get("mealBolus", False)),
        })

    df = pd.DataFrame(rows).sort_values("dt").reset_index(drop=True)
    return df


def summarize(bg_df: pd.DataFrame, tx_df: pd.DataFrame,
              source_path: str) -> None:
    if bg_df.empty:
        print("No valid readings found.")
        return
    print(f"\n=== AndroidAPS Summary: {Path(source_path).parent.name} ===")
    print(f"  CGM readings : {len(bg_df):,}")
    print(f"  Date range   : {bg_df['dt'].min().date()} → {bg_df['dt'].max().date()}")
    print(f"  Glucose      : {bg_df['glucose'].min():.0f}–{bg_df['glucose'].max():.0f} mg/dL  "
          f"(mean {bg_df['glucose'].mean():.1f})")
    if not tx_df.empty:
        smb  = tx_df[tx_df["is_smb"]]
        meal = tx_df[tx_df["is_meal"]]
        manual = tx_df[~tx_df["is_smb"] & ~tx_df["is_meal"]]
        print(f"  Boluses      : {len(tx_df)} total  —  "
              f"{len(smb)} SMB micro  |  {len(meal)} meal  |  {len(manual)} other manual")
        print(f"  Total insulin: {tx_df['insulin'].sum():.1f} U  "
              f"(SMB: {smb['insulin'].sum():.1f} U  meal: {meal['insulin'].sum():.1f} U)")


def export_clarity_csv(df: pd.DataFrame, out_path: str,
                        patient_name: str = "OpenAPS Donor") -> None:
    """Clarity-compatible CSV for load_clarity_csv() in cgm_render_report_v6.py"""
    out = df.copy()
    out["Timestamp (YYYY-MM-DDThh:mm:ss)"] = out["dt"].dt.strftime("%Y-%m-%dT%H:%M:%S")
    out["Glucose Value (mg/dL)"] = out["glucose"].apply(
        lambda g: "Low" if g <= 40 else ("High" if g >= 400 else str(int(g)))
    )
    out["Event Type"]     = "EGV"
    out["Transmitter ID"] = out["transmitter_id"]
    out["Patient Info"]   = patient_name
    cols = ["Timestamp (YYYY-MM-DDThh:mm:ss)", "Glucose Value (mg/dL)",
            "Event Type", "Transmitter ID", "Patient Info"]
    out[cols].to_csv(out_path, index=False)
    print(f"  Wrote Clarity CSV: {out_path}  ({len(out):,} rows)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python load_androidaps_json.py <BgReadings.json> "
              "[output.csv] [donor_id]")
        sys.exit(1)
    src      = sys.argv[1]
    donor_id = (sys.argv[3] if len(sys.argv) >= 4
                else Path(src).parent.name or "donor")
    tx_path  = str(Path(src).parent / "Treatments.json")

    bg_df = load_androidaps_bgreadings(src, donor_id=donor_id)
    tx_df = load_androidaps_treatments(tx_path)
    summarize(bg_df, tx_df, src)

    if len(sys.argv) >= 3:
        export_clarity_csv(bg_df, sys.argv[2], patient_name=donor_id)
