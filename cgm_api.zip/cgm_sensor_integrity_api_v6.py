# © 2025-2026 Dan Heller. MIT License. https://github.com/argv01/cgm-sensor-integrity
"""
CGM Sensor Integrity API v6

Developer add-on for the CGM Sensor Integrity Detector v6.
This module does not contain the detector logic itself. Instead, it locates the
main package and provides a small, pandas-friendly integration layer for
population analysis.

Public API
----------
    ensure_main_package_importable(main_package_dir=None)
        Locate and import the main detector package.

    normalize_cgm_dataframe(df, timestamp_col, glucose_col)
        Clean a CGM DataFrame into canonical columns: timestamp, glucose_mgdl.

    analyze_user_dataframe(df, ...)
        Run cluster detection and hypo event linking for one user.
        Returns dict with keys: clusters_df, events_df, summary.

    aggregate_cluster_metrics(clusters_df, events_df, group_cols)
        Aggregate results by one or more grouping columns (e.g. sensor_type).
"""

from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd


def _candidate_main_dirs(explicit_dir: Optional[str] = None) -> List[Path]:
    """Return ordered list of directories to search for the main detector package."""
    here = Path(__file__).resolve().parent
    candidates: List[Path] = []

    def add(p: Optional[Path]) -> None:
        if p is None:
            return
        try:
            rp = p.resolve()
        except Exception:
            return
        if rp not in candidates:
            candidates.append(rp)

    if explicit_dir:
        add(Path(explicit_dir))

    env_dir = os.environ.get("CSID_MAIN_DIR")
    if env_dir:
        add(Path(env_dir))

    add(here)
    add(here.parent / "main")
    add(here.parent / "cgm_sensor_integrity_detector_v6")
    add(here.parent / "cgm_sensor_integrity_detector")

    return candidates


def ensure_main_package_importable(main_package_dir: Optional[str] = None):
    """
    Locate the main CGM Sensor Integrity Detector package and return it as an
    imported module.

    Parameters
    ----------
    main_package_dir :
        Optional explicit path to the extracted main package directory.
        If omitted, searches relative paths and the CSID_MAIN_DIR environment variable.
    """
    module_name = "cgm_sensor_integrity_detector"

    try:
        return importlib.import_module(module_name)
    except Exception:
        pass

    for candidate in _candidate_main_dirs(main_package_dir):
        wrapper = candidate / "cgm_sensor_integrity_detector.py"
        core    = candidate / "cgm_cluster_detector_v5.py"
        if wrapper.exists() and core.exists():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            return importlib.import_module(module_name)

    searched = "\n  - ".join(str(p) for p in _candidate_main_dirs(main_package_dir))
    raise ImportError(
        "Could not locate the main CGM Sensor Integrity Detector v6 package. "
        "Expected cgm_sensor_integrity_detector.py and cgm_cluster_detector_v5.py in one of:\n"
        f"  - {searched}\n"
        "Pass main_package_dir=... explicitly or set CSID_MAIN_DIR."
    )


def normalize_cgm_dataframe(
    df: pd.DataFrame,
    timestamp_col: str,
    glucose_col: str,
) -> pd.DataFrame:
    """
    Return a cleaned CGM DataFrame with canonical columns: timestamp, glucose_mgdl.

    Rows with invalid timestamps or glucose values are dropped.
    Exact duplicate (timestamp, glucose_mgdl) pairs are removed.
    """
    if timestamp_col not in df.columns:
        raise KeyError(f"Missing timestamp column: {timestamp_col}")
    if glucose_col not in df.columns:
        raise KeyError(f"Missing glucose column: {glucose_col}")

    out = df.copy()
    out["timestamp"]    = pd.to_datetime(out[timestamp_col], errors="coerce")
    out["glucose_mgdl"] = pd.to_numeric(out[glucose_col],   errors="coerce")
    out = out.dropna(subset=["timestamp", "glucose_mgdl"]).copy()
    out = out.sort_values("timestamp").drop_duplicates(subset=["timestamp", "glucose_mgdl"])
    return out.reset_index(drop=True)


def _is_nocturnal(ts: pd.Timestamp, start_hour: int = 22, end_hour: int = 7) -> bool:
    """Return True if timestamp falls in the nocturnal window (default 22:00–07:00)."""
    hour = pd.Timestamp(ts).hour
    if start_hour > end_hour:          # window wraps midnight
        return hour >= start_hour or hour < end_hour
    return start_hour <= hour < end_hour


def _metadata_values(day_df: pd.DataFrame, metadata_cols: Sequence[str]) -> Dict[str, Any]:
    """Extract first non-null value for each metadata column from a day slice."""
    meta: Dict[str, Any] = {}
    for col in metadata_cols:
        if col in day_df.columns and len(day_df[col].dropna()) > 0:
            meta[col] = day_df[col].iloc[0]
        else:
            meta[col] = None
    return meta


def analyze_user_dataframe(
    df: pd.DataFrame,
    timestamp_col: str = "timestamp",
    glucose_col: str = "glucose_mgdl",
    user_id_col: Optional[str] = "user_id",
    metadata_cols: Optional[Sequence[str]] = None,
    main_package_dir: Optional[str] = None,
    hypo_threshold: float = 70.0,
    event_window_hours: float = 3.0,
    min_confidence: str = "medium",
    nocturnal_start_hour: int = 22,
    nocturnal_end_hour: int = 7,
    **detector_kwargs,
) -> Dict[str, Any]:
    """
    Analyze one user's CGM DataFrame and return clusters and hypo events.

    Parameters
    ----------
    df : pd.DataFrame
        CGM data for a single user.
    timestamp_col, glucose_col :
        Source column names for timestamps and glucose readings.
    user_id_col :
        Optional column carrying a user identifier, propagated into outputs.
    metadata_cols :
        Optional columns to carry into output rows (e.g. sensor_type, transmitter_id).
    main_package_dir :
        Optional explicit path to the extracted main detector package.
    hypo_threshold :
        Glucose level (mg/dL) below which a reading is considered hypoglycaemic.
    event_window_hours :
        Hours after cluster end to search for a subsequent hypo nadir.
    min_confidence :
        Minimum cluster confidence level to include ('low', 'medium', 'high').
    nocturnal_start_hour, nocturnal_end_hour :
        Define the nocturnal window for event classification.
    **detector_kwargs :
        Additional keyword arguments forwarded to detect_clusters().

    Returns
    -------
    dict with keys:
        clusters_df : pd.DataFrame — one row per detected cluster
        events_df   : pd.DataFrame — one row per cluster-linked hypo event
        summary     : dict         — aggregate counts
    """
    metadata_cols = list(metadata_cols or [])
    main = ensure_main_package_importable(main_package_dir)

    clean = normalize_cgm_dataframe(df, timestamp_col=timestamp_col, glucose_col=glucose_col)
    if clean.empty:
        return {
            "clusters_df": pd.DataFrame(),
            "events_df":   pd.DataFrame(),
            "summary": {"n_days": 0, "n_clusters": 0, "n_events": 0, "n_nocturnal_events": 0},
        }

    user_id = None
    if user_id_col and user_id_col in clean.columns and len(clean[user_id_col].dropna()) > 0:
        user_id = clean[user_id_col].iloc[0]

    clusters_rows: List[Dict[str, Any]] = []
    events_rows:   List[Dict[str, Any]] = []

    for day in sorted(clean["timestamp"].dt.date.unique()):
        day_start    = pd.Timestamp(day)
        day_end      = day_start + pd.Timedelta(days=1)
        analysis_end = day_end + pd.Timedelta(hours=event_window_hours)

        day_df      = clean[(clean["timestamp"] >= day_start) & (clean["timestamp"] < day_end)].copy()
        extended_df = clean[(clean["timestamp"] >= day_start) & (clean["timestamp"] < analysis_end)].copy()

        if day_df.empty:
            continue

        meta     = _metadata_values(day_df, metadata_cols)
        clusters = main.detect_clusters(day_df["timestamp"], day_df["glucose_mgdl"], **detector_kwargs)

        cluster_id_map: Dict[Tuple, str] = {}
        for idx, c in enumerate(clusters, start=1):
            cid = f"{user_id if user_id is not None else 'user'}:{day}:{idx}"
            cluster_id_map[(pd.Timestamp(c["start"]), pd.Timestamp(c["end"]), str(c["confidence"]))] = cid
            row = {
                "cluster_id":   cid,
                "date":         str(day),
                "cluster_start": pd.Timestamp(c["start"]),
                "cluster_end":   pd.Timestamp(c["end"]),
                "confidence":    c["confidence"],
                "min_glucose":   float(c["min"]),
                "max_glucose":   float(c["max"]),
                "duration_min":  float(c["duration_min"]),
            }
            if user_id is not None:
                row["user_id"] = user_id
            row.update(meta)
            clusters_rows.append(row)

        events = main.find_hypo_events(
            extended_df["timestamp"],
            extended_df["glucose_mgdl"],
            hypo_threshold=hypo_threshold,
            window_hours=event_window_hours,
            min_confidence=min_confidence,
            **detector_kwargs,
        )

        for e in events:
            cluster      = e["cluster"]
            cluster_start = pd.Timestamp(cluster["start"])
            if cluster_start.date() != day:
                continue
            cluster_key = (cluster_start, pd.Timestamp(cluster["end"]), str(cluster["confidence"]))
            cid         = cluster_id_map.get(cluster_key)
            row = {
                "date":                      str(day),
                "cluster_id":                cid,
                "cluster_start":             cluster_start,
                "cluster_end":               pd.Timestamp(cluster["end"]),
                "confidence":                cluster["confidence"],
                "nadir_glucose":             float(e["nadir"]),
                "nadir_time":                pd.Timestamp(e["nadir_time"]),
                "time_to_nadir_hours":       float(e["time_to_nadir_hours"]),
                "n_readings_below_threshold": int(e["n_readings_below_threshold"]),
                "is_nocturnal":              bool(_is_nocturnal(
                    pd.Timestamp(e["nadir_time"]),
                    start_hour=nocturnal_start_hour,
                    end_hour=nocturnal_end_hour,
                )),
            }
            if user_id is not None:
                row["user_id"] = user_id
            row.update(meta)
            events_rows.append(row)

    clusters_df = pd.DataFrame(clusters_rows)
    events_df   = pd.DataFrame(events_rows)

    nocturnal_count = int(events_df["is_nocturnal"].sum()) \
        if not events_df.empty and "is_nocturnal" in events_df.columns else 0

    return {
        "clusters_df": clusters_df,
        "events_df":   events_df,
        "summary": {
            "n_days":              int(clean["timestamp"].dt.date.nunique()),
            "n_clusters":          len(clusters_df),
            "n_events":            len(events_df),
            "n_nocturnal_events":  nocturnal_count,
        },
    }


def aggregate_cluster_metrics(
    clusters_df: pd.DataFrame,
    events_df: pd.DataFrame,
    group_cols: Sequence[str] = ("sensor_type",),
) -> pd.DataFrame:
    """
    Aggregate cluster and event metrics by one or more grouping columns.

    Returns a DataFrame with columns:
        <group_cols>, sensor_days, clusters, medium_clusters,
        high_clusters, events, nocturnal_events
    """
    group_cols = list(group_cols)
    out_cols   = group_cols + [
        "sensor_days", "clusters", "medium_clusters", "high_clusters",
        "events", "nocturnal_events",
    ]

    if clusters_df.empty and events_df.empty:
        return pd.DataFrame(columns=out_cols)

    if not clusters_df.empty:
        cw = clusters_df.copy()
        cw["medium_flag"] = (cw["confidence"] == "medium").astype(int)
        cw["high_flag"]   = (cw["confidence"] == "high").astype(int)
        cluster_agg = cw.groupby(group_cols, dropna=False).agg(
            sensor_days      = ("date",        "nunique"),
            clusters         = ("cluster_id",  "nunique"),
            medium_clusters  = ("medium_flag", "sum"),
            high_clusters    = ("high_flag",   "sum"),
        ).reset_index()
    else:
        cluster_agg = pd.DataFrame(columns=group_cols + [
            "sensor_days", "clusters", "medium_clusters", "high_clusters"])

    if not events_df.empty:
        ew = events_df.copy()
        if "is_nocturnal" not in ew.columns:
            ew["is_nocturnal"] = False
        event_agg = ew.groupby(group_cols, dropna=False).agg(
            events            = ("cluster_id",   "count"),
            nocturnal_events  = ("is_nocturnal", "sum"),
        ).reset_index()
    else:
        event_agg = pd.DataFrame(columns=group_cols + ["events", "nocturnal_events"])

    out = cluster_agg.merge(event_agg, how="left", on=group_cols)
    for col in ("events", "nocturnal_events"):
        if col not in out.columns:
            out[col] = 0
        out[col] = out[col].fillna(0).astype(int)

    return out[out_cols]


__all__ = [
    "ensure_main_package_importable",
    "normalize_cgm_dataframe",
    "analyze_user_dataframe",
    "aggregate_cluster_metrics",
]
