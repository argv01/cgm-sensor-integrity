# CGM Sensor Integrity — Sample Scripts

> **Requires `cgm_ai_assistant.zip`** — extract both zips into the same folder before running any scripts. The core detector files (`cgm_cluster_detector_v5.py`, `cgm_sensor_integrity_detector.py`, `cgm_render_report_v6.py`) must be on the Python path.

## Requirements

Python 3.9+:

```
pip install -r requirements.txt
```

## Scripts

Each file is self-contained with comments explaining what it does. Edit the file paths at the top, then run:

```bash
python SampleScripts/daily_report.py
python SampleScripts/dashboard.py
python SampleScripts/detect_clusters.py
python SampleScripts/find_hypo_events.py
python SampleScripts/compare_g6_g7.py
```
