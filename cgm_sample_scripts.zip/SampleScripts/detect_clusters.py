"""
detect_clusters.py
------------------
Run the cluster detector against one day of CGM data and print results.
Shows confidence level, time window, amplitude, and duration for each cluster.

Edit INPUT_CSV and REPORT_DATE below, then run:
    python detect_clusters.py
"""

import pandas as pd
import cgm_sensor_integrity_detector as det
from cgm_render_report_v6 import load_clarity_csv

INPUT_CSV   = "../SampleCGM-Data/Clarity_Export_JaneDoe_2025-12-10.csv"
REPORT_DATE = "2025-12-05"

egv, units, *_ = load_clarity_csv(INPUT_CSV)

day = egv[egv["dt"].dt.date == pd.Timestamp(REPORT_DATE).date()]
if day.empty:
    print(f"No data found for {REPORT_DATE}")
else:
    clusters = det.detect_clusters(day["dt"], day["glucose"])
    print(f"{len(clusters)} clusters on {REPORT_DATE}:\n")
    for c in clusters:
        label = "CRITICAL" if c["confidence"] == "high" else "Elevated"
        print(f"  {label:>10}  {c['start'].strftime('%H:%M')}–{c['end'].strftime('%H:%M')}  "
              f"amp={c['max']-c['min']:.0f} mg/dL  dur={c['duration_min']:.0f} min")
