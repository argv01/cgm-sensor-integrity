"""
compare_g6_g7.py
----------------
Render a combined multi-sensor summary dashboard comparing G6 and G7
data from the same time period. Requires two Clarity CSV exports.

Edit the file paths below, then run:
    python compare_g6_g7.py
"""

import subprocess, sys

G7_CSV     = "../SampleCGM-Data/Clarity_Export_Heller_Daniel_2026-03-18.csv"
G6_CSV     = "../SampleCGM-Data/Clarity_Export_Heller_Dan_2026-03-18.csv"
OUTPUT_PNG = "comparison_dashboard.png"

result = subprocess.run(
    [sys.executable, "cgm_render_report_v6.py",
     "--clarity_csv", G7_CSV, G6_CSV,
     "--dashboard",
     "--out", OUTPUT_PNG],
    capture_output=True, text=True
)

if result.returncode == 0:
    for line in result.stdout.strip().splitlines():
        print(line)
else:
    print("Error:", result.stderr)
