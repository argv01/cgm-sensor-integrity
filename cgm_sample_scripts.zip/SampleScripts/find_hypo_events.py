"""
find_hypo_events.py
-------------------
Find all days where a cluster was followed by a hypoglycemic reading
within a 3-hour window. Prints cluster details and the subsequent nadir.

Edit INPUT_CSV below, then run:
    python find_hypo_events.py
"""

import pandas as pd
import cgm_sensor_integrity_detector as det
from cgm_render_report_v6 import load_clarity_csv

INPUT_CSV      = "../SampleCGM-Data/Clarity_Export_JaneDoe_2025-12-10.csv"
HYPO_THRESHOLD = 70    # mg/dL
WINDOW_HOURS   = 3.0   # how far after cluster end to look

egv, units, *_ = load_clarity_csv(INPUT_CSV)

print(f"Searching for clusters followed by glucose < {HYPO_THRESHOLD} mg/dL "
      f"within {WINDOW_HOURS}h...\n")

found = 0
for date in sorted(egv["dt"].dt.date.unique()):
    day = egv[egv["dt"].dt.date == date].copy()
    events = det.find_hypo_events(
        day["dt"], day["glucose"],
        hypo_threshold=HYPO_THRESHOLD,
        window_hours=WINDOW_HOURS,
        min_confidence="medium",
    )
    for e in events:
        c = e["cluster"]
        label = "CRITICAL" if c["confidence"] == "high" else "Elevated"
        print(f"  {date}  {label} cluster {c['start'].strftime('%H:%M')}–{c['end'].strftime('%H:%M')} "
              f"→ nadir {e['nadir']:.0f} mg/dL at {e['nadir_time'].strftime('%H:%M')} "
              f"({e['time_to_nadir_hours']:.1f}h later)")
        found += 1

print(f"\n{found} cluster-linked hypo event{'s' if found != 1 else ''} found.")
