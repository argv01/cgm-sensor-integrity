"""
dashboard.py
------------
Render a 90-day summary dashboard from a Dexcom Clarity CSV export.
Produces a PNG with per-day cluster bars, sensor health color strip,
and hypo summary.

Edit INPUT_CSV below, then run:
    python dashboard.py
"""

from cgm_render_report_v6 import (
    load_clarity_csv, _build_dashboard_data,
    _paginate_dashboard_data, _data_pages, render_dashboard,
)

INPUT_CSV  = "../SampleCGM-Data/Clarity_Export_JaneDoe_2025-12-10.csv"
OUTPUT_PNG = "dashboard.png"

egv, units, sensor_label, patient_name, bgm = load_clarity_csv(INPUT_CSV)

data  = _build_dashboard_data(egv, units,
                               sensor_type_label=sensor_label,
                               patient_name=patient_name)
pages = _data_pages(data)

for pg in pages:
    pdata    = _paginate_dashboard_data(data, pg)
    suffix   = f"_p{pg+1}" if len(pages) > 1 else ""
    out_path = OUTPUT_PNG.replace(".png", f"{suffix}.png")
    render_dashboard(pdata, out_path)
    print(f"Saved: {out_path}")
