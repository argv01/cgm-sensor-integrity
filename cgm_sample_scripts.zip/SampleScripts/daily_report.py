"""
daily_report.py
---------------
Render a daily report for a single date from a Dexcom Clarity CSV export.
Produces a PNG with the glucose scatter, cluster annotations, and hypo table.

Edit INPUT_CSV and REPORT_DATE below, then run:
    python daily_report.py
"""

from cgm_render_report_v6 import load_clarity_csv, _build_daily_data, render_daily_report

INPUT_CSV   = "../SampleCGM-Data/Clarity_Export_JaneDoe_2025-12-10.csv"
REPORT_DATE = "2025-12-05"
OUTPUT_PNG  = "daily_report.png"

egv, units, sensor_label, patient_name, bgm = load_clarity_csv(INPUT_CSV)

data = _build_daily_data(
    egv, units, REPORT_DATE,
    sensor_type_label=sensor_label,
    patient_name=patient_name,
    bgm_df=bgm,
)

render_daily_report(data, OUTPUT_PNG)
print(f"Saved: {OUTPUT_PNG}")
