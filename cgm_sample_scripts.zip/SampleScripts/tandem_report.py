"""
tandem_report.py
----------------
Render a dashboard and daily report from one or more Tandem Source
Daily Timeline CSV exports. Combines multiple months automatically.

Tandem Source exports one month at a time. To get 90 days of data,
export three consecutive months and pass all three files here.

How to export from Tandem Source:
  1. Go to source.tandemdiabetes.com and log in
  2. Select the Daily Timeline report
  3. Set your date range (max 30 days per export)
  4. Click "Export Data" to download a CSV

Edit the INPUT_FILES list and REPORT_DATE below, then run:
    python SampleScripts/tandem_report.py

Requires load_tconnect_csv.py from the same package (../load_tconnect_csv.py).
"""

import sys
from pathlib import Path
import pandas as pd

# Add parent directory to path so we can import the loaders and renderer
sys.path.insert(0, str(Path(__file__).parent.parent))

from load_tconnect_csv import load_tconnect_csv
import cgm_render_report_v6 as r

# ── Edit these ────────────────────────────────────────────────────────────────

INPUT_FILES = [
    "../SampleCGM-Data/tandem_jan.csv",   # replace with your actual filenames
    "../SampleCGM-Data/tandem_feb.csv",
    "../SampleCGM-Data/tandem_mar.csv",
]

REPORT_DATE  = "2026-02-12"   # date for daily report (YYYY-MM-DD)
DASHBOARD_OUT = "tandem_dashboard.png"
DAILY_OUT     = f"tandem_daily_{REPORT_DATE}.png"

# ── Load and merge ────────────────────────────────────────────────────────────

all_egv, all_bgm, all_bolus = [], [], []
patient_name  = ""
pump_algo     = ""

for path in INPUT_FILES:
    p = Path(path)
    if not p.exists():
        print(f"  Skipping (not found): {path}")
        continue
    egv, units, sensor_label, name, bgm, bolus = load_tconnect_csv(p)
    if not patient_name:
        patient_name = name
    if not pump_algo and "Control-IQ" in sensor_label:
        pump_algo = "Control-IQ"
    all_egv.append(egv)
    all_bgm.append(bgm)
    all_bolus.append(bolus)

if not all_egv:
    print("No data loaded. Check your INPUT_FILES paths.")
    sys.exit(1)

egv_combined   = pd.concat(all_egv).drop_duplicates(subset=["dt"]).sort_values("dt").reset_index(drop=True)
bgm_combined   = pd.concat(all_bgm).drop_duplicates(subset=["dt"]).sort_values("dt").reset_index(drop=True)
bolus_combined = pd.concat(all_bolus).drop_duplicates(subset=["dt","insulin"]).sort_values("dt").reset_index(drop=True)

# Required columns for the renderer
egv_combined["sensor_label"]   = "S1"
egv_combined["tx_id"]          = egv_combined.get("tx_id", "Unknown")
egv_combined["transmitter_id"] = egv_combined.get("transmitter_id", "Unknown")

display_name   = f"{patient_name}  \u2022  {pump_algo}" if pump_algo else patient_name
sensor_display = "Tandem t:slim X2"

print(f"Patient:    {patient_name}")
print(f"Date range: {egv_combined['dt'].min().date()} \u2192 {egv_combined['dt'].max().date()}")
print(f"EGV rows:   {len(egv_combined)}")
print(f"Boluses:    {len(bolus_combined)}")

# ── Dashboard ─────────────────────────────────────────────────────────────────

dash_data = r._build_dashboard_data(
    egv_combined, "mg/dL",
    sensor_type_label=sensor_display,
    patient_name=display_name,
)
for pg in r._data_pages(dash_data):
    pdata   = r._paginate_dashboard_data(dash_data, pg)
    pages   = r._data_pages(dash_data)
    suffix  = f"_p{pg+1}" if len(pages) > 1 else ""
    out     = DASHBOARD_OUT.replace(".png", f"{suffix}.png")
    r.render_dashboard(pdata, out)
    print(f"Saved: {out}")

# ── Daily report ──────────────────────────────────────────────────────────────

data = r._build_daily_data(
    egv_combined, "mg/dL", REPORT_DATE,
    sensor_type_label=sensor_display,
    patient_name=display_name,
    bgm_df=bgm_combined,
    bolus_df=bolus_combined,
)
if data:
    r.render_daily_report(data, DAILY_OUT)
    print(f"Saved: {DAILY_OUT}")
else:
    print(f"No data found for {REPORT_DATE}")
