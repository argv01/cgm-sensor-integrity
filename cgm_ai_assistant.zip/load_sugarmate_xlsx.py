# © 2025-2026 Dan Heller. MIT License. https://github.com/argv01/cgm-sensor-integrity
"""
load_sugarmate_xlsx.py
----------------------
Loader for Sugarmate Excel report exports.

File structure:
  - "Summary" sheet: date range and metadata
  - One sheet per day named e.g. "Mon Jan 12, 2026"
  - Each day sheet: row 15 = column headers, row 16+ = data
  - Columns: time, mg/dL, trend, activity, carbs (g), bolus (u),
             basal (u), exercise (mins), protein (g), photos

Usage (command line via the renderer):
    python cgm_render_report_v6.py --sugarmate report.xlsx --dashboard --out dashboard.png

Usage (Python API):
    from load_sugarmate_xlsx import load_sugarmate_xlsx
    egv, units, sensor_label, patient_name, bgm_df, bolus_df, carb_df = load_sugarmate_xlsx("report.xlsx")
    # egv has columns: dt, glucose
    # bolus_df has columns: dt, insulin, is_smb, bolus_type, event_type
    # carb_df has columns: dt, carbs
"""

from __future__ import annotations
from pathlib import Path
from typing import Tuple
import pandas as pd
import openpyxl


def load_sugarmate_xlsx(
    path: str | Path,
) -> Tuple[pd.DataFrame, str, str, str, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Load a Sugarmate Excel report export.

    Returns
    -------
    egv_df, units, sensor_label, patient_name, bgm_df, bolus_df, carb_df
    """
    path = Path(path)
    wb = openpyxl.load_workbook(path, data_only=True)

    source_device = "Sugarmate / Dexcom"
    if "Summary" in wb.sheetnames:
        ws_sum = wb["Summary"]
        for row in ws_sum.iter_rows(max_row=10, values_only=True):
            for cell in row:
                if isinstance(cell, str) and "CGM data by" in cell:
                    source_device = f"Sugarmate / {cell.split('by')[-1].strip()}"
                    break

    egv_rows   = []
    bolus_rows = []
    carb_rows  = []

    for sheet_name in wb.sheetnames:
        if sheet_name == "Summary":
            continue
        ws = wb[sheet_name]

        header_row = None
        for i, row in enumerate(ws.iter_rows(max_row=20, values_only=True), 1):
            if row[0] == "time" and row[1] == "mg/dL":
                header_row = i
                break
        if header_row is None:
            continue

        headers = list(next(
            ws.iter_rows(min_row=header_row, max_row=header_row, values_only=True)
        ))
        try:
            col_time    = headers.index("time")
            col_glucose = headers.index("mg/dL")
            col_bolus   = headers.index("bolus (u)") if "bolus (u)" in headers else None
            col_carbs   = headers.index("carbs (g)") if "carbs (g)" in headers else None
        except ValueError:
            continue

        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            dt  = row[col_time]
            glc = row[col_glucose]

            if dt is None or glc is None:
                continue
            try:
                glc = float(glc)
                dt  = pd.Timestamp(dt)
            except (TypeError, ValueError):
                continue

            egv_rows.append({"dt": dt, "glucose": glc})

            if col_bolus is not None:
                bv = row[col_bolus]
                if bv is not None:
                    try:
                        insulin = float(bv)
                        if insulin > 0:
                            bolus_rows.append({
                                "dt": dt, "insulin": insulin,
                                "is_smb": False,
                                "bolus_type": "Food/Correction",
                                "event_type": "Sugarmate-Bolus",
                            })
                    except (TypeError, ValueError):
                        pass

            if col_carbs is not None:
                cv = row[col_carbs]
                if cv is not None:
                    try:
                        carbs = float(cv)
                        if carbs > 0:
                            carb_rows.append({"dt": dt, "carbs": carbs})
                    except (TypeError, ValueError):
                        pass

    egv_df = (
        pd.DataFrame(egv_rows)
        .drop_duplicates(subset=["dt"])
        .sort_values("dt")
        .reset_index(drop=True)
    ) if egv_rows else pd.DataFrame(columns=["dt", "glucose"])

    bolus_df = (
        pd.DataFrame(bolus_rows).sort_values("dt").reset_index(drop=True)
    ) if bolus_rows else pd.DataFrame(
        columns=["dt", "insulin", "is_smb", "bolus_type", "event_type"])

    carb_df = (
        pd.DataFrame(carb_rows).sort_values("dt").reset_index(drop=True)
    ) if carb_rows else pd.DataFrame(columns=["dt", "carbs"])

    bgm_df = pd.DataFrame(columns=["dt", "glucose"])

    return egv_df, "mg/dL", source_device, "", bgm_df, bolus_df, carb_df
