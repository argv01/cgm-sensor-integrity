"""CGM Sensor Integrity Detector

An analytic for identifying locally unreliable CGM traces.
Thin public wrapper that re-exports the supported detector API.
"""

from cgm_cluster_detector_v5 import detect_clusters, find_hypo_events

__all__ = ["detect_clusters", "find_hypo_events"]
