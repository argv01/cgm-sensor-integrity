# © 2025-2026 Dan Heller. MIT License. https://github.com/argv01/cgm-sensor-integrity
"""
load_tconnect_csv.py
--------------------
Loader for Tandem Source (t:connect) Daily Timeline CSV exports.

The file has two distinct sections:
  1. EGV/BG rows — device glucose readings
     Columns: DeviceType, SerialNumber, Description, EventDateTime, Readings (mg/dL)
  2. Bolus rows — insulin delivery events (appended after all glucose rows)
     Columns: Type, BolusType, BolusDeliveryMethod, BG (mg/dL), SerialNumber,
              CompletionDateTime, InsulinDelivered, FoodDelivered, CorrectionDelivered,
              CompletionStatusDesc, BolexStartDateTime, BolexCompletionDateTime,
              BolexInsulinDelivered, BolexCompletionStatusDesc, StandardPercent,
              Duration (mins), CarbSize, TargetBG (mg/dL), CorrectionFactor, CarbRatio

BolusType mapping to renderer conventions:
  Auto              → is_smb=True   (Control-IQ automatic correction)
  Correction        → is_smb=False  (manual correction bolus)
  Food              → is_smb=False  (meal bolus)
  Food / Correction → is_smb=False  (combined meal + correction)
  Override          → is_smb=False  (user override of AID recommendation)

Usage (command line via the renderer):
    python cgm_render_report_v6.py --tconnect_csv export.csv --dashboard --out dashboard.png
    python cgm_render_report_v6.py --tconnect_csv jan.csv feb.csv mar.csv --dashboard --out dashboard.png

Usage (Python API):
    from load_tconnect_csv import load_tconnect_csv
    egv, units, sensor_label, patient_name, bgm_df, bolus_df = load_tconnect_csv("export.csv")
    # egv is a DataFrame with columns: dt, glucose
    # bolus_df has columns: dt, insulin, is_smb, bolus_type, event_type
"""

from __future__ import annotations
from pathlib import Path
from typing import Tuple, Optional
import pandas as pd


def load_tconnect_csv(
    path: str | Path,
) -> Tuple[pd.DataFrame, str, str, str, pd.DataFrame, pd.DataFrame]:
    """
    Load a Tandem Source Daily Timeline CSV export.

    Parameters
    ----------
    path : str or Path
        Path to the CSV file (filename begins with CSV_[PatientName]_...).

    Returns
    -------
    egv_df : pd.DataFrame
        Glucose readings with columns: dt (datetime), glucose (float)
    units : str
        Glucose units — always "mg/dL" for Tandem Source exports
    sensor_label : str
        Device label string for report headers
    patient_name : str
        Patient name extracted from the file header
    bgm_df : pd.DataFrame
        Manual BG fingerstick readings with columns: dt, glucose
    bolus_df : pd.DataFrame
        Insulin delivery events with columns:
        dt, insulin, is_smb, bolus_type, event_type
    """
    path = Path(path)
    with open(path, encoding="utf-8-sig") as f:
        raw = f.read()

    lines = raw.split("\n")

    # ── Extract metadata from file header ────────────────────────────────────
    patient_name  = ""
    pump_algo     = ""
    serial_number = ""

    for line in lines[:10]:
        if line.startswith("Patient Name,"):
            patient_name = line.split(",", 1)[1].strip()
        elif line.startswith("Pump Algorithm,"):
            pump_algo = line.split(",", 1)[1].strip()

    # ── Parse EGV / BG rows ───────────────────────────────────────────────────
    egv_rows = []
    bgm_rows = []

    for line in lines:
        if ",EGV," in line or ",BG," in line:
            parts = line.split(",")
            if len(parts) < 5:
                continue
            try:
                device_type = parts[0].strip()
                serial      = parts[1].strip()
                description = parts[2].strip()
                timestamp   = parts[3].strip()
                reading     = float(parts[4].strip())
                dt          = pd.Timestamp(timestamp)
                if serial_number == "":
                    serial_number = serial
                row = {"dt": dt, "glucose": reading}
                if description == "EGV":
                    egv_rows.append(row)
                elif description == "BG":
                    bgm_rows.append(row)
            except (ValueError, IndexError):
                continue

    # ── Parse bolus rows ──────────────────────────────────────────────────────
    bolus_rows = []
    in_bolus_section = False
    bolus_cols = []

    for line in lines:
        if line.startswith("Type,BolusType,"):
            in_bolus_section = True
            bolus_cols = [c.strip() for c in line.split(",")]
            continue
        if not in_bolus_section:
            continue
        if not line.startswith("Bolus,"):
            continue

        parts = line.split(",")
        if len(parts) < 6:
            continue
        try:
            row_dict = dict(zip(bolus_cols, parts))
            bolus_type   = row_dict.get("BolusType", "").strip()
            delivery_method = row_dict.get("BolusDeliveryMethod", "").strip()
            completion_dt = row_dict.get("CompletionDateTime", "").strip()
            insulin_str   = row_dict.get("InsulinDelivered", "0").strip()
            status        = row_dict.get("CompletionStatusDesc", "").strip()

            if not completion_dt or not insulin_str:
                continue

            insulin = float(insulin_str)
            if insulin <= 0:
                continue

            # Skip incomplete/cancelled boluses
            if status in ("User Stopped", "Incomplete"):
                continue

            dt = pd.Timestamp(completion_dt)
            is_smb = (bolus_type == "Auto" or delivery_method == "Auto")

            bolus_rows.append({
                "dt":         dt,
                "insulin":    insulin,
                "is_smb":     is_smb,
                "bolus_type": bolus_type,
                "event_type": f"Tandem-{bolus_type}",
            })
        except (ValueError, IndexError, KeyError):
            continue

    # ── Build DataFrames ──────────────────────────────────────────────────────
    egv_df = (
        pd.DataFrame(egv_rows)
        .drop_duplicates(subset=["dt"])
        .sort_values("dt")
        .reset_index(drop=True)
    ) if egv_rows else pd.DataFrame(columns=["dt", "glucose"])

    bgm_df = (
        pd.DataFrame(bgm_rows)
        .drop_duplicates(subset=["dt"])
        .sort_values("dt")
        .reset_index(drop=True)
    ) if bgm_rows else pd.DataFrame(columns=["dt", "glucose"])

    bolus_df = (
        pd.DataFrame(bolus_rows)
        .sort_values("dt")
        .reset_index(drop=True)
    ) if bolus_rows else pd.DataFrame(
        columns=["dt", "insulin", "is_smb", "bolus_type", "event_type"])

    # ── Build labels ──────────────────────────────────────────────────────────
    algo_tag     = f" ({pump_algo})" if pump_algo else ""
    sensor_label = f"Tandem t:slim X2{algo_tag}"
    units        = "mg/dL"

    return egv_df, units, sensor_label, patient_name, bgm_df, bolus_df
