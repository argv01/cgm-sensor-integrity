# © 2025-2026 Dan Heller. MIT License. https://github.com/argv01/cgm-sensor-integrity

"""
CGM cluster detector (v5)

What this detector is trying to do
----------------------------------
This module detects time windows where CGM readings show patterns that are unlikely to be physiologic and could
mislead automated insulin delivery (AID) systems. The detector focuses on rapid, directionally incoherent
reversals ("yo-yo" motion) with enough amplitude to plausibly drive incorrect dosing decisions.

This is designed for post-hoc safety analysis:
- It is *not* a real-time algorithm. Cluster boundaries are often back-dated once subsequent readings make the
  pattern evident.
- The intent is to quantify risk and surface candidate days for inspection, not to provide clinical advice.

Changes from v3
---------------
- **No merge.** Each detected window of incoherence is reported individually. v3 merged adjacent windows
  (gap <= 30 min) into single clusters, which absorbed stable readings and inflated bounding boxes. v4 keeps
  them separate so boxes reflect where the oscillation actually occurs.
- **Chain-based density promotion** replaces total-amplitude promotion. v3 promoted confidence if the
  cluster's total glucose range (max - min) exceeded 55 mg/dL. This conflated wide range over long durations
  with genuinely implausible oscillation. v4 instead finds chains of adjacent clusters (connected components
  where gaps <= `chain_radius_minutes`) and promotes all members when the chain size >= `chain_min_size`.
  This captures "many noisy windows in a row" as a danger signal without inflating individual cluster boundaries.
- **Single-step (spike) promotion** is retained from v3.
- **`find_hypo_events()`** identifies clusters followed by hypoglycemia within a configurable
  time window (default 3 hours). The `min_confidence` parameter controls which clusters
  qualify — default is "medium", meaning elevated and critical clusters preceding a hypo
  flagged regardless of severity. Optionally filtered by insulin dosing during the cluster.
- **Single device-agnostic profile.** v3 had separate G6 and G7 profiles with different
  thresholds. v4 uses one set of thresholds for all CGM data. The `profile` parameter is
  accepted for backward compatibility but has no effect. Use keyword overrides for tuning.

Inputs
------
- `timestamps`: a sequence of datetimes (or values coercible by pandas to datetime)
- `glucose`: a sequence of glucose values (mg/dL), same length as timestamps

Data sources
------------
This module is source-agnostic. It operates on (timestamp, glucose) pairs regardless of origin.
Supported sources via the renderer (cgm_render_report_v6.py):
- Dexcom Clarity CSV exports (--clarity_csv)
- Tandem Source Daily Timeline CSV exports (--tconnect_csv)
- Abbott FreeStyle Libre 3 CSV exports (--libre_csv)
- Sugarmate Excel report exports (--sugarmate)
- AndroidAPS Open Humans exports (--androidaps_dir)
- Paired G6/G7 Excel workbook (--g6g7_excel)

Any other CGM source can be used if mapped to (timestamp, glucose) series.
Per-device metadata (Sensor ID, Transmitter ID) is outside this module.

Public API
----------
`detect_clusters(timestamps, glucose, profile="g6"|"g7", **overrides) -> list[dict]`
`find_hypo_events(timestamps, glucose, ...) -> list[dict]`

Versioning note
---------------
This file supersedes cgm_cluster_detector_v3.py for Bootstrap Contract v1.4.
"""

from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable, List, Dict, Any, Optional
import numpy as np
import pandas as pd


@dataclass
class DetectorConfig:
    window_minutes: float = 30.0
    min_points: int = 6           # kept for API compatibility; no longer used
                                  # as an unconditional floor — see win_pts fix below
    min_window_minutes: float = 15.0  # floor expressed in time, not points;
                                      # scales correctly with coarse sampling rates
    min_reversals: int = 2
    min_amp: float = 15.0
    incoh_ratio_thr: float = 0.35
    min_cluster_minutes: float = 20.0
    gap_threshold_minutes: float = 12.0  # rolling windows spanning gaps > this are suppressed
                                          # (2.4× the nominal 5-min interval; handles transmitter
                                          # changes, signal loss, DST spring-forward, etc.)
    # confidence thresholds (score-based)
    conf_high: float = 3.0
    conf_medium: float = 2.0
    # v4 chain-based density promotion
    chain_radius_minutes: float = 30.0
    chain_min_size: int = 3
    # single-step spike promotion (retained from v3)
    spike_bump_delta_mgdl: float = 40.0
    spike_bump_enabled: bool = True
    calibration_grace_minutes: float = 15.0
    calibration_timestamps: tuple = ()


def _to_series(x: Iterable) -> pd.Series:
    if isinstance(x, pd.Series):
        return x
    return pd.Series(list(x))


def _estimate_dt_minutes(ts: pd.Series) -> float:
    diffs = np.diff(ts.values.astype("datetime64[ns]")).astype("timedelta64[s]").astype(float) / 60.0
    diffs = diffs[np.isfinite(diffs)]
    if len(diffs) == 0:
        return 5.0
    med = float(np.median(diffs))
    return med if med > 0 else 5.0


def _promote_once(level: str) -> str:
    return 'high' if level == 'medium' else ('medium' if level == 'low' else 'high')


def _score_clusters(df: pd.DataFrame, cfg: DetectorConfig) -> List[Dict[str, Any]]:
    """Detect and score individual cluster windows. No merging."""
    t = df["time"].reset_index(drop=True)
    g = df["glucose"].astype(float).reset_index(drop=True)

    dt_min = _estimate_dt_minutes(t)
    # win_pts: number of rolling-window points corresponding to cfg.window_minutes.
    # Floor is expressed in time (cfg.min_window_minutes), not raw points, so that
    # coarser-sampled data (e.g. 7-10 min intervals from Gluroo, Nightscout, etc.)
    # does not produce an inflated window. At 8 min/pt the old cfg.min_points=6
    # floor would silently expand the window to 48 min instead of the intended 30.
    win_pts = max(
        int(round(cfg.window_minutes / dt_min)),
        int(round(cfg.min_window_minutes / dt_min)),
        3,  # hard minimum: need at least 3 points for any rolling computation
    )

    d = g.diff()
    sign = np.sign(d)
    rev = ((sign != sign.shift(1)) & (sign != 0) & (sign.shift(1) != 0)).astype(int)

    # Gap masking: suppress any rolling window that spans a timestamp gap larger than
    # gap_threshold_minutes. Prevents false clusters from transmitter changes, signal
    # loss, DST spring-forward, and fall-back.
    dt_gaps = t.diff().dt.total_seconds().div(60.0).fillna(0.0)
    gap_break = (dt_gaps > cfg.gap_threshold_minutes)
    gap_in_window = gap_break.rolling(win_pts, min_periods=1).max().astype(bool)

    rev_cnt = rev.rolling(win_pts, min_periods=win_pts).sum().where(~gap_in_window)
    amp = (g.rolling(win_pts, min_periods=win_pts).max()
           - g.rolling(win_pts, min_periods=win_pts).min()).where(~gap_in_window)

    sum_abs = d.abs().rolling(win_pts, min_periods=win_pts).sum().where(~gap_in_window)
    net = (g - g.shift(win_pts - 1)).abs()
    incoh = (sum_abs - net)
    incoh_ratio = (incoh / (sum_abs.replace(0, np.nan))).fillna(0)

    mask = (rev_cnt >= cfg.min_reversals) & (amp >= cfg.min_amp) & (incoh_ratio >= cfg.incoh_ratio_thr)
    idx = np.where(mask.values)[0]
    if len(idx) == 0:
        return []

    # contiguous mask segments
    segments = []
    s = int(idx[0]); p = int(idx[0])
    for i in idx[1:]:
        i = int(i)
        if i == p + 1:
            p = i
        else:
            segments.append((s, p))
            s = i; p = i
    segments.append((s, p))

    # back-date starts by win_pts-1 points
    expanded = [(max(0, s - (win_pts - 1)), e) for s, e in segments]

    # v4: merge only physically overlapping segments (from back-dating).
    # No gap-based merge — adjacent but non-overlapping segments stay separate.
    merged = []
    for s, e in expanded:
        if not merged:
            merged.append([s, e])
        else:
            ps, pe = merged[-1]
            if s <= pe:  # overlapping
                merged[-1][1] = max(pe, e)
            else:
                merged.append([s, e])

    out = []
    for s, e in merged:
        dur = (t.iloc[e] - t.iloc[s]).total_seconds() / 60.0
        if dur < cfg.min_cluster_minutes:
            continue

        w = df.iloc[s:e+1]
        peak_rev = float(rev_cnt.iloc[s:e+1].max())
        peak_incoh = float(incoh_ratio.iloc[s:e+1].max())

        score = 0.6 * (peak_rev / max(cfg.min_reversals, 1)) + 0.4 * (peak_incoh / max(cfg.incoh_ratio_thr, 1e-6))
        if score >= cfg.conf_high:
            conf = "high"
        elif score >= cfg.conf_medium:
            conf = "medium"
        else:
            conf = "low"

        amp_val = float(w['glucose'].max() - w['glucose'].min())
        if len(w) > 1:
            step_max = float(np.nanmax(np.abs(np.diff(w['glucose'].values))))
        else:
            step_max = 0.0

        # Spike promotion only (amplitude promotion removed in v4)
        bumped = False
        if bool(cfg.spike_bump_enabled) and step_max >= float(cfg.spike_bump_delta_mgdl):
            near_cal = False
            if getattr(cfg, 'calibration_timestamps', ()):
                cal_ts = pd.to_datetime(list(cfg.calibration_timestamps), errors='coerce')
                cal_ts = cal_ts[~pd.isna(cal_ts)]
                if len(cal_ts):
                    grace = pd.Timedelta(minutes=float(cfg.calibration_grace_minutes))
                    w0 = pd.Timestamp(t.iloc[s]); w1 = pd.Timestamp(t.iloc[e])
                    for ct in cal_ts:
                        if (ct - grace) <= w1 and (ct + grace) >= w0:
                            near_cal = True
                            break
            if not near_cal:
                conf = _promote_once(conf)
                bumped = True

        out.append({
            "start": pd.Timestamp(t.iloc[s]),
            "end": pd.Timestamp(t.iloc[e]),
            "min": float(w["glucose"].min()),
            "max": float(w["glucose"].max()),
            "duration_min": float(dur),
            "confidence": conf,
            "debug": {
                "dt_min": dt_min,
                "win_pts": win_pts,
                "peak_reversals_window": peak_rev,
                "peak_incoh_ratio": peak_incoh,
                "config": cfg.__dict__,
                "amp_val": amp_val,
                "step_max": step_max,
                "bumped": bumped,
            }
        })
    return out


def _chain_promote(clusters: List[Dict], cfg: DetectorConfig) -> List[Dict]:
    """
    Build connected components of clusters where gap <= chain_radius_minutes.
    Promote all members of chains with size >= chain_min_size by one confidence level.
    """
    n = len(clusters)
    if n == 0:
        return clusters

    radius = cfg.chain_radius_minutes
    threshold = cfg.chain_min_size

    parent = list(range(n))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[b] = a

    for i in range(n):
        for j in range(i + 1, n):
            ci, cj = clusters[i], clusters[j]
            if ci["start"] <= cj["end"] and cj["start"] <= ci["end"]:
                gap = 0.0
            else:
                gap = min(
                    abs((cj["start"] - ci["end"]).total_seconds()),
                    abs((ci["start"] - cj["end"]).total_seconds()),
                ) / 60.0
            if gap <= radius:
                union(i, j)

    components = defaultdict(list)
    for i in range(n):
        components[find(i)].append(i)

    result = []
    for i, c in enumerate(clusters):
        new_c = dict(c)
        new_c["debug"] = dict(c["debug"])
        chain_size = len(components[find(i)])
        new_c["debug"]["chain_size"] = chain_size
        new_c["debug"]["chain_promoted"] = False
        if chain_size >= threshold:
            new_c["confidence"] = _promote_once(c["confidence"])
            new_c["debug"]["chain_promoted"] = True
        result.append(new_c)
    return result


def _config_for_profile(profile: str) -> DetectorConfig:
    """Return detector configuration.
    
    v4 uses a single device-agnostic profile by default. The `profile` parameter
    is accepted for backward compatibility but "g6" and "g7" now return the same
    configuration. Use keyword overrides to `detect_clusters()` for fine-tuning.
    """
    return DetectorConfig(
        window_minutes=30.0,
        min_points=6,
        min_reversals=2,
        min_amp=15.0,
        incoh_ratio_thr=0.35,
        min_cluster_minutes=20.0,
    )


def detect_clusters(timestamps: Iterable, glucose: Iterable, profile: str = "g6", **overrides) -> List[Dict[str, Any]]:
    """
    Detect clusters of directionally incoherent CGM data.

    Parameters
    ----------
    timestamps : iterable of datetime-like
    glucose : iterable of numeric glucose values (mg/dL)
    profile : "g6" or "g7" (different default thresholds)
    **overrides : any DetectorConfig field can be overridden by keyword

    Returns
    -------
    list of dicts, each with: start, end, min, max, duration_min, confidence, debug
    """
    ts = _to_series(timestamps)
    gg = _to_series(glucose)

    df = pd.DataFrame({"time": pd.to_datetime(ts, errors="coerce"), "glucose": pd.to_numeric(gg, errors="coerce")})
    df = df.dropna().sort_values("time").reset_index(drop=True)

    cfg = _config_for_profile(profile)
    for k, v in overrides.items():
        if hasattr(cfg, k):
            setattr(cfg, k, v)

    clusters = _score_clusters(df, cfg)
    clusters = _chain_promote(clusters, cfg)
    return clusters


def find_hypo_events(
    timestamps: Iterable,
    glucose: Iterable,
    profile: str = "default",
    hypo_threshold: float = 70.0,
    window_hours: float = 3.0,
    min_confidence: str = "medium",
    require_insulin: bool = False,
    insulin_times: Optional[Iterable] = None,
    insulin_units: Optional[Iterable] = None,
    **overrides,
) -> List[Dict[str, Any]]:
    """
    Find clusters followed by hypoglycemia.

    Parameters
    ----------
    timestamps, glucose, profile, **overrides : same as detect_clusters
    hypo_threshold : glucose level (mg/dL) below which a reading counts as hypo (default 70)
    window_hours : how many hours after cluster end to look for hypo (default 3.0)
    min_confidence : minimum cluster confidence to consider ("low", "medium", or "high"; default "medium")
    require_insulin : if True, only return events where insulin was dosed during the cluster
    insulin_times : iterable of datetime-like insulin dosing timestamps (optional)
    insulin_units : iterable of numeric insulin amounts (optional, same length as insulin_times)

    Returns
    -------
    list of dicts, each with:
      cluster, nadir, nadir_time, time_to_nadir_hours, n_readings_below_threshold,
      insulin_during_cluster (list of {time, units} dicts; empty if no insulin data)
    """
    conf_levels = {"low": 0, "medium": 1, "high": 2}
    min_conf_val = conf_levels.get(min_confidence.lower(), 0)
    ts = _to_series(timestamps)
    gg = _to_series(glucose)

    df = pd.DataFrame({"time": pd.to_datetime(ts, errors="coerce"), "glucose": pd.to_numeric(gg, errors="coerce")})
    df = df.dropna().sort_values("time").reset_index(drop=True)

    clusters = detect_clusters(timestamps, glucose, profile=profile, **overrides)
    qualifying = [c for c in clusters if conf_levels.get(c["confidence"], 0) >= min_conf_val]

    insulin_df = None
    if insulin_times is not None and insulin_units is not None:
        insulin_df = pd.DataFrame({
            "time": pd.to_datetime(_to_series(insulin_times), errors="coerce"),
            "units": pd.to_numeric(_to_series(insulin_units), errors="coerce"),
        }).dropna().sort_values("time")

    events = []
    for c in qualifying:
        window_end = c["end"] + pd.Timedelta(hours=window_hours)
        post = df[(df["time"] > c["end"]) & (df["time"] <= window_end)]
        hypo_readings = post[post["glucose"] < hypo_threshold]

        if len(hypo_readings) == 0:
            continue

        nadir = float(post["glucose"].min())
        nadir_idx = post["glucose"].idxmin()
        nadir_time = post.loc[nadir_idx, "time"]
        time_to_nadir = (nadir_time - c["end"]).total_seconds() / 3600.0

        insulin_during = []
        if insulin_df is not None:
            mask = (insulin_df["time"] >= c["start"]) & (insulin_df["time"] <= c["end"])
            for _, row in insulin_df[mask].iterrows():
                insulin_during.append({"time": row["time"], "units": float(row["units"])})

        if require_insulin and len(insulin_during) == 0:
            continue

        events.append({
            "cluster": c,
            "nadir": nadir,
            "nadir_time": pd.Timestamp(nadir_time),
            "time_to_nadir_hours": time_to_nadir,
            "n_readings_below_threshold": len(hypo_readings),
            "insulin_during_cluster": insulin_during,
        })

    return events
