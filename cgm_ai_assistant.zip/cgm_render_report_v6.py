#!/usr/bin/env python3
# © 2025-2026 Dan Heller. MIT License. https://github.com/argv01/cgm-sensor-integrity
"""
CGM Report Renderer (v6)

Reads CGM data from multiple sources, runs the v5 cluster detector, and produces:

  - Daily report PNG  (--date YYYY-MM-DD)
  - Summary dashboard PNG  (--dashboard)
  - Multi-sensor summary PNG  (automatic when multiple streams are detected)

Supported input formats
-----------------------
  --clarity_csv FILE [FILE ...]   Dexcom Clarity export (one or more CSVs merged)
  --g6g7_excel FILE               Paired G6/G7 Excel workbook (2023 study data —
                                  not a generic Excel file; see README for format)
  --libre_csv FILE                Abbott FreeStyle Libre 3 CSV export
  --tconnect_csv FILE [FILE ...]  Tandem Source Daily Timeline CSV export
                                  (pass multiple files to merge months automatically)
  --sugarmate FILE                Sugarmate Excel report export (.xlsx)
  --androidaps_dir DIR            AndroidAPS Open Humans export folder

Usage
-----
  # Dexcom Clarity
  python cgm_render_report_v6.py --clarity_csv export.csv --dashboard --out dashboard.png

  # Tandem pump (one or more months)
  python cgm_render_report_v6.py --tconnect_csv jan.csv feb.csv --dashboard --out dashboard.png

  # Sugarmate
  python cgm_render_report_v6.py --sugarmate report.xlsx --dashboard --out dashboard.png

  # Abbott Libre
  python cgm_render_report_v6.py --libre_csv export.csv --dashboard --out dashboard.png

  # Daily report for any source
  python cgm_render_report_v6.py --clarity_csv export.csv --date 2026-01-03 --out report.png

Optional tuning
---------------
  --hypo_threshold 70      Glucose (mg/dL) below which a reading counts as hypoglycaemic
  --window_hours 3         Hours after cluster end to look for a hypo event
  --min_confidence medium  Minimum cluster confidence for hypo matching (low/medium/high)
  --sensor_labels STR      Override inferred sensor boundaries, e.g.
                           "S1:2023-03-02:2023-03-12,S2:2023-03-12:2023-03-22"
  --hide_smb               Suppress SMB micro-bolus markers on daily reports

Sensor health scoring
---------------------
Each sensor segment in the dashboard header is coloured by a log-progressive
contamination score:

    score = (W_crit + W_elev) / (W_crit + W_elev + W_clean)

where:
    W_crit  = crit_min  × 1.5 × (1 + ln(1 + crit_min  / 30))
    W_elev  = elev_min  × 1.0 × (1 + ln(1 + elev_min  / 60))
    W_clean = clean_min × 1.0 × (1 + ln(1 + clean_min / 120))

The log terms give sustained contamination disproportionately higher weight
than brief bursts, while long clean stretches earn proportionally more credit.

Tier thresholds (see TIER_PURPLE / TIER_RED / TIER_YELLOW constants):
    purple  ≥ 8%   severely compromised
    red     ≥ 4%   significantly compromised
    yellow  ≥ 1%   mildly compromised
    green   < 1%   clean

Public API
----------
    load_clarity_csv(path)          → (egv_df, units, sensor_label, name, bgm_df)
    load_excel_workbook(path, type) → (egv_df, units, sensor_label)
    load_libre_csv(path)            → (egv_df, units, sensor_label, name, bgm_df)
    sensor_contamination_tier(crit_min, elev_min, total_min) → tier_str
    render_daily_report(data, path)
    render_dashboard(data, path)
    render_dashboard_summary(data, path)
    render_multi_sensor_summary(stream_results, path)
"""

from __future__ import annotations
import argparse
import textwrap
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

import cgm_cluster_detector_v5 as det

# ── Transmitter ID formatter ─────────────────────────────────────────────────

def _fmt_tx_id(val) -> str:
    """Strip float .0 suffix and truncate long numeric IDs."""
    s = str(val).strip()
    if s.endswith(".0") and s[:-2].isdigit():
        s = s[:-2]
    if len(s) > 12:
        s = "…" + s[-9:]
    return s


def _detect_units(col_name: str) -> str:
    """Extract units from CSV column header."""
    if "mmol" in col_name.lower():
        return "mmol/L"
    return "mg/dL"


# ── Data Loading ─────────────────────────────────────────────────────────────
FONT_FAMILY = "DejaVu Serif"
plt.rcParams.update({"font.family": "serif", "font.serif": [FONT_FAMILY], "font.size": 11})

DISPLAY_LABEL = {"high": "Critical", "medium": "Elevated"}
DISPLAY_COLOR = {"high": "#d32f2f", "medium": "#f57c00"}

_CONF_RANK = {"high": 3, "medium": 2, "low": 1}

# ── Sensor health tier colors — single source of truth ───────────────────────
# All sensor label boxes, gradient strips, and legend patches use these.
TIER_SOLID = {
    "green":  "#2e7d32",
    "yellow": "#FFEB3B",
    "red":    "#c62828",
    "purple": "#6a1b9a",
}
TIER_TEXT = {
    "green":  "#ffffff",   # dark green background needs white text
    "yellow": "#000000",
    "red":    "#ffffff",
    "purple": "#ffffff",
}
# Light pastel fills for stream header bars (title row background)
TIER_FILL = {
    "green":  "#c8e6c9",
    "yellow": "#fff9c4",
    "red":    "#ffcdd2",
    "purple": "#e1bee7",
}
TIER_FILL_TEXT = {
    "green":  "#1b5e20",
    "yellow": "#333333",
    "red":    "#b71c1c",
    "purple": "#4a148c",
}
# Bold RGBA for gradient strip (same hues, full saturation)
TIER_RGBA = {
    "green":  (0.18, 0.65, 0.18, 1.0),
    "yellow": (1.00, 0.92, 0.23, 1.0),   # matches #FFEB3B
    "red":    (0.85, 0.10, 0.10, 1.0),
    "purple": (0.55, 0.10, 0.75, 1.0),
}

def sensor_contamination_tier(crit_min: float, elev_min: float,
                               total_min: float) -> str:
    """
    Log-progressive contamination score for a sensor segment.
    Sustained contamination penalises more; sustained clean time credits more.
    Returns one of: 'green', 'yellow', 'red', 'purple'.
    """
    import math as _math
    clean_min = max(total_min - crit_min - elev_min, 0)
    wc    = crit_min * 1.5 * (1 + _math.log(1 + crit_min  / 30))
    we    = elev_min * 1.0 * (1 + _math.log(1 + elev_min  / 60))
    wk    = clean_min * 1.0 * (1 + _math.log(1 + clean_min / 120))
    score = (wc + we) / max(wc + we + wk, 1)
    if   score >= TIER_PURPLE: return "purple"
    elif score >= TIER_RED:    return "red"
    elif score >= TIER_YELLOW: return "yellow"
    else:                      return "green"

def _merge_clusters(clusters: list, gap_minutes: float = 30.0) -> list:
    """
    Merge clusters whose inter-cluster gap is <= gap_minutes into a single
    display cluster. Uses start_wall/end_wall if present, otherwise start/end.
    Merged cluster takes the highest confidence of its members.
    Does NOT merge across gaps larger than gap_minutes (e.g. transmitter changes).
    """
    if not clusters:
        return []
    key_s = lambda c: c.get("start_wall", c["start"])
    key_e = lambda c: c.get("end_wall",   c["end"])
    ordered = sorted(clusters, key=key_s)
    merged = []
    cur = dict(ordered[0])
    for nxt in ordered[1:]:
        gap = (key_s(nxt) - key_e(cur)).total_seconds() / 60.0
        if 0 <= gap <= gap_minutes:
            cur["end"]          = nxt["end"]
            cur["end_wall"]     = key_e(nxt)
            cur["max"]          = max(cur["max"], nxt["max"])
            cur["min"]          = min(cur["min"], nxt["min"])
            if _CONF_RANK.get(nxt["confidence"], 0) > _CONF_RANK.get(cur["confidence"], 0):
                cur["confidence"] = nxt["confidence"]
            cur["duration_min"] = (key_e(cur) - key_s(cur)).total_seconds() / 60.0
        else:
            merged.append(cur)
            cur = dict(nxt)
    merged.append(cur)
    return merged
COLORS_POOL   = ["#ffcdd2", "#ffe0b2", "#c8e6c9", "#b2dfdb", "#bbdefb", "#e1bee7",
                 "#f8bbd0", "#dcedc8", "#b3e5fc", "#ffe0b2"]

PAGE_SIZE      = 90    # days per dashboard page (fixed x-axis width)
MINUTES_PER_DAY = 1440  # 24 × 60

# Sensor health tier score thresholds (log-progressive contamination score)
TIER_PURPLE = 0.08   # ≥8%  — severely compromised
TIER_RED    = 0.04   # ≥4%  — significantly compromised
TIER_YELLOW = 0.01   # ≥1%  — mildly compromised
                     # <1%  — clean (green)


# ═══════════════════════════════════════════════════════════════════════════════
# DATA LOADING
# ═══════════════════════════════════════════════════════════════════════════════

def _extract_sensor_type(src_vals) -> str:
    """
    Derive a clean sensor type label from Dexcom 'Source Device' column values.
    e.g. 'iOS G6' -> 'Dexcom G6', 'iOS G7' -> 'Dexcom G7', 'Libre 3' -> 'Libre 3'
    """
    combined = " ".join(str(v) for v in src_vals).upper()
    if "G7" in combined:
        return "Dexcom G7"
    if "G6" in combined:
        return "Dexcom G6"
    if "LIBRE 3" in combined or "LIBRE3" in combined:
        return "Libre 3"
    if "LIBRE" in combined:
        return "FreeStyle Libre"
    if "ONE+" in combined:
        return "Dexcom ONE+"
    if "ONE" in combined:
        return "Dexcom ONE"
    if "OPENAPS" in combined or "ANDROIDAPS" in combined:
        return "OpenAPS"
    return "CGM"


def load_clarity_csv(path: str) -> Tuple[pd.DataFrame, str, str, str]:
    """
    Load a standard Dexcom Clarity export CSV.
    Returns (egv_df, units, sensor_type_label, patient_name)
    """
    raw = pd.read_csv(path, low_memory=False)

    # Extract patient name from header rows (FirstName / LastName event types)
    pat_col = next((c for c in raw.columns if "Patient Info" in c), None)
    first, last = "", ""
    patient_name = ""
    if pat_col:
        # Check for OpenAPS merged export marker: "OpenAPS|donor_id"
        sample_val = raw[pat_col].dropna().iloc[0] if not raw[pat_col].dropna().empty else ""
        if str(sample_val).startswith("OpenAPS|"):
            donor_id = str(sample_val).split("|", 1)[1].strip()
            patient_name = donor_id   # donor number shown as Name
        else:
            fn_row = raw[raw["Event Type"] == "FirstName"]
            ln_row = raw[raw["Event Type"] == "LastName"]
            if not fn_row.empty:
                first = str(fn_row[pat_col].iloc[0]).strip()
            if not ln_row.empty:
                last = str(ln_row[pat_col].iloc[0]).strip()
            patient_name = f"{first} {last}".strip() if (first or last) else ""

    # Detect glucose column and units
    glucose_col = next(
        (c for c in raw.columns if "Glucose Value" in c),
        None
    )
    if glucose_col is None:
        raise ValueError("No 'Glucose Value' column found in CSV.")
    units = _detect_units(glucose_col)

    # Detect timestamp column
    ts_col = next((c for c in raw.columns if "Timestamp" in c and "YYYY" in c), None)
    if ts_col is None:
        ts_col = next((c for c in raw.columns if "Timestamp" in c), None)
    if ts_col is None:
        raise ValueError("No timestamp column found in CSV.")

    egv = raw[raw["Event Type"] == "EGV"].copy()
    egv["dt"] = pd.to_datetime(egv[ts_col], errors="coerce")
    egv["glucose"] = pd.to_numeric(egv[glucose_col], errors="coerce")

    # Extract manual BGM (fingerstick) readings — "Blood Glucose" and "Calibration"
    bgm_raw = raw[raw["Event Type"].isin(["Blood Glucose", "Calibration"])].copy()
    bgm_raw["dt"] = pd.to_datetime(bgm_raw[ts_col], errors="coerce")
    bgm_raw["glucose"] = pd.to_numeric(bgm_raw[glucose_col], errors="coerce")
    bgm_df = bgm_raw.dropna(subset=["dt", "glucose"])[["dt", "glucose"]].copy()
    bgm_df = bgm_df.sort_values("dt").reset_index(drop=True)

    tx_col = next((c for c in raw.columns if "Transmitter ID" in c), None)
    if tx_col:
        egv["transmitter_id"] = egv[tx_col].fillna("Unknown").apply(_fmt_tx_id)
    else:
        egv["transmitter_id"] = "Unknown"

    # Build dt_mono: a monotonic synthetic clock immune to DST artifacts.
    # TX time counters are per-transmitter and independent — they cannot be
    # compared across transmitters. Strategy:
    #   1. Sort by wall-clock dt (Clarity guarantees correct order aside from DST).
    #   2. Within each transmitter segment, advance dt_mono by TX time diffs
    #      (monotonic hardware counter, 1-second resolution, DST-immune).
    #   3. At transmitter boundaries, advance by wall-clock diff (real gap anyway).
    # This gives a globally monotonic timestamp that correctly detects intra-session
    # gaps (signal loss, spring-forward hour) without cross-transmitter contamination.
    tx_time_col = next((c for c in raw.columns if "Transmitter Time" in c), None)
    egv = egv.dropna(subset=["dt", "glucose"]).sort_values("dt").reset_index(drop=True)
    if tx_time_col:
        egv["_tx_time"] = pd.to_numeric(egv[tx_time_col], errors="coerce")
        mono = [egv["dt"].iloc[0]]
        for i in range(1, len(egv)):
            prev, cur = egv.iloc[i - 1], egv.iloc[i]
            if (cur["transmitter_id"] == prev["transmitter_id"]
                    and pd.notna(cur["_tx_time"]) and pd.notna(prev["_tx_time"])
                    and cur["_tx_time"] > prev["_tx_time"]):
                # Same TX — use hardware counter diff (DST-immune)
                delta = pd.Timedelta(seconds=float(cur["_tx_time"] - prev["_tx_time"]))
            else:
                # TX boundary or missing TX time — fall back to wall-clock diff
                delta = cur["dt"] - prev["dt"]
                if delta.total_seconds() < 0:
                    delta = pd.Timedelta(seconds=300)   # fallback: 5 min
            mono.append(mono[-1] + delta)
        egv["dt_mono"] = mono
        egv = egv.drop(columns=["_tx_time"])
    else:
        egv["dt_mono"] = egv["dt"]

    # Derive sensor type from Source Device column
    # For OpenAPS merged exports, transmitter_id = "???" — detect from that
    src_col = next((c for c in raw.columns if "Source Device" in c), None)
    tx_col_vals = egv["transmitter_id"].dropna().unique() if "transmitter_id" in egv.columns else []
    if all(v == "???" for v in tx_col_vals):
        sensor_type_label = "OpenAPS"
    else:
        sensor_type_label = _extract_sensor_type(
            egv[src_col].dropna().unique() if src_col else []
        )

    egv = _infer_sensor_labels(egv, sensor_type_label=sensor_type_label)
    return egv[["dt", "dt_mono", "glucose", "transmitter_id", "sensor_label"]], units, sensor_type_label, patient_name, bgm_df


def load_excel_workbook(path: str, sensor_type: str) -> Tuple[pd.DataFrame, str, str]:
    """
    Load the 2023 paired G6/G7 Excel workbook.
    sensor_type: "G6" or "G7"
    Returns (egv_df, units)

    The Clarity_Export sheet has date-only timestamps (time zeroed out by Excel).
    The Raw Data sheet has separate Date + Time columns with full timestamps.
    We prefer Raw Data when available.
    """
    units = "mg/dL"
    st = sensor_type.upper()
    prefix = "G6" if st == "G6" else "G7"

    # Try Raw Data sheet first (has proper timestamps)
    xl_sheets = pd.ExcelFile(path).sheet_names
    if "Raw Data" in xl_sheets:
        raw = pd.read_excel(path, sheet_name="Raw Data")
        date_col = f"{prefix} Date"
        time_col = f"{prefix} Time"
        gluc_col = f"{prefix} Glucose"
        if date_col in raw.columns and time_col in raw.columns and gluc_col in raw.columns:
            df = raw[[date_col, time_col, gluc_col]].copy()
            df = df.dropna(subset=[date_col, time_col, gluc_col])
            # Combine date + time: date col is Timestamp, time col is datetime.time
            df["dt"] = df.apply(
                lambda r: pd.Timestamp(r[date_col]).replace(
                    hour=r[time_col].hour,
                    minute=r[time_col].minute,
                    second=r[time_col].second
                ) if pd.notna(r[date_col]) and pd.notna(r[time_col]) else pd.NaT,
                axis=1
            )
            df["glucose"] = pd.to_numeric(df[gluc_col], errors="coerce")
            # Load transmitter IDs from Clarity_Export sheet.
            # Timestamps are split: date in "Timestamp" col, time in "Unnamed: 2"
            tx_by_dt = {}  # floor-minute timestamp → transmitter_id
            try:
                ce = pd.read_excel(path, sheet_name="Clarity_Export")
                ts_ce  = next((c for c in ce.columns if "Timestamp" in c), None)
                tx_ce  = next((c for c in ce.columns if "Transmitter ID" in c), None)
                src_ce = next((c for c in ce.columns if "Source Device" in c), None)
                time_ce = "Unnamed: 2" if "Unnamed: 2" in ce.columns else None
                if ts_ce and tx_ce:
                    ce_egv = ce[ce["Event Type"] == "EGV"].copy()
                    if src_ce:
                        if st == "G6":
                            ce_egv = ce_egv[ce_egv[src_ce].str.contains("G6", na=False)]
                        else:
                            ce_egv = ce_egv[~ce_egv[src_ce].str.contains("G6", na=False)]
                    # Combine date + time columns
                    if time_ce:
                        ce_egv["_dt"] = ce_egv.apply(
                            lambda r: pd.Timestamp(r[ts_ce]).replace(
                                hour=r[time_ce].hour,
                                minute=r[time_ce].minute,
                                second=r[time_ce].second
                            ) if pd.notna(r[ts_ce]) and pd.notna(r[time_ce]) else pd.NaT,
                            axis=1)
                    else:
                        ce_egv["_dt"] = pd.to_datetime(ce_egv[ts_ce], errors="coerce")
                    ce_egv["_tx"] = ce_egv[tx_ce].fillna("Unknown").apply(_fmt_tx_id)
                    tx_by_dt = dict(zip(ce_egv["_dt"].dt.floor("min"), ce_egv["_tx"]))
            except Exception:
                pass

            if tx_by_dt:
                df["transmitter_id"] = df["dt"].dt.floor("min").map(tx_by_dt).fillna("Unknown")
            else:
                df["transmitter_id"] = "Unknown"
            df = df.dropna(subset=["dt", "glucose"]).sort_values("dt").reset_index(drop=True)
            df["dt_mono"] = df["dt"]
            max_days = 10 if st == "G7" else 0
            sensor_type_label = f"Dexcom {st}"
            df = _infer_sensor_labels(df, gap_hours=1.0, max_sensor_days=max_days,
                                      sensor_type_label=sensor_type_label)
            # Drop stub sensors (< 50 readings)
            MIN_SENSOR_READINGS = 50
            counts = df["sensor_label"].value_counts()
            keep = counts[counts >= MIN_SENSOR_READINGS].index
            df = df[df["sensor_label"].isin(keep)].reset_index(drop=True)
            df = df.drop(columns=["sensor_label"])
            df = _infer_sensor_labels(df, gap_hours=1.0, max_sensor_days=max_days,
                                      sensor_type_label=sensor_type_label)
            # Extract carb data from the shared "Date / Time / carbs (g)" columns
            carb_df = pd.DataFrame(columns=["dt", "carbs"])
            if "carbs (g)" in raw.columns:
                carb_date_col = raw.columns[raw.columns.get_loc("carbs (g)") - 2]
                carb_time_col = raw.columns[raw.columns.get_loc("carbs (g)") - 1]
                carb_raw = raw[[carb_date_col, carb_time_col, "carbs (g)"]].copy()
                carb_raw = carb_raw.dropna(subset=["carbs (g)"])
                carb_raw = carb_raw[pd.to_numeric(carb_raw["carbs (g)"], errors="coerce") > 0]
                if not carb_raw.empty:
                    carb_raw["dt"] = carb_raw.apply(
                        lambda r: pd.Timestamp(r[carb_date_col]).replace(
                            hour=r[carb_time_col].hour,
                            minute=r[carb_time_col].minute,
                            second=getattr(r[carb_time_col], "second", 0)
                        ) if pd.notna(r[carb_date_col]) and pd.notna(r[carb_time_col]) else pd.NaT,
                        axis=1
                    )
                    carb_raw["carbs"] = pd.to_numeric(carb_raw["carbs (g)"], errors="coerce")
                    carb_df = carb_raw.dropna(subset=["dt","carbs"])[["dt","carbs"]].sort_values("dt").reset_index(drop=True)

            # Extract bolus data from the shared "Date / Time / bolus (u)" columns
            bolus_df = pd.DataFrame(columns=["dt","insulin","is_smb","bolus_type","event_type"])
            if "bolus (u)" in raw.columns:
                bol_date_col = raw.columns[raw.columns.get_loc("bolus (u)") - 2]
                bol_time_col = raw.columns[raw.columns.get_loc("bolus (u)") - 1]
                bol_raw = raw[[bol_date_col, bol_time_col, "bolus (u)"]].copy()
                bol_raw = bol_raw.dropna(subset=["bolus (u)"])
                bol_raw = bol_raw[pd.to_numeric(bol_raw["bolus (u)"], errors="coerce") > 0]
                if not bol_raw.empty:
                    bol_raw["dt"] = bol_raw.apply(
                        lambda r: pd.Timestamp(r[bol_date_col]).replace(
                            hour=r[bol_time_col].hour,
                            minute=r[bol_time_col].minute,
                            second=getattr(r[bol_time_col], "second", 0)
                        ) if pd.notna(r[bol_date_col]) and pd.notna(r[bol_time_col]) else pd.NaT,
                        axis=1
                    )
                    bol_raw["insulin"]    = pd.to_numeric(bol_raw["bolus (u)"], errors="coerce")
                    bol_raw["is_smb"]     = False
                    bol_raw["bolus_type"] = "Food/Correction"
                    bol_raw["event_type"] = "Excel-Bolus"
                    bolus_df = bol_raw.dropna(subset=["dt","insulin"])[
                        ["dt","insulin","is_smb","bolus_type","event_type"]
                    ].sort_values("dt").reset_index(drop=True)

            return df[["dt", "dt_mono", "glucose", "transmitter_id", "sensor_label"]], units, sensor_type_label, carb_df, bolus_df

    # Fallback: Clarity_Export sheet
    raw = pd.read_excel(path, sheet_name="Clarity_Export")
    glucose_col = next((c for c in raw.columns if "Glucose Value" in c), None)
    if glucose_col is None:
        raise ValueError("No glucose column found in workbook.")
    units = _detect_units(glucose_col)
    ts_col = next((c for c in raw.columns if "Timestamp" in c), None)
    egv = raw[raw["Event Type"] == "EGV"].copy()
    egv["dt"] = pd.to_datetime(egv[ts_col], errors="coerce")
    egv["glucose"] = pd.to_numeric(egv[glucose_col], errors="coerce")
    src_col = next((c for c in raw.columns if "Source Device" in c), None)
    if src_col:
        if st == "G6":
            egv = egv[egv[src_col].str.contains("G6", na=False)]
        else:
            egv = egv[~egv[src_col].str.contains("G6", na=False)]
    tx_col = next((c for c in raw.columns if "Transmitter ID" in c), None)
    egv["transmitter_id"] = (egv[tx_col].fillna("Unknown").apply(_fmt_tx_id)
                             if tx_col else "Unknown")
    egv = egv.dropna(subset=["dt", "glucose"]).sort_values("dt").reset_index(drop=True)
    egv = _infer_sensor_labels(egv)
    sensor_type_label = f"Dexcom {st}"
    return egv[["dt", "glucose", "transmitter_id", "sensor_label"]], units, sensor_type_label, pd.DataFrame(columns=["dt","carbs"]), pd.DataFrame(columns=["dt","insulin","is_smb","bolus_type","event_type"])


def load_libre_csv(path: str) -> Tuple[pd.DataFrame, str, str, str]:
    """
    Load an Abbott FreeStyle Libre 3 CSV export.
    Returns (egv_df, units, sensor_type_label, patient_name)
    The Libre export has a 2-row metadata header; row 1 contains column names.
    Record Type 0 = historic glucose (EGV equivalent).
    Serial Number is used as transmitter_id (one serial = one sensor).
    """
    # Read metadata row for patient name
    meta = pd.read_csv(path, nrows=1, header=None)
    patient_name = ""
    for v in meta.iloc[0].tolist():
        if isinstance(v, str) and v.strip() and v.strip() not in ["Generated on","Generated by"]:
            patient_name = v.strip()

    df = pd.read_csv(path, skiprows=1, low_memory=False)
    ts_col   = next((c for c in df.columns if "Device Timestamp" in c), None)
    gl_col   = next((c for c in df.columns if "Historic Glucose" in c), None)
    rt_col   = next((c for c in df.columns if "Record Type" in c), None)
    sn_col   = next((c for c in df.columns if "Serial Number" in c), None)
    if not ts_col or not gl_col:
        raise ValueError("Cannot find required columns in Libre CSV")

    egv = df[df[rt_col] == 0].copy() if rt_col else df.copy()
    egv["dt"]      = pd.to_datetime(egv[ts_col], errors="coerce")
    egv["glucose"] = pd.to_numeric(egv[gl_col],  errors="coerce")
    egv["transmitter_id"] = egv[sn_col].fillna("Unknown").astype(str) if sn_col else "Unknown"

    # Detect units from column name
    units = "mmol/L" if "mmol" in gl_col.lower() else "mg/dL"

    egv = egv.dropna(subset=["dt","glucose"]).sort_values("dt").reset_index(drop=True)
    egv["dt_mono"] = egv["dt"]   # no TX counter available

    # Libre sensors: 14-day max wear; use 7-day MIN_SESSION
    egv = _infer_sensor_labels(egv, sensor_type_label="FreeStyle Libre 3")

    # BGM: Record Type 1 = scan glucose (fingerstick-equivalent)
    # Libre scan glucose (Record Type 1) = NFC tap readings, not manual fingersticks.
    # Exclude from BGM overlay — they are not independent ground-truth measurements.
    bgm_df = pd.DataFrame()
    if rt_col:
        strip_col = next((c for c in df.columns if "Strip Glucose" in c), None)
        if strip_col:
            strip_raw = df[pd.to_numeric(df.get(strip_col, pd.Series()), errors="coerce").notna()].copy()
            strip_raw["dt"]      = pd.to_datetime(strip_raw[ts_col], errors="coerce")
            strip_raw["glucose"] = pd.to_numeric(strip_raw[strip_col], errors="coerce")
            bgm_df = strip_raw.dropna(subset=["dt","glucose"])[["dt","glucose"]].sort_values("dt").reset_index(drop=True)

    return egv[["dt","dt_mono","glucose","transmitter_id","sensor_label"]], units, "FreeStyle Libre 3", patient_name, bgm_df


def _find_sensor_boundaries(gap_times: List, max_sensor_hours: float = 240.0,
                             min_gap_hours: float = 1.5,
                             min_session_hours: float = 72.0,
                             seg_start=None) -> List[int]:
    """
    Given a list of gap timestamps (times of readings after gaps >= min_gap_hours
    within one transmitter segment), return the indices that are most likely real
    sensor change boundaries.

    Rules (in priority order):
    1. Hard upper bound: a session cannot exceed max_sensor_hours (240h for G6).
       Any gap beyond that from the last confirmed boundary is forced as a boundary.
    2. Minimum session: gaps within min_session_hours of the last confirmed boundary
       (or seg_start) are treated as outages and skipped.
       G6: 72h (3 days). G7: 168h (7 days) — G7 TX and sensor are bonded, so any
       gap within a G7 TX is always an outage, never a sensor change.
    3. Valid window: gaps between min_session_hours and max_sensor_hours are accepted.
       Greedy — first valid gap wins.

    seg_start: timestamp of the first reading in the TX segment. Used as the
    initial reference so the first gap is subject to the same MIN_SESSION check
    as all others — not unconditionally accepted.
    """
    if not gap_times:
        return []

    MAX         = pd.Timedelta(hours=max_sensor_hours)
    MIN_SESSION = pd.Timedelta(hours=min_session_hours)

    confirmed        = []
    last_confirmed_t = seg_start   # anchor to segment start, not None

    for i, gap_t in enumerate(gap_times):
        if last_confirmed_t is None:
            # No seg_start provided — fall back to accepting the first gap
            confirmed.append(i)
            last_confirmed_t = gap_t
            continue

        delta = gap_t - last_confirmed_t

        if delta > MAX:
            # Hard constraint: must be a new sensor
            confirmed.append(i)
            last_confirmed_t = gap_t
        elif delta >= MIN_SESSION:
            # Valid wear window — greedy accept
            confirmed.append(i)
            last_confirmed_t = gap_t
        # else: delta < MIN_SESSION — skip as probable outage

    return confirmed


def _infer_sensor_labels(egv: pd.DataFrame, gap_hours: float = 1.5,
                         max_sensor_days: float = 10.0,
                         sensor_type_label: str = "") -> pd.DataFrame:
    """
    Assign sensor labels (S1, S2, ...) based on transmitter ID changes and
    inferred sensor boundaries within each transmitter segment.

    Sensor boundary detection uses a forward-chain validation heuristic:
    - Collect all gaps >= gap_hours within each transmitter segment
    - Validate each gap as a sensor change by checking whether the downstream
      chain produces consistent ~10-day intervals
    - Gaps that cannot be validated into a chain are treated as signal outages
      (not sensor changes) within the same session

    Hard constraint: G6 sensors cannot exceed max_sensor_days (10 days = 240h).
    Any gap beyond that must be a boundary. G7 has a grace period — pass
    max_sensor_days=10.5 for G7.

    Fuzziness: early changes (day 5, 6, 7...) are valid. There is no minimum
    session length — only the 240h maximum is enforced.

    KNOWN LIMITATION: Gap-based sensor session detection is inherently unreliable.
    A gap could be a sensor change, transmitter failure, signal loss, or the user
    being out of range. Reused sensors (second-life wear past 10 days, common with
    hacked G6 extensions) will appear as separate sessions with immediately degraded
    health scores — which is actually correct behavior. The first and last sessions
    in any dataset are always partial and cannot be validated.
    Use --sensor_labels to override when the inferred boundaries are wrong.

    Per-transmitter processing ensures TX changes (unambiguous hardware boundaries)
    are always honored before applying the gap heuristic.
    """
    egv = egv.copy()
    max_sensor_hours = max_sensor_days * 24.0
    # G7: sensor and transmitter are bonded — a gap within one TX is always an outage,
    # never a sensor change. Use a 7-day minimum to prevent false splits.
    # G6: multiple sensors per transmitter; 3-day minimum is appropriate.
    is_g7   = "G7" in sensor_type_label.upper()
    is_libre = "LIBRE" in sensor_type_label.upper()
    is_g6   = "G6" in sensor_type_label.upper()
    min_session_hours = 72.0 if is_g6 else 168.0

    tx_ids_ordered = list(dict.fromkeys(egv["transmitter_id"].tolist()))
    multi_tx = len(tx_ids_ordered) > 1
    tx_counter = {tx: i + 1 for i, tx in enumerate(tx_ids_ordered)}

    # Process each transmitter segment independently
    result_labels = pd.Series(index=egv.index, dtype=str)
    global_sensor_num = 0

    for tx in tx_ids_ordered:
        seg = egv[egv["transmitter_id"] == tx].sort_values("dt")
        if seg.empty:
            continue

        dts = seg["dt"].tolist()

        # Find all gaps >= gap_hours within this segment
        gap_indices = []   # index into dts
        gap_times = []     # timestamp of reading AFTER the gap
        for k in range(1, len(dts)):
            delta_h = (dts[k] - dts[k-1]).total_seconds() / 3600
            if delta_h >= gap_hours:
                gap_indices.append(k)
                gap_times.append(dts[k])

        # Validate which gaps are real sensor changes
        confirmed_gap_positions = set()
        if gap_times:
            seg_start = dts[0]  # TX segment start — reference for first gap
            confirmed_idxs = _find_sensor_boundaries(
                gap_times, max_sensor_hours=max_sensor_hours,
                min_gap_hours=gap_hours,
                min_session_hours=min_session_hours,
                seg_start=seg_start)
            confirmed_gap_positions = {gap_indices[j] for j in confirmed_idxs}

        # Assign sensor labels within this TX segment
        sensor_within_tx = 0
        labels_for_seg = []
        for k in range(len(dts)):
            if k == 0 or k in confirmed_gap_positions:
                sensor_within_tx += 1
                global_sensor_num += 1
            s = sensor_within_tx
            if multi_tx:
                labels_for_seg.append(f"TX{tx_counter[tx]}·S{s}")
            else:
                labels_for_seg.append(f"S{global_sensor_num - sensor_within_tx + s}")

        result_labels.loc[seg.index] = labels_for_seg

    egv["sensor_label"] = result_labels
    return egv


# ═══════════════════════════════════════════════════════════════════════════════
# STATS HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _apply_sensor_label_overrides(egv: pd.DataFrame, sensor_labels_str: str) -> pd.DataFrame:
    """
    Override inferred sensor labels with author-specified date ranges.

    Format: "LABEL:START:END,LABEL:START:END,..."
    Example: "S1:2023-03-02:2023-03-12,S2:2023-03-12:2023-03-16,S3:2023-03-16:2023-03-30"

    Any reading whose date falls within [START, END) gets the specified label.
    Readings not covered by any range keep their inferred label.

    NOTE: This is a kludge to work around the fundamental limitation that
    gap-based sensor session detection is unreliable. Use when you know the
    actual sensor change dates from your own records.
    """
    egv = egv.copy()
    overrides = []
    for part in sensor_labels_str.split(","):
        part = part.strip()
        if not part:
            continue
        pieces = part.split(":")
        if len(pieces) != 3:
            print(f"WARNING: ignoring malformed --sensor_labels entry: {part!r}")
            continue
        label, start_str, end_str = pieces
        try:
            start = pd.Timestamp(start_str).date()
            end   = pd.Timestamp(end_str).date()
            overrides.append((label.strip(), start, end))
        except Exception:
            print(f"WARNING: ignoring unparseable dates in --sensor_labels: {part!r}")
            continue

    if not overrides:
        return egv

    dates = egv["dt"].dt.date
    for label, start, end in overrides:
        mask = (dates >= start) & (dates <= end)  # inclusive end
        egv.loc[mask, "sensor_label"] = label

    return egv

def _tir(glucose: pd.Series) -> Dict[str, float]:
    """Compute Time-in-Range percentages for standard glycaemic bands."""
    n = len(glucose)
    if n == 0:
        return {k: 0.0 for k in ("very_high", "high", "in_range", "low", "very_low")}
    return {
        "very_high":  100 * (glucose > 250).sum() / n,
        "high":       100 * ((glucose > 180) & (glucose <= 250)).sum() / n,
        "in_range":   100 * ((glucose >= 70) & (glucose <= 180)).sum() / n,
        "low":        100 * ((glucose >= 54) & (glucose < 70)).sum() / n,
        "very_low":   100 * (glucose < 54).sum() / n,
    }


def _ea1c(avg_glucose: float) -> float:
    """Estimate HbA1c (%) from mean glucose (mg/dL) using the ADA formula."""
    return (46.7 + avg_glucose) / 28.7


NOCTURNAL_START_HOUR = 22
NOCTURNAL_END_HOUR = 7


def _is_nocturnal_ts(ts) -> bool:
    """Return True when a timestamp falls in the 22:00–06:59 sleep-window proxy."""
    ts = pd.Timestamp(ts)
    return ts.hour >= NOCTURNAL_START_HOUR or ts.hour < NOCTURNAL_END_HOUR


def _build_hypo_rows(hypo_events: List[Dict[str, Any]], include_date: bool = True,
                     bolus_df: "pd.DataFrame | None" = None) -> List[Dict[str, Any]]:
    """Build styled table rows for cluster-linked hypo events."""
    rows = []
    for ev_num, e in enumerate(hypo_events, start=1):
        c = e["cluster"]
        date_str = str(e.get("_date", c.get("_date", "")))[:10]
        cluster_end = pd.Timestamp(c.get("end_wall", c["end"]))
        nadir_time_ts = pd.Timestamp(e["nadir_time"])
        lag_min = max(0, (nadir_time_ts - cluster_end).total_seconds() / 60)
        cluster_date = pd.Timestamp(c.get("_date", c["start"])).date()
        nadir_date   = nadir_time_ts.date()
        time_str = nadir_time_ts.strftime("%H:%M")
        if nadir_date > cluster_date:
            time_str += " +1d"

        # Sum insulin from cluster start → nadir (all boluses acting on bad sensor data)
        insulin_before = None
        if bolus_df is not None and not bolus_df.empty and "insulin" in bolus_df.columns:
            cluster_start = pd.Timestamp(c.get("start_wall", c.get("start", nadir_time_ts)))
            mask = (bolus_df["dt"] >= cluster_start) & (bolus_df["dt"] <= nadir_time_ts)
            total_u = bolus_df.loc[mask, "insulin"].sum()
            insulin_before = f"{total_u:.1f}U" if total_u > 0 else "—"

        rows.append({
            "event_num":      ev_num,
            "date":           date_str[5:] if include_date else "",
            "time":           time_str,
            "lag":            f"{int(lag_min)}m",
            "low_bg":         str(int(round(e["nadir"]))),
            "insulin_before": insulin_before,
            "confidence":     c["confidence"],
            "nocturnal":      _is_nocturnal_ts(nadir_time_ts),
        })
    return rows


def _badge_kwargs(nocturnal: bool) -> Dict[str, Any]:
    """Return matplotlib text bbox kwargs for nocturnal/daytime hypo badges."""
    if nocturnal:
        return dict(facecolor="#111111", edgecolor="#111111", textcolor="white")
    return dict(facecolor="#FFD600", edgecolor="black", textcolor="black")


# ═══════════════════════════════════════════════════════════════════════════════
# DATA PREPARATION — DAILY
# ═══════════════════════════════════════════════════════════════════════════════

def _build_daily_data(
    egv: pd.DataFrame,
    units: str,
    date_str: str,
    sensor_type_label: str = "CGM",
    patient_name: str = "",
    bgm_df: "pd.DataFrame | None" = None,
    bolus_df: "pd.DataFrame | None" = None,
    carb_df: "pd.DataFrame | None" = None,
    show_smb: bool = False,
    hypo_threshold: float = 70.0,
    window_hours: float = 3.0,
    min_confidence: str = "medium",
) -> Dict[str, Any]:
    """Compute all data needed for a daily report."""
    target = pd.Timestamp(date_str).date()
    day = egv[egv["dt"].dt.date == target].copy()
    if len(day) == 0:
        raise ValueError(f"No data found for date {date_str}")

    # Sensor label for the day (use most common)
    sensor_label = day["sensor_label"].mode().iloc[0] if len(day) else "?"

    # Buffer using wall-clock dt — dt_mono is used for detection only.
    # A faulty transmitter counter can run fast (seen at 2× real time), making
    # dt_mono unreliable for window boundaries while still being useful for
    # intra-session gap detection within a single transmitter's readings.
    target_ts  = pd.Timestamp(date_str)
    buf_before = pd.Timedelta(days=1)
    buf_after  = pd.Timedelta(hours=window_hours) + pd.Timedelta(days=1)
    buf_egv = egv[
        (egv["dt"] >= target_ts - buf_before) &
        (egv["dt"] <  target_ts + buf_after)
    ]
    dt_col = "dt"   # wall-clock; see dashboard comment re: TX counter unreliability
    all_c = det.detect_clusters(buf_egv[dt_col], buf_egv["glucose"], profile="g7")
    all_h = det.find_hypo_events(
        buf_egv[dt_col], buf_egv["glucose"],
        hypo_threshold=hypo_threshold,
        window_hours=window_hours,
        min_confidence=min_confidence,
    )
    _cfg = all_c[0].get("config", {}) if all_c else det.DetectorConfig().__dict__
    params_fingerprint = {
        "window_min":      _cfg.get("window_minutes",        30.0),
        "min_reversals":   _cfg.get("min_reversals",          2),
        "incoh_ratio":     _cfg.get("incoh_ratio_thr",       0.35),
        "min_amp_mgdl":    _cfg.get("min_amp",               15.0),
        "spike_bump_mgdl": _cfg.get("spike_bump_delta_mgdl", 40.0),
        "chain_min":       _cfg.get("chain_min_size",         3),
        "merge_gap_min":   30.0,
        "hypo_thr_mgdl":   hypo_threshold,
        "hypo_window_hr":  window_hours,
    }
    # Detection uses wall-clock dt, so cluster start/end are already wall-clock
    def _mono_to_wall(ts):
        return pd.Timestamp(ts)

    def _wall_date(ts):
        return _mono_to_wall(ts).date()

    clusters = [c for c in all_c if _wall_date(c["start"]) == target]
    hypo_events = [e for e in all_h if _wall_date(e["cluster"]["start"]) == target]

    # Attach wall-clock start/end for rendering (detection uses dt_mono)
    for c in clusters:
        c["start_wall"] = _mono_to_wall(c["start"])
        c["end_wall"]   = _mono_to_wall(c["end"])

    # Stats count pre-merge clusters; keeping merge removed so card and chart agree.
    raw_clusters = clusters
    # (30-min display merge previously here — removed: card counts must match chart)

    g = day["glucose"]
    tir = _tir(g)
    avg = float(g.mean())
    sd  = float(g.std())

    visible = [c for c in clusters if c["confidence"] in ("high", "medium")]
    n_high = sum(1 for c in raw_clusters if c["confidence"] == "high")
    n_med  = sum(1 for c in raw_clusters if c["confidence"] == "medium")
    max_amp = max((c["max"] - c["min"] for c in visible), default=0.0)
    total_cluster_min = sum(c["duration_min"] for c in visible)
    crit_min = sum(c["duration_min"] for c in clusters if c["confidence"] == "high")
    elev_min = sum(c["duration_min"] for c in clusters if c["confidence"] == "medium")

    hypo_med = [e for e in hypo_events
                if e["cluster"]["confidence"] in ("medium", "high")]

    # Deduplicate: if two clusters led to the same nadir_time (same hypo episode),
    # keep only the most proximate cluster (shortest lag = most causally relevant).
    seen_nadir: dict = {}
    for e in hypo_med:
        nt = pd.Timestamp(e["nadir_time"])
        c  = e["cluster"]
        cluster_end = pd.Timestamp(c.get("end_wall", c["end"]))
        lag_s = max(0, (nt - cluster_end).total_seconds())
        if nt not in seen_nadir or lag_s < seen_nadir[nt][1]:
            seen_nadir[nt] = (e, lag_s)
    hypo_med = sorted([v[0] for v in seen_nadir.values()],
                      key=lambda e: pd.Timestamp(e["nadir_time"]))

    hypo_rows = _build_hypo_rows(hypo_med, include_date=False, bolus_df=bolus_df)
    n_nocturnal_hypo = sum(1 for r in hypo_rows if r["nocturnal"])
    # Total distinct hypo episodes on this day (readings below threshold, grouped by continuity)
    _hypo_readings = day[day["glucose"] < hypo_threshold]["dt"].sort_values()
    if len(_hypo_readings):
        _gaps = _hypo_readings.diff().dt.total_seconds().fillna(9999)
        n_total_hypo = int((_gaps > 20 * 60).sum()) + 1  # new episode if gap > 20 min
    else:
        n_total_hypo = 0

    # Multi-sensor metadata for this day
    sensors_today = list(day["sensor_label"].unique())
    # Sequential TX labels: extract the "TXn" prefix from sensor_labels (e.g. "TX1·S3" → "TX1")
    # For G6; G7 labels are "TX8·S1" style but TX prefix IS sequential already
    tx_seq_seen = []
    for sl in day["sensor_label"]:
        prefix = sl.split("·")[0] if "·" in sl else sl
        if prefix not in tx_seq_seen:
            tx_seq_seen.append(prefix)
    tx_today = tx_seq_seen if len(tx_seq_seen) > 1 else []
    sensor_labels_col = day["sensor_label"].tolist()

    tx_id_today = day["transmitter_id"].mode().iloc[0] if "transmitter_id" in day.columns else ""
    # Build ordered list of all unique sensors across the full dataset for this TX
    if tx_id_today:
        tx_all = egv[egv["transmitter_id"] == tx_id_today]
        ordered_sensors = list(dict.fromkeys(
            tx_all.sort_values("dt")["sensor_label"].tolist()))
        total_in_tx = len(ordered_sensors)
    else:
        ordered_sensors = list(dict.fromkeys(
            egv.sort_values("dt")["sensor_label"].tolist()))
        total_in_tx = len(ordered_sensors)

    # Positions (1-based) of sensors active today
    today_sensor_nums = []
    for sl in sensors_today:
        try:
            today_sensor_nums.append(ordered_sensors.index(sl) + 1)
        except ValueError:
            today_sensor_nums.append(0)
    today_sensor_nums = sorted(set(n for n in today_sensor_nums if n > 0))

    sensor_context = {
        "tx_id":   tx_id_today,
        "nums":    today_sensor_nums,          # list of 1-based positions
        "total":   total_in_tx,
        "is_g7":   "G7" in sensor_type_label.upper(),
    }

    return {
        "date": date_str,
        "device": "Dexcom CGM",
        "sensor_type_label": sensor_type_label,
        "patient_name": patient_name,
        "sensor": sensor_label,
        "sensors_today": sensors_today,
        "tx_today": tx_today,
        "sensor_labels_col": sensor_labels_col,
        "sensor_context": sensor_context,
        "units": units,
        "n_readings": len(day),
        "readings_dt": day["dt"].tolist(),
        "readings_glucose": g.tolist(),
        "clusters": clusters,
        "hypo_events": hypo_events,
        "hypo_med": hypo_med,
        "hypo_rows": hypo_rows,
        "n_nocturnal_hypo": n_nocturnal_hypo,
        "avg_bg": avg, "sd_bg": sd, "cv_pct": (100.0 * sd / avg if avg > 0 else 0.0), "ea1c": _ea1c(avg),
        "tir_very_high": tir["very_high"], "tir_high": tir["high"],
        "tir_in_range": tir["in_range"], "tir_low": tir["low"],
        "tir_very_low": tir["very_low"],
        "n_high": n_high, "n_med": n_med,
        "crit_min": crit_min, "elev_min": elev_min,
        "max_amp": max_amp, "total_cluster_min": total_cluster_min,
        "params_fingerprint": params_fingerprint,
        "bgm_readings": (
            bgm_df[bgm_df["dt"].dt.date == pd.Timestamp(date_str).date()]
            if bgm_df is not None and len(bgm_df) else pd.DataFrame()
        ),
        "bolus_readings": (
            bolus_df[bolus_df["dt"].dt.date == pd.Timestamp(date_str).date()]
            if bolus_df is not None and len(bolus_df) else pd.DataFrame()
        ),
        "carb_readings": (
            carb_df[carb_df["dt"].dt.date == pd.Timestamp(date_str).date()]
            if carb_df is not None and len(carb_df) else pd.DataFrame()
        ),
        "show_smb":      show_smb,
        "n_total_hypo":  n_total_hypo,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# DATA PREPARATION — DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

def _build_dashboard_data(
    egv: pd.DataFrame,
    units: str,
    sensor_type_label: str = "CGM",
    patient_name: str = "",
    hypo_threshold: float = 70.0,
    window_hours: float = 3.0,
    min_confidence: str = "medium",
) -> Dict[str, Any]:
    """Compute all data needed for a dashboard."""
    from datetime import timedelta as _timedelta
    all_hypo_events = []
    data_dates = sorted(egv["dt"].dt.date.unique())
    # Build date grid: use full calendar for dense data (gaps <= 30 days),
    # but collapse to actual data dates for sparse exports like a Libre "export all"
    # spanning multiple years with long gaps between sessions.
    if data_dates:
        total_span = (data_dates[-1] - data_dates[0]).days + 1
        sparsity   = len(data_dates) / max(total_span, 1)
        if sparsity < 0.25 and total_span > 90:
            # Sparse: >75% of calendar days empty AND span > 3 months
            # Use only actual data dates — avoids 13-page dashboards for sporadic exports
            dates = data_dates
        else:
            # Dense: build full calendar grid so gaps show as empty bars
            dates, _cur = [], data_dates[0]
            while _cur <= data_dates[-1]:
                dates.append(_cur)
                _cur += _timedelta(days=1)
    else:
        dates = []

    # Detection uses wall-clock dt. dt_mono was intended to be DST-immune but
    # G7 transmitter counters can run at wildly incorrect rates (observed 36×
    # real-time on TX3), making dt_mono unreliable. Wall-clock dt with gap
    # masking (gap_threshold_minutes=12) correctly handles transmitter swaps,
    # signal loss, and the 1-hour spring-forward gap.
    dt_col = "dt"

    # Detect on full series — midnight boundaries are no longer split
    all_clusters = det.detect_clusters(egv[dt_col], egv["glucose"], profile="g7")
    all_hypo_events = det.find_hypo_events(
        egv[dt_col], egv["glucose"],
        hypo_threshold=hypo_threshold,
        window_hours=window_hours,
        min_confidence=min_confidence,
    )

    # Capture detection parameters for the transparency fingerprint printed on reports.
    # Reading from the first cluster's stored config ensures the fingerprint reflects
    # any overrides that were actually applied, not just the defaults.
    _cfg = all_clusters[0].get("config", {}) if all_clusters else det.DetectorConfig().__dict__
    params_fingerprint = {
        "window_min":      _cfg.get("window_minutes",        30.0),
        "min_reversals":   _cfg.get("min_reversals",          2),
        "incoh_ratio":     _cfg.get("incoh_ratio_thr",       0.35),
        "min_amp_mgdl":    _cfg.get("min_amp",               15.0),
        "spike_bump_mgdl": _cfg.get("spike_bump_delta_mgdl", 40.0),
        "chain_min":       _cfg.get("chain_min_size",         3),
        "merge_gap_min":   30.0,   # display-layer constant
        "hypo_thr_mgdl":   hypo_threshold,
        "hypo_window_hr":  window_hours,
    }

    # Attribute each cluster to its wall-clock start date for per-day bar chart
    for c in all_clusters:
        c["_date"]      = pd.Timestamp(c["start"]).date()
        c["start_wall"] = pd.Timestamp(c["start"])
        c["end_wall"]   = pd.Timestamp(c["end"])
    for e in all_hypo_events:
        e["_date"] = e["cluster"].get("_date", e["cluster"]["start"].date())

    # Per-day cluster counts and durations
    highs_by_day    = []
    meds_by_day     = []
    crit_min_by_day = []
    elev_min_by_day = []
    dates_str       = []

    for d_date in dates:
        day_clusters = [c for c in all_clusters if c["_date"] == d_date]
        highs_by_day.append(sum(1 for c in day_clusters if c["confidence"] == "high"))
        meds_by_day.append(sum(1 for c in day_clusters if c["confidence"] == "medium"))
        crit_min_by_day.append(sum(c["duration_min"] for c in day_clusters if c["confidence"] == "high"))
        elev_min_by_day.append(sum(c["duration_min"] for c in day_clusters if c["confidence"] == "medium"))
        dates_str.append(str(d_date)[5:])

    # Global stats — computed on actual readings only (not calendar grid)
    g = egv["glucose"]
    tir = _tir(g)
    avg = float(g.mean())
    sd  = float(g.std())
    cv  = 100.0 * sd / avg if avg > 0 else 0.0

    n_high = sum(1 for c in all_clusters if c["confidence"] == "high")
    n_med  = sum(1 for c in all_clusters if c["confidence"] == "medium")

    hypo_med = [e for e in all_hypo_events
                if e["cluster"]["confidence"] in ("medium", "high")]

    # Per-sensor rows — grouped by transmitter with sensor sub-detail
    sensor_rows, sensor_day_ranges = _build_sensor_rows(egv, all_clusters, dates)

    # Hypo event table rows — numbered for circle annotations
    date_index = {d: i for i, d in enumerate(dates)}
    hypo_rows = _build_hypo_rows(hypo_med, include_date=True, bolus_df=None)
    hypo_circles: Dict[int, List[int]] = {}   # date_idx -> [event_nums]
    for row, e in zip(hypo_rows, hypo_med):
        c = e["cluster"]
        ev_num = row["event_num"]
        try:
            d_date = e.get("_date") or c.get("_date")
            if d_date is not None:
                idx = date_index.get(d_date)
                if idx is not None:
                    hypo_circles.setdefault(idx, []).append(ev_num)
        except Exception:
            pass
    n_nocturnal_hypo = sum(1 for r in hypo_rows if r["nocturnal"])

    # Transmitter change indices (grey lines) and full TX/sensor structure
    tx_change_indices = []
    tx_band_ranges = []
    prev_tx = None
    tx_start_idx = 0
    for i, d_date in enumerate(dates):
        day = egv[egv["dt"].dt.date == d_date]
        tx = day["transmitter_id"].mode().iloc[0] if len(day) else None
        if tx and tx != prev_tx:
            if prev_tx is not None:
                tx_change_indices.append(i)
                tx_band_ranges.append((tx_start_idx, i - 1, prev_tx))
            tx_start_idx = i
            prev_tx = tx
    if prev_tx is not None:
        tx_band_ranges.append((tx_start_idx, len(dates) - 1, prev_tx))

    tx_structure, sensor_change_indices = _build_tx_structure(egv, all_clusters, dates)
    is_g7 = "G7" in sensor_type_label

    return {
        "units": units,
        "sensor_type_label": sensor_type_label,
        "patient_name": patient_name,
        "date_range": (f"{pd.Timestamp(dates[0]).strftime('%b %-d %Y')} \u2013 "
                       f"{pd.Timestamp(dates[-1]).strftime('%b %-d %Y')}") if dates else "",
        "n_days": len(data_dates),          # actual days with readings (for stats)
        "n_calendar_days": len(dates),      # full calendar span (for grid)
        "n_sensors": egv["sensor_label"].nunique(),
        "n_readings": len(egv),
        "avg_bg": avg, "sd_bg": sd, "cv_pct": cv, "ea1c": _ea1c(avg),
        "tir_very_high": tir["very_high"], "tir_high": tir["high"],
        "tir_in_range": tir["in_range"], "tir_low": tir["low"],
        "tir_very_low": tir["very_low"],
        "n_high": n_high, "n_med": n_med,
        "n_hypo_events": len(hypo_med),
        "n_nocturnal_hypo": n_nocturnal_hypo,
        "highs_by_day":    highs_by_day,
        "meds_by_day":     meds_by_day,
        "crit_min_by_day": crit_min_by_day,
        "elev_min_by_day": elev_min_by_day,
        "dates_str": dates_str,
        "dates_full": [str(d) for d in dates],
        "sensor_rows": sensor_rows,
        "sensor_day_ranges": sensor_day_ranges,
        "hypo_rows": hypo_rows,
        "hypo_circles": hypo_circles,
        "tx_change_indices": tx_change_indices,
        "tx_band_ranges": tx_band_ranges,
        "tx_structure": tx_structure,
        "sensor_change_indices": sensor_change_indices,
        "params_fingerprint": params_fingerprint,
        "is_g7": is_g7,
    }


def _build_tx_structure(
    egv: pd.DataFrame,
    all_clusters: List[Dict],
    dates: List,
) -> Tuple[List[Dict], List[int]]:
    """
    Build per-transmitter / per-sensor structure for dashboard label area.
    Returns:
      tx_structure: list of dicts, one per transmitter:
        { tx_id, start_idx, end_idx,
          sensors: [{label, start_idx, end_idx, high, med}] }
      sensor_change_indices: date indices where sensor changed within same TX
        (used for green dotted lines; TX changes are handled separately as grey)
    """
    # Cluster counts per sensor_label
    sensor_highs: Dict[str, int] = {}
    sensor_meds:  Dict[str, int] = {}
    for c in all_clusters:
        d = c.get("_date")
        if d is None:
            continue
        row = egv[egv["dt"].dt.date == d]
        if len(row) == 0:
            continue
        lbl = row["sensor_label"].mode().iloc[0]
        if c["confidence"] == "high":
            sensor_highs[lbl] = sensor_highs.get(lbl, 0) + 1
        elif c["confidence"] == "medium":
            sensor_meds[lbl] = sensor_meds.get(lbl, 0) + 1

    tx_struct: List[Dict] = []
    sensor_change_indices: List[int] = []

    cur_tx_id = None
    cur_tx_start = 0
    cur_sensors: List[Dict] = []
    cur_sensor_label = None
    cur_sensor_start = 0
    prev_tx = None
    prev_sensor = None

    def _close_sensor(end_idx):
        if cur_sensor_label is not None:
            cur_sensors.append({
                "label": cur_sensor_label,
                "start_idx": cur_sensor_start,
                "end_idx": end_idx,
                "high": sensor_highs.get(cur_sensor_label, 0),
                "med":  sensor_meds.get(cur_sensor_label, 0),
            })

    def _close_tx(end_idx):
        if cur_tx_id is not None:
            tx_struct.append({
                "tx_id":     cur_tx_id,
                "start_idx": cur_tx_start,
                "end_idx":   end_idx,
                "sensors":   list(cur_sensors),
            })

    # If sensor labels have been overridden (no "·" prefix), treat entire dataset
    # as one logical transmitter — split only on sensor_label changes
    labels_overridden = not any("·" in str(lbl)
                                for lbl in egv["sensor_label"].unique())

    for i, d_date in enumerate(dates):
        day = egv[egv["dt"].dt.date == d_date]
        if len(day) == 0:
            continue
        tx     = "combined" if labels_overridden else day["transmitter_id"].mode().iloc[0]
        sensor = day["sensor_label"].mode().iloc[0]

        if tx != prev_tx:
            # Transmitter change — also closes sensor
            _close_sensor(i - 1)
            _close_tx(i - 1)
            cur_sensors.clear()
            cur_tx_id    = tx
            cur_tx_start = i
            cur_sensor_label = sensor
            cur_sensor_start = i
        elif sensor != prev_sensor:
            # Sensor change within same transmitter
            _close_sensor(i - 1)
            sensor_change_indices.append(i)
            cur_sensor_label = sensor
            cur_sensor_start = i

        prev_tx     = tx
        prev_sensor = sensor

    # Close final sensor and TX
    _close_sensor(len(dates) - 1)
    _close_tx(len(dates) - 1)

    return tx_struct, sensor_change_indices


def _build_sensor_rows(
    egv: pd.DataFrame,
    all_clusters: List[Dict],
    dates: List,
) -> Tuple[List[Dict], List[Tuple[int, int]]]:
    """
    Build per-sensor table rows and day-range spans for the dashboard chart.
    Groups by transmitter; shows sensor sub-detail (indented label).
    """
    # Map each sensor_label to its date range and glucose stats
    sensor_meta: Dict[str, Dict] = {}
    for lbl, grp in egv.groupby("sensor_label"):
        d_min = grp["dt"].dt.date.min()
        d_max = grp["dt"].dt.date.max()
        g = grp["glucose"]
        sensor_meta[lbl] = {
            "d_min": d_min, "d_max": d_max,
            "days": max(1, (d_max - d_min).days + 1),
            "avg": float(g.mean()), "sd": float(g.std()),
            "tx": grp["transmitter_id"].mode().iloc[0],
        }

    # Count clusters per sensor
    sensor_highs: Dict[str, int] = {}
    sensor_meds:  Dict[str, int] = {}
    for c in all_clusters:
        d = c.get("_date")
        if d is None:
            continue
        row = egv[egv["dt"].dt.date == d]
        lbl = row["sensor_label"].mode().iloc[0] if len(row) else None
        if lbl:
            if c["confidence"] == "high":
                sensor_highs[lbl] = sensor_highs.get(lbl, 0) + 1
            elif c["confidence"] == "medium":
                sensor_meds[lbl] = sensor_meds.get(lbl, 0) + 1

    # Sort sensors chronologically
    sorted_labels = sorted(sensor_meta.keys(), key=lambda l: sensor_meta[l]["d_min"])

    # Build rows — insert a transmitter header row when TX changes
    rows = []
    prev_tx = None
    date_list = sorted(dates)
    date_index = {d: i for i, d in enumerate(date_list)}

    sensor_day_ranges = []

    for lbl in sorted_labels:
        m = sensor_meta[lbl]
        tx = m["tx"]
        h = sensor_highs.get(lbl, 0)
        med = sensor_meds.get(lbl, 0)
        days = m["days"]
        hpd = h / days if days > 0 else 0.0

        # Transmitter header row — only when labels use TX-prefixed naming
        # (i.e. not overridden by --sensor_labels which produces clean S1/S2/S3)
        _labels_have_tx_prefix = any("·" in str(l) for l in sorted_labels)
        if _labels_have_tx_prefix and tx != prev_tx:
            rows.append({
                "label": f"TX: {tx}", "dates": "", "days": "",
                "avg": None, "sd": None,
                "high": "", "med": "", "high_per_day": None,
                "is_tx_header": True,
            })
            prev_tx = tx

        rows.append({
            "label": f"  {lbl}", "dates": f"{m['d_min'].strftime('%b %d')}–{m['d_max'].strftime('%b %d')}",
            "days": days, "avg": m["avg"], "sd": m["sd"],
            "high": h, "med": med, "high_per_day": hpd,
            "is_tx_header": False,
        })

        # Day range for bar chart shading
        si = date_index.get(m["d_min"], 0)
        ei = date_index.get(m["d_max"], si)
        sensor_day_ranges.append((si, ei))

    return rows, sensor_day_ranges


# ═══════════════════════════════════════════════════════════════════════════════
# SHARED DRAWING
# ═══════════════════════════════════════════════════════════════════════════════

def _draw_card(
    fig, x: float, y: float, w: float, h: float,
    title: str, rows: List[Tuple[str, str]],
    title_color: str = "#1a237e",
    highlight_border: bool = False,
):
    ax = fig.add_axes([x, y, w, h])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    bc = "#d32f2f" if highlight_border else "#ddd"
    bw = 2.5 if highlight_border else 1.5
    ax.add_patch(FancyBboxPatch(
        (0.02, 0.02), 0.96, 0.96,
        boxstyle="round,pad=0.02",
        facecolor="white", edgecolor=bc, linewidth=bw))
    n = len(rows)
    # Title gets top 18% of card; rows fill the remaining 76% evenly
    title_y = 0.88
    ax.text(0.5, title_y, title, fontsize=10, fontweight="bold",
            ha="center", va="top", color=title_color)
    row_top  = 0.72
    row_bot  = 0.06
    sp = (row_top - row_bot) / max(n, 1)
    for i, (label, value) in enumerate(rows):
        ypos = row_top - sp * 0.5 - i * sp
        ax.text(0.06, ypos, label, fontsize=9, va="center", color="#555")
        val_str = str(value)
        if len(val_str) > 12:
            val_str = val_str[:11] + "…"
        ax.text(0.94, ypos, val_str, fontsize=9, va="center",
                ha="right", fontweight="bold", color="#222")


def _draw_hypo_table(ax, rows: List[Dict[str, Any]], include_date: bool = True, max_rows_per_col: int = 10):
    """Draw a compact alternating-row hypo table with numbered event badges."""
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    if not rows:
        ax.text(0.0, 0.75, "No qualifying events.", fontsize=10,
                va="top", color="#888", style="italic")
        return

    rows = rows[:max_rows_per_col * 2]
    half = -(-len(rows) // 2)
    col_sets = [rows[:half], rows[half:]]
    label2 = "Date" if include_date else "Time"
    has_insulin = any(r.get("insulin_before") is not None for r in rows)

    # Compute h_hdr from the larger (left) column so both columns share the same header height
    max_n_r = len(col_sets[0])
    h_hdr = 1.0 / (max_n_r + 1.0)
    h_row = h_hdr

    for t_rows, t_x0 in zip(col_sets, [0.00, 0.50]):
        if not t_rows:
            continue
        t_w = 0.47
        t_x1 = t_x0 + t_w
        n_r = len(t_rows)

        hdr_bg = plt.Rectangle((t_x0, 1.0 - h_hdr), t_w, h_hdr,
                               facecolor="#dddddd", edgecolor="none",
                               transform=ax.transAxes, zorder=1)
        ax.add_patch(hdr_bg)
        border = plt.Rectangle((t_x0, 1.0 - h_hdr * (n_r + 1)), t_w, h_hdr * (n_r + 1),
                               facecolor="none", edgecolor="#333", linewidth=0.8,
                               transform=ax.transAxes, zorder=4)
        ax.add_patch(border)

        # Column definitions: (label, fractional_left, fractional_width, data_ha)
        # Fractions are of t_w. Data padding: center for #, left+small pad for others.
        if has_insulin:
            col_defs = [
                ("#",       0.000, 0.110, "center"),
                (label2,    0.110, 0.270, "left"),
                ("Lag",     0.380, 0.160, "left"),
                ("Low BG",  0.540, 0.210, "left"),
                ("Insulin", 0.750, 0.250, "left"),
            ]
        else:
            col_defs = [
                ("#",      0.000, 0.120, "center"),
                (label2,   0.120, 0.330, "left"),
                ("Lag",    0.450, 0.210, "left"),
                ("Low BG", 0.660, 0.340, "left"),
            ]

        # Draw headers — centered within each cell
        hdr_y_center = 1.0 - h_hdr * 0.5
        for lbl, frac_l, frac_w, _ in col_defs:
            cell_x = t_x0 + frac_l * t_w
            cell_cx = t_x0 + (frac_l + frac_w * 0.5) * t_w
            # Cell border
            ax.add_patch(plt.Rectangle((cell_x, 1.0 - h_hdr), frac_w * t_w, h_hdr,
                         facecolor="none", edgecolor="#333", linewidth=0.8,
                         transform=ax.transAxes, zorder=5))
            ax.text(cell_cx, hdr_y_center, lbl, fontsize=8, fontweight="bold",
                    color="#222", ha="center", va="center", zorder=6)

        # Draw data rows
        row_colors = ["#ffffff", "#dbeeff"]
        data_keys = ["event_num", "date" if include_date else "time",
                     "lag", "low_bg"] + (["insulin_before"] if has_insulin else [])
        data_colors = ["#111", "#111", "#111", "#b71c1c"] + (["#00838f"] if has_insulin else [])
        data_bold   = [False, False, False, True] + ([True] if has_insulin else [])

        for r_i, row in enumerate(t_rows):
            y_top = 1.0 - h_hdr * (r_i + 1)
            y_bot = y_top - h_row
            y_ctr = (y_top + y_bot) / 2
            bg = plt.Rectangle((t_x0, y_bot), t_w, h_row,
                               facecolor=row_colors[r_i % 2], edgecolor="none",
                               transform=ax.transAxes, zorder=1)
            ax.add_patch(bg)
            ax.plot([t_x0, t_x1], [y_bot, y_bot], color="#aaaaaa", linewidth=0.5, zorder=3)

            for (lbl, frac_l, frac_w, d_ha), key, col, bold in \
                    zip(col_defs, data_keys, data_colors, data_bold):
                cell_x = t_x0 + frac_l * t_w
                # Cell border
                ax.add_patch(plt.Rectangle((cell_x, y_bot), frac_w * t_w, h_row,
                             facecolor="none", edgecolor="#aaa", linewidth=0.5,
                             transform=ax.transAxes, zorder=4))
                if key == "event_num":
                    # Badge centered in cell
                    cell_cx = t_x0 + (frac_l + frac_w * 0.5) * t_w
                    badge = _badge_kwargs(row.get("nocturnal", False))
                    ax.text(cell_cx, y_ctr, str(row["event_num"]),
                            ha="center", va="center", fontsize=6.5, fontweight="bold",
                            color=badge["textcolor"], zorder=6,
                            bbox=dict(boxstyle="circle,pad=0.22",
                                      facecolor=badge["facecolor"],
                                      edgecolor=badge["edgecolor"],
                                      linewidth=1.1))
                else:
                    val = row.get(key, "—") or "—"
                    cell_cx = t_x0 + (frac_l + frac_w * 0.5) * t_w
                    ax.text(cell_cx, y_ctr, val,
                            fontsize=7.5, va="center", ha="center",
                            color=col, fontweight="bold" if bold else "normal",
                            zorder=5)


# ═══════════════════════════════════════════════════════════════════════════════
# DAILY REPORT
# ═══════════════════════════════════════════════════════════════════════════════

def _generate_bullets(d: Dict) -> List[str]:
    """Qualitative bullet points — no card-redundant stats."""
    clusters = d["clusters"]
    hypo_events = d["hypo_events"]

    chain_promoted = sum(1 for c in clusters if c.get("debug", {}).get("chain_promoted", False))
    n_crit = d["n_high"]
    n_elev = d["n_med"]
    visible = [c for c in clusters if c["confidence"] in ("high", "medium")]

    bullets = []

    # Temporal / severity story
    if chain_promoted >= 8:
        bullets.append("Sensor produced unreliable data nearly continuously throughout the day")
    elif chain_promoted >= 4:
        cc = [c for c in visible if c.get("debug", {}).get("chain_promoted", False)]
        if cc:
            earliest = min(c.get("start_wall", c["start"]) for c in cc)
            latest   = max(c.get("end_wall",   c["end"])   for c in cc)
            bullets.append(
                f"A dense chain of clusters from {earliest.strftime('%H:%M')}–"
                f"{latest.strftime('%H:%M')} indicates sustained sensor unreliability")
    elif n_crit + n_elev > 3:
        bullets.append(f"Multiple noisy stretches detected — {n_crit} critical, {n_elev} elevated")
    elif n_crit > 0:
        worst = max((c for c in clusters if c["confidence"] == "high"),
                    key=lambda c: c["max"] - c["min"])
        ws = worst.get("start_wall", worst["start"])
        we = worst.get("end_wall",   worst["end"])
        bullets.append(
            f"Most severe cluster ran {ws.strftime('%H:%M')}–"
            f"{we.strftime('%H:%M')} with amplitude {worst['max'] - worst['min']:.0f}")
    elif n_elev > 0:
        bullets.append(f"{n_elev} elevated cluster{'s' if n_elev > 1 else ''} detected — moderate sensor noise")
    else:
        bullets.append("No elevated or critical clusters — a clean day")

    # Hypo events (medium+ clusters only)
    hypo_med = [e for e in hypo_events
                if e["cluster"]["confidence"] in ("medium", "high")]
    nocturnal_n = sum(1 for e in hypo_med if _is_nocturnal_ts(e["nadir_time"]))
    if hypo_med:
        if nocturnal_n > 0:
            bullets.append(
                f"{len(hypo_med)} cluster-preceded hypoglycemic events detected within 3 hours; {nocturnal_n} fell in the 22:00–07:00 nocturnal window")
        else:
            bullets.append(
                f"{len(hypo_med)} cluster-preceded hypoglycemic events detected within the 3-hour window")
    else:
        bullets.append("No cluster-preceded hypoglycemic events within the 3-hour window")

    return bullets


def render_daily_report(d: Dict, output_file: str):
    """Render a daily CGM report PNG — fixed 8.5×11 page, layout mirrors dashboard."""
    timestamps = pd.Series(pd.to_datetime(d["readings_dt"]))
    glucose    = pd.Series(d["readings_glucose"])
    clusters   = d["clusters"]
    units      = d["units"]
    hypo_med   = d["hypo_med"]
    hypo_rows  = d.get("hypo_rows", [])
    has_hypo   = len(hypo_med) > 0
    n_nocturnal_hypo = d.get("n_nocturnal_hypo", 0)

    fig = plt.figure(figsize=(8.5, 11))
    fig.patch.set_facecolor("#fafafa")

    # ── Header ────────────────────────────────────────────────────────────────
    HDR_TOP = 0.980
    fig.text(0.5, HDR_TOP,
             f"CGM Sensor Integrity Daily Report  —  {d['date']}",
             fontsize=16, fontweight="bold", ha="center", va="top", color="#1a237e")
    patient_name = d.get("patient_name", "")
    tx_id_for_name = d.get("sensor_context", {}).get("tx_id", "")
    if patient_name or tx_id_for_name:
        _name_parts = []
        if patient_name:
            _name_parts.append(patient_name)
        if tx_id_for_name and tx_id_for_name not in ("Unknown", ""):
            # Pump serial numbers are all-numeric; CGM tx IDs are alphanumeric
            prefix = "Pump" if tx_id_for_name.isdigit() else "ID"
            _name_parts.append(f"{prefix}: {tx_id_for_name}")
        fig.text(0.5, HDR_TOP - 0.030,
                 "  \u2022  ".join(_name_parts),
                 fontsize=13, fontweight="bold", ha="center", va="top", color="#000000")

    # ── Cards — identical positions/sizes to dashboard ────────────────────────
    CARD_Y  = 0.78   # title at 0.990, name at 0.962, cards need to clear 0.932
    CARD_H  = 0.13
    _draw_card(fig, 0.03, CARD_Y, 0.22, CARD_H, "Glucose Stats", [
        ("Average",  f"{d['avg_bg']:.1f}"),
        ("Std Dev",  f"{d['sd_bg']:.1f}"),
        ("CV%",      f"{d['cv_pct']:.1f}%"),
        ("eA1c",     f"{d['ea1c']:.1f}%")])
    _draw_card(fig, 0.27, CARD_Y, 0.22, CARD_H, "Time in Range", [
        (">250",    f"{d['tir_very_high']:.1f}%"),
        ("181–250", f"{d['tir_high']:.1f}%"),
        ("70–180",  f"{d['tir_in_range']:.1f}%"),
        ("54–69",   f"{d['tir_low']:.1f}%"),
        ("<54",     f"{d['tir_very_low']:.1f}%")])
    _draw_card(fig, 0.51, CARD_Y, 0.22, CARD_H, "Clusters", [
        ("Critical", f"{d['n_high']} ({d['crit_min']:.0f} min)"),
        ("Elevated", f"{d['n_med']} ({d['elev_min']:.0f} min)"),
        ("Total",    f"{d['n_high'] + d['n_med']}"),
        ("Per Day",  f"{d['n_high'] + d['n_med']}")])
    # Compute total daily insulin from bolus_readings
    _bolus_day = d.get("bolus_readings", pd.DataFrame())
    _total_insulin_str = ""
    if not _bolus_day.empty and "insulin" in _bolus_day.columns:
        _total_u = _bolus_day["insulin"].sum()
        _total_insulin_str = f"{_total_u:.1f} U"

    _n_readings = len(d.get("readings_dt", []))
    _pct_day = f"{_n_readings / 288 * 100:.0f}% of day" if _n_readings else "—"
    _device_label = d["sensor_type_label"]
    if len(_device_label) > 22:
        _device_label = _device_label[:20] + "…"
    _ds_rows = [
        ("Device",   _device_label),
        ("Readings", f"{_n_readings}"),
        ("Coverage", _pct_day)]
    if _total_insulin_str:
        _ds_rows.append(("Insulin", _total_insulin_str))
    _draw_card(fig, 0.75, CARD_Y, 0.22, CARD_H, "Data Source", _ds_rows)

    # ── "Sensor Integrity" header + cluster legend — same as dashboard ────────
    CARD_GAP   = 0.008
    HEADER_H   = 0.028
    HEADER_GAP = 0.004
    header_y   = CARD_Y - CARD_GAP - HEADER_H

    ax_hdr = fig.add_axes([0.09, header_y, 0.87, HEADER_H])
    ax_hdr.set_xlim(0, 1); ax_hdr.set_ylim(0, 1); ax_hdr.axis("off")
    ax_hdr.text(0.0, 0.5, "Sensor Integrity",
                fontsize=12, fontweight="bold", va="center", color="#1a237e")
    from matplotlib.patches import Patch as _Patch
    from matplotlib.lines import Line2D as _Line2D_hdr
    bgm_handle = _Line2D_hdr([0], [0], marker="o", color="w",
                              markerfacecolor="white", markeredgecolor="black",
                              markeredgewidth=2, markersize=9, label="BGM")
    _legend_handles = [
        _Patch(facecolor="#d32f2f", alpha=0.85, label="Critical"),
        _Patch(facecolor="#f9a825", alpha=0.85, label="Elevated"),
        bgm_handle]
    ax_hdr.legend(handles=_legend_handles,
        loc="center right", fontsize=8.5, frameon=True, framealpha=0.85,
        ncol=len(_legend_handles), handlelength=1.2, handleheight=0.9,
        borderpad=0.4, columnspacing=0.8)

    # ── Sensor label row ──────────────────────────────────────────────────────
    ROW_H     = 0.030
    label_top = header_y - HEADER_GAP
    label_bot = label_top - ROW_H

    ax_lbl = fig.add_axes([0.09, label_bot, 0.87, ROW_H])
    ax_lbl.set_xlim(0, 1); ax_lbl.set_ylim(0, 1); ax_lbl.axis("off")
    sensors_today = d.get("sensors_today", [d["sensor"]])
    tx_today      = d.get("tx_today", [])
    sc = d.get("sensor_context", {})
    if sc:
        nums   = sc.get("nums", [])
        total  = sc.get("total", 1)
        tx_id  = sc.get("tx_id", "")
        is_g7  = sc.get("is_g7", False)
        is_g6  = "G6" in d.get("sensor_type_label", "").upper()
        if is_g7:
            lbl_text = f"Sensor: {tx_id}" if tx_id else sensors_today[0]
        elif len(nums) > 1:
            nums_str = " and ".join(str(n) for n in nums)
            if is_g6 and tx_id:
                lbl_text = f"Sensors {nums_str} of {total}  \u2022  Transmitter: {tx_id}"
            elif tx_id:
                lbl_text = f"Sensors {nums_str} of {total}  \u2022  Pump: {tx_id}"
            else:
                lbl_text = f"Sensors {nums_str} of {total}"
        elif nums:
            if is_g6 and tx_id:
                lbl_text = f"Sensor {nums[0]} of {total}  \u2022  Transmitter: {tx_id}"
            elif tx_id:
                lbl_text = f"Sensor {nums[0]} of {total}  \u2022  Pump: {tx_id}"
            else:
                lbl_text = f"Sensor {nums[0]} of {total}"
        else:
            lbl_text = sensors_today[0]
    else:
        sensor_str = " \u2192 ".join(sensors_today) if len(sensors_today) > 1 else sensors_today[0]
        tx_str     = "  \u2022  TX: " + " \u2192 ".join(tx_today) if tx_today else ""
        lbl_text   = f"{sensor_str}{tx_str}"
    ax_lbl.text(0.5, 0.5, lbl_text,
                fontsize=9, ha="center", va="center", color="#333",
                fontweight="bold")

    # ── Scatter plot ──────────────────────────────────────────────────────────
    CHART_TOP     = label_bot
    HYPO_HDR_H    = 0.055
    HYPO_ROW_H    = 0.020
    HYPO_GAP      = 0.028
    FOOTER_H      = 0.030

    n_hypo        = min(len(hypo_rows), 12)
    rows_per_col  = max(1, -(-n_hypo // 2))
    hypo_tbl_h    = 0.030 + rows_per_col * HYPO_ROW_H
    CHART_BOT     = FOOTER_H + HYPO_GAP + HYPO_HDR_H + hypo_tbl_h + 0.010
    chart_h       = min(CHART_TOP - CHART_BOT, 0.38)   # cap at 38% of page height
    # If capped, float chart from top (more natural than stretching from bottom)
    CHART_BOT     = CHART_TOP - chart_h

    # Tiered y ceiling: 200 → 300 → 400 (matches Sugarmate convention)
    _gmax = float(glucose.max())
    _yceil = 200 if _gmax <= 200 else (300 if _gmax <= 300 else 400)

    # Carb zone sits ABOVE the CGM chart — extend ceiling to make room
    _CARB_ZONE_H = 40
    _carb_for_check = d.get("carb_readings", pd.DataFrame())
    _has_carbs = not _carb_for_check.empty and "carbs" in _carb_for_check.columns
    if _has_carbs:
        _yceil_cgm = _yceil          # CGM data ceiling
        _yceil     = _yceil + _CARB_ZONE_H  # extended axis ceiling
    else:
        _yceil_cgm = _yceil

    ax = fig.add_axes([0.09, CHART_BOT, 0.87, chart_h])

    ax.scatter(timestamps, glucose, s=12, color="#1565c0", zorder=4, alpha=0.7)

    # BGM / fingerstick readings — black circle, white interior, 2px border
    # Readings above the y ceiling are clamped and labeled with their actual value
    bgm_readings = d.get("bgm_readings", pd.DataFrame())
    if not bgm_readings.empty:
        bgm_day = bgm_readings[bgm_readings["dt"].dt.date == pd.Timestamp(d["date"]).date()].copy()
        if not bgm_day.empty:
            bgm_high = bgm_day[bgm_day["glucose"] > _yceil]
            bgm_plot = bgm_day.copy()
            bgm_plot["glucose"] = bgm_plot["glucose"].clip(upper=_yceil - 5)
            ax.scatter(bgm_plot["dt"], bgm_plot["glucose"],
                       s=80, color="white", edgecolors="black",
                       linewidths=2, zorder=6, marker="o")
            for _, row in bgm_high.iterrows():
                ax.text(row["dt"], _yceil - 3, f"{int(row['glucose'])}",
                        fontsize=6.5, ha="center", va="bottom",
                        color="black", fontweight="bold", zorder=7)

    sensor_labels_col = d.get("sensor_labels_col", None)
    if sensor_labels_col and len(sensors_today) > 1:
        sl_series = pd.Series(sensor_labels_col)
        change_indices = [i for i in range(1, len(sl_series))
                          if sl_series.iloc[i] != sl_series.iloc[i-1]]
        for ci in change_indices:
            change_ts   = timestamps.iloc[ci]
            right_label = sl_series.iloc[ci]
            left_label  = sl_series.iloc[ci - 1]
            ax.axvline(change_ts, color="#2e7d32", linewidth=1.5, linestyle="--", zorder=5)
            for label, side, pad in [(right_label, "left", 15), (left_label, "right", -15)]:
                ax.text(change_ts + pd.Timedelta(minutes=pad), 0.96, label,
                        fontsize=8, color="#1b5e20", ha=side, va="top",
                        transform=ax.get_xaxis_transform(),
                        bbox=dict(boxstyle="round,pad=0.25", facecolor="white",
                                  edgecolor="#2e7d32", linewidth=1.0, alpha=0.95))

    ax.axhline(70,  linestyle="--", color="gray", linewidth=1)
    ax.axhline(180, linestyle="--", color="gray", linewidth=1)

    for c in clusters:
        if c["confidence"] not in ("high", "medium"):
            continue
        cs = c.get("start_wall", c["start"])
        ce = c.get("end_wall",   c["end"])
        ax.add_patch(Rectangle(
            (mdates.date2num(cs), c["min"]),
            mdates.date2num(ce) - mdates.date2num(cs),
            max(1.0, c["max"] - c["min"]),
            fill=False, linewidth=2,
            edgecolor=DISPLAY_COLOR[c["confidence"]]))

    for row, e in zip(hypo_rows, hypo_med):
        nt = pd.Timestamp(e["nadir_time"])
        if nt.date() != pd.Timestamp(d["date"]).date():
            continue
        badge = _badge_kwargs(row.get("nocturnal", False))
        nadir_val = float(e["nadir"])
        ax.text(nt, nadir_val - 8, str(row["event_num"]),
                ha="center", va="top", fontsize=13, fontweight="bold",
                color=badge["textcolor"], zorder=8, clip_on=False,
                bbox=dict(boxstyle="circle,pad=0.30",
                          facecolor=badge["facecolor"], edgecolor=badge["edgecolor"],
                          linewidth=1.5))

    day_start = pd.Timestamp(d["date"])
    ax.set_xlim(day_start, day_start + pd.Timedelta(hours=24))
    ax.set_ylim(0, _yceil)
    # Suppress the 0 tick and any ticks inside the carb zone
    _tick_max = _yceil_cgm if _has_carbs else _yceil
    ax.set_yticks([t for t in ax.get_yticks() if 50 <= t <= _tick_max])
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=2))

    # Insulin zone: only rendered if bolus data is present
    _bolus_for_zone = d.get("bolus_readings", pd.DataFrame())
    if not _bolus_for_zone.empty:
        _insulin_zone_top = 40
        ax.axhspan(0, _insulin_zone_top, facecolor="#e8e8e8", alpha=0.55,
                   zorder=1, linewidth=0)
        ax.text(-0.01, _insulin_zone_top * 0.5, "Insulin",
                fontsize=8.5, color="#333333", ha="right", va="center",
                rotation=90, transform=ax.get_yaxis_transform(), zorder=2)

    # Carb zone: stalactites hanging from top of chart
    _carb_for_zone = d.get("carb_readings", pd.DataFrame())
    if not _carb_for_zone.empty and "carbs" in _carb_for_zone.columns:
        _carb_zone_bot = _yceil_cgm
        ax.axhspan(_carb_zone_bot, _yceil, facecolor="#e8e8e8", alpha=0.55,
                   zorder=1, linewidth=0)
        ax.text(-0.01, _carb_zone_bot + (_yceil - _carb_zone_bot) * 0.5, "Carbs",
                fontsize=8.5, color="#333333", ha="right", va="center",
                rotation=90, transform=ax.get_yaxis_transform(), zorder=2)
        # Stalactites — dark amber/yellow bars hanging DOWN from ceiling
        _carb_day = _carb_for_zone.copy()
        _max_carbs = _carb_day["carbs"].max() if not _carb_day.empty else 1.0
        CARB_SCALE = 36.0 / max(_max_carbs, 1.0)  # max carb reaches 36 of 40-unit zone
        for _, row in _carb_day.iterrows():
            carb_g = float(row["carbs"])
            if carb_g <= 0:
                continue
            bar_h = max(carb_g * CARB_SCALE, 2)
            ax.bar(row["dt"], bar_h, width=pd.Timedelta(minutes=5),
                   bottom=_yceil - bar_h, color="#F9A825", edgecolor="#F57F17",
                   linewidth=0.6, zorder=7, align="center")
            ax.text(row["dt"], _yceil - bar_h - 1.5, f'{int(carb_g)}g',
                    fontsize=6.5, fontweight="bold",
                    ha="center", va="top", color="#E65100", zorder=8)

    # Bolus overlay — vertical bars rising from x-axis
    # Bar height = units * BOLUS_SCALE (so max ~6U reaches ~40 on glucose y-axis)
    # Meal boluses:       magenta bars with unit label on top
    # Manual corrections: medium purple bars with unit label on top
    # SMBs:               small green bars, no label, hidden unless --show_smb
    bolus_readings = d.get("bolus_readings", pd.DataFrame())
    show_smb       = d.get("show_smb", False)
    if not bolus_readings.empty:
        bl_day = bolus_readings.copy()
        if "dt" in bl_day.columns:
            bl_day = bl_day[bl_day["dt"].dt.date == pd.Timestamp(d["date"]).date()]
        if not bl_day.empty:
            _max_dose = bl_day["insulin"].max() if not bl_day.empty else 1.0
            BOLUS_SCALE = (_insulin_zone_top - 2) / max(_max_dose, 1.0)

            crit_windows = [(pd.Timestamp(c["start_wall"]), pd.Timestamp(c["end_wall"]))
                            for c in d.get("clusters", []) if c["confidence"] == "high"]
            elev_windows = [(pd.Timestamp(c["start_wall"]), pd.Timestamp(c["end_wall"]))
                            for c in d.get("clusters", []) if c["confidence"] == "medium"]

            def _bcolor(ts):
                for s, e in crit_windows:
                    if s <= ts <= e: return "#d32f2f", "#b71c1c"
                for s, e in elev_windows:
                    if s <= ts <= e: return "#f57c00", "#e65100"
                return None, None

            def _draw_bolus_bar(ts, units_val, fc, ec, label=None, width_min=4):
                bar_h = max(units_val * BOLUS_SCALE, 2)
                ax.bar(ts, bar_h, width=pd.Timedelta(minutes=width_min),
                       bottom=0, color=fc, edgecolor=ec, linewidth=0.6,
                       zorder=7, align="center")
                if label:
                    ax.text(ts, bar_h + 1.5, label,
                            fontsize=6.5, fontweight="bold",
                            ha="center", va="bottom", color=ec, zorder=8)

            smb  = bl_day[bl_day["is_smb"]] if "is_smb" in bl_day.columns else pd.DataFrame()
            user = bl_day[~bl_day["is_smb"]] if "is_smb" in bl_day.columns else bl_day

            # SMBs — small green bars, shown only if show_smb
            if show_smb:
                for _, row in smb.iterrows() if not smb.empty else []:
                    fc, ec = _bcolor(row["dt"])
                    _draw_bolus_bar(row["dt"], row.get("insulin", 0),
                                    fc=fc or "#81c784", ec=fc or "#388e3c",
                                    width_min=3)

            # User boluses (meal + correction combined) — teal bars with label
            for _, row in user.iterrows() if not user.empty else []:
                fc, ec = _bcolor(row["dt"])
                u = row.get("insulin", 0)
                lbl = str(int(u)) if u == int(u) else f"{u:.1f}"
                _draw_bolus_bar(row["dt"], u,
                                fc=fc or "#4dd0e1", ec=fc or "#00838f",
                                label=lbl, width_min=5)
    ax.xaxis.set_minor_locator(mdates.HourLocator(interval=1))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.set_xlabel("Time", fontsize=12, fontweight="bold")
    ax.set_ylabel(f"Glucose ({units})", fontsize=12, fontweight="bold")
    ax.tick_params(axis="both", labelsize=10)
    ax.grid(True, alpha=0.12)

    # ── Hypo section — same structure as dashboard ────────────────────────────
    # Divider sits below the x-axis tick labels (~0.048 below chart bottom)
    XTICK_OVERFLOW = 0.048
    div_y = CHART_BOT - XTICK_OVERFLOW - 0.008
    ax_div = fig.add_axes([0.06, div_y, 0.91, 0.001])
    ax_div.set_xlim(0, 1); ax_div.set_ylim(0, 1); ax_div.axis("off")
    ax_div.add_patch(plt.Rectangle((0, 0), 1, 1, facecolor="#bbbbbb",
                                   edgecolor="none", transform=ax_div.transAxes))

    title_y = div_y - 0.018
    fig.text(0.06, title_y,
             "Hypoglycemia Events that Occur After Clusters",
             fontsize=11, fontweight="bold", color="#c62828", va="top")
    _n_total_hypo  = d.get("n_total_hypo", len(hypo_med))
    _n_linked_hypo = len(hypo_med)
    fig.text(0.06, title_y - 0.018,
             f"Total hypos: {_n_total_hypo}  \u2022  Linked to clusters: {_n_linked_hypo}",
             fontsize=8, color="#444", va="top")

    # Badge legend — right-aligned on same line as title
    from matplotlib.lines import Line2D as _Line2D_badge
    _day_h = _Line2D_badge([0], [0], marker="o", color="w", markerfacecolor="#FFD600",
                           markeredgecolor="black", markeredgewidth=1.1,
                           markersize=8, label="Daytime")
    _noc_h = _Line2D_badge([0], [0], marker="o", color="w", markerfacecolor="#111111",
                           markeredgecolor="#111111", markeredgewidth=1.1,
                           markersize=8, label="Nocturnal (22:00–07:00)")
    ax_badge = fig.add_axes([0.50, title_y - 0.028, 0.47, 0.022])
    ax_badge.set_xlim(0, 1); ax_badge.set_ylim(0, 1); ax_badge.axis("off")
    ax_badge.legend(handles=[_day_h, _noc_h], loc="center right",
                    fontsize=7.5, frameon=False, ncol=2,
                    handletextpad=0.4, columnspacing=1.2, borderpad=0)

    hypo_tbl_top = title_y - 0.050
    ax_h = fig.add_axes([0.06, hypo_tbl_top - hypo_tbl_h, 0.91, hypo_tbl_h])
    _draw_hypo_table(ax_h, hypo_rows, include_date=False, max_rows_per_col=6)

    # ── Footer ────────────────────────────────────────────────────────────────
    fig.text(0.06, 0.012, "CGM Sensor Integrity Detector v6",
             fontsize=7.5, ha="left", va="bottom", color="#888", style="italic")
    fig.text(0.5, 0.012,
             "danheller.substack.com/p/the-cgm-patent-that-could-save-lives",
             fontsize=7.5, ha="center", va="bottom", color="#888", style="italic")
    fig.text(0.94, 0.012, "Page 1 of 1",
             fontsize=11, ha="right", va="bottom", color="#000", fontweight="bold")

    plt.savefig(output_file, dpi=150, facecolor="#fafafa")
    plt.close()
    print(f"Saved: {output_file}")


# ═══════════════════════════════════════════════════════════════════════════════
# DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════



def _page_has_data(d: Dict, page: int) -> bool:
    """Return True if this page slice has at least one non-zero cluster bar."""
    start = page * PAGE_SIZE
    n     = len(d["dates_str"])
    if start >= n:
        return False
    end = min(start + PAGE_SIZE, n)
    return any(
        d["highs_by_day"][i] > 0 or d["meds_by_day"][i] > 0
        for i in range(start, end)
    )


def _data_pages(d: Dict) -> List[int]:
    """Return sorted list of page indices that have at least one cluster bar."""
    n_pages = -(-len(d["dates_str"]) // PAGE_SIZE)
    return [p for p in range(n_pages) if _page_has_data(d, p)]


# ── Summary dashboard layout constants (inches, fixed) ────────────────────────
_SUM_PAGE_W      = 8.5
_SUM_PAGE_H      = 11.0
_SUM_MARGIN      = 0.28   # top & bottom
_SUM_HDR_H       = 0.50   # title + subtitle
_SUM_CARDS_H     = 1.15   # global stats card row (first page only)
_SUM_CARDS_GAP   = 0.14
_SUM_STRIP_LABEL = 0.22   # date-range label bar per strip
_SUM_STRIP_CHART = 1.40   # bar chart height per strip (sensor label row carved from this)
_SUM_STRIP_GAP   = 0.45   # gap between strips — must fit rotated x-tick labels (~0.25) + breathing room
_SUM_FP_H        = 0.22   # params fingerprint at bottom
_SUM_STRIP_TOTAL = _SUM_STRIP_LABEL + _SUM_STRIP_CHART + _SUM_STRIP_GAP

# Strips per page — computed once at module level for consistency
def _sum_strips_per_page(first: bool) -> int:
    """Return number of sensor strips per summary page (first page has less room)."""
    overhead = (_SUM_MARGIN + _SUM_HDR_H
                + (_SUM_CARDS_H + _SUM_CARDS_GAP if first else 0)
                + _SUM_FP_H + _SUM_MARGIN)
    available = _SUM_PAGE_H - overhead
    return max(1, int(available / _SUM_STRIP_TOTAL))


def _render_summary_bar_chart(fig, pdata: dict,
                               left: float, bottom: float,
                               width: float, height: float) -> None:
    """
    Render one cluster bar chart strip onto fig at the given axes coordinates.
    Used by both render_dashboard_summary and render_multi_sensor_summary
    so the two share identical bar chart logic.
    """
    from matplotlib.ticker import MaxNLocator
    ax = fig.add_axes([left, bottom, width, height])
    ax.set_xlim(-0.5, PAGE_SIZE - 0.5)
    ax.set_facecolor("#f9f9f9")

    x = range(PAGE_SIZE)
    ax.bar(x, pdata["highs_by_day"], color="#d32f2f", alpha=0.85, width=0.8)
    ax.bar(x, pdata["meds_by_day"],  bottom=pdata["highs_by_day"],
           color="#f9a825", alpha=0.85, width=0.8)

    ax.set_ylim(0, 12)
    ax.set_ylabel("Clusters", fontsize=7, labelpad=3)
    ax.set_xlabel("Date",     fontsize=7, labelpad=3)
    ax.yaxis.set_major_locator(MaxNLocator(integer=True, nbins=3))
    ax.tick_params(axis="y", labelsize=6)
    ax.tick_params(axis="x", labelsize=5.5)
    ax.grid(True, axis="y", alpha=0.15)
    ax.set_facecolor("white")

    # Sensor health shading — light fill, not solid
    for tx in pdata.get("tx_structure", []):
        for s in tx["sensors"]:
            _dur      = max(1, s["end_idx"] - s["start_idx"] + 1)
            _crit_m   = sum(pdata.get("crit_min_by_day", [0]*PAGE_SIZE)
                            [s["start_idx"]:s["end_idx"]+1])
            _elev_m   = sum(pdata.get("elev_min_by_day", [0]*PAGE_SIZE)
                            [s["start_idx"]:s["end_idx"]+1])
            _ft       = sensor_contamination_tier(_crit_m, _elev_m, _dur * MINUTES_PER_DAY)
            ax.axvspan(s["start_idx"] - 0.5, s["end_idx"] + 0.5,
                       alpha=0.15, color=TIER_SOLID[_ft], zorder=0)

    # TX alternating shading
    for ti, tx in enumerate(pdata.get("tx_structure", [])):
        ax.axvspan(tx["start_idx"] - 0.5, tx["end_idx"] + 0.5,
                   alpha=0.07, color=COLORS_POOL[ti % len(COLORS_POOL)])

    # Sensor change divider lines
    all_sc = list(pdata.get("sensor_change_indices", []))
    for tx in pdata.get("tx_structure", []):
        if tx["start_idx"] > 0:
            all_sc.append(tx["start_idx"])
    for xi in sorted(set(all_sc)):
        ax.axvline(xi - 0.5, color="#2e7d32", linewidth=0.8,
                   linestyle=(0, (4, 3)), zorder=5)

    # Sparse x-tick labels
    step = max(1, PAGE_SIZE // 12)
    tick_pos = [i for i in range(0, PAGE_SIZE, step) if pdata["dates_str"][i]]
    ax.set_xticks(tick_pos)
    ax.set_xticklabels([pdata["dates_str"][i] for i in tick_pos],
                       rotation=40, ha="right", fontsize=5.5)


def render_dashboard_summary(d: Dict, base_path: str) -> List[str]:
    """
    Render one or more 8.5×11 summary pages.

    Each page shows:
      - A title/subtitle header (all pages)
      - Global stats cards (first page only)
      - Fixed-height mini bar-chart strips, one per data page, all identical size
        (~6 on the first page, ~8 on subsequent pages)

    Pages with no cluster data are skipped entirely.
    Returns the list of file paths written.
    """
    from matplotlib.ticker import MaxNLocator

    data_page_indices = _data_pages(d)
    n_data_pages      = len(data_page_indices)

    if n_data_pages == 0:
        fig = plt.figure(figsize=(_SUM_PAGE_W, _SUM_PAGE_H))
        fig.patch.set_facecolor("#fafafa")
        fig.text(0.5, 0.5, "No cluster data to summarise.",
                 ha="center", va="center", fontsize=14, color="#888")
        plt.savefig(base_path, dpi=150, facecolor="#fafafa")
        plt.close()
        print(f"Saved: {base_path}")
        return [base_path]

    # Partition data pages across summary pages
    strips_p0   = _sum_strips_per_page(first=True)
    strips_rest = _sum_strips_per_page(first=False)

    # Build list of (summary_page_idx, [data_page_indices_for_this_strip])
    batches: List[List[int]] = []
    remaining = list(data_page_indices)
    first_batch = remaining[:strips_p0]
    remaining   = remaining[strips_p0:]
    batches.append(first_batch)
    while remaining:
        batches.append(remaining[:strips_rest])
        remaining = remaining[strips_rest:]

    n_sum_pages = len(batches)
    base, ext   = (base_path.rsplit(".", 1) if "." in base_path
                   else (base_path, "png"))
    written: List[str] = []

    for sum_page_idx, batch in enumerate(batches):
        is_first  = (sum_page_idx == 0)
        n_strips  = len(batch)
        out_file  = (base_path if n_sum_pages == 1
                     else f"{base}_p{sum_page_idx + 1}.{ext}")

        fig = plt.figure(figsize=(_SUM_PAGE_W, _SUM_PAGE_H))
        fig.patch.set_facecolor("#fafafa")

        # Helper: convert inches-from-top to figure fraction
        def _yf(y_from_top_in: float) -> float:
            return 1.0 - y_from_top_in / _SUM_PAGE_H

        y = _SUM_MARGIN  # cursor from top in inches

        # ── Header ───────────────────────────────────────────────────────────
        pg_label = (f"  (page {sum_page_idx + 1} of {n_sum_pages})"
                    if n_sum_pages > 1 else "")
        fig.text(0.5, _yf(y),
                 f"CGM Data Quality Summary  —  {d['date_range']}{pg_label}",
                 fontsize=14, fontweight="bold", ha="center", va="top",
                 color="#1a237e")
        y += 0.28
        fig.text(0.5, _yf(y),
                 (lambda lbl: lbl if len(lbl) <= 28 else lbl[:26] + "…")(
                 d['sensor_type_label']) + f"  \u2022  {d['units']}  \u2022  {d['n_days']} days",
                 fontsize=10.5, ha="center", va="top", color="#444")
        y += 0.22

        # ── Cards (first summary page only) ──────────────────────────────────
        if is_first:
            has_hypo    = d["n_hypo_events"] > 0
            card_top_frac = _yf(y)
            card_h_frac   = _SUM_CARDS_H / _SUM_PAGE_H
            _draw_card(fig, 0.03, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Glucose Stats", [
                           ("Average", f"{d['avg_bg']:.1f}"),
                           ("Std Dev", f"{d['sd_bg']:.1f}"),
                           ("CV%",     f"{d['cv_pct']:.1f}%"),
                           ("eA1c",    f"{d['ea1c']:.1f}%")])
            _draw_card(fig, 0.27, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Time in Range", [
                           (">250",    f"{d['tir_very_high']:.1f}%"),
                           ("181–250", f"{d['tir_high']:.1f}%"),
                           ("70–180",  f"{d['tir_in_range']:.1f}%"),
                           ("54–69",   f"{d['tir_low']:.1f}%"),
                           ("<54",     f"{d['tir_very_low']:.1f}%")])
            _draw_card(fig, 0.51, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Clusters (all)", [
                           ("Critical", f"{d['n_high']}"),
                           ("Elevated", f"{d['n_med']}"),
                           ("Total",    f"{d['n_high'] + d['n_med']}"),
                           ("Per Day",  f"{(d['n_high']+d['n_med'])/max(d['n_days'],1):.2f}")])
            _draw_card(fig, 0.75, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Data Source", [
                           ("Sensors",     f"{d['n_sensors']}"),
                           ("Days",        f"{d['n_days']}"),
                           ("Hypo Events", f"{d['n_hypo_events']}"),
                           ("Nocturnal",   f"{d.get('n_nocturnal_hypo', 0)}")])
            y += _SUM_CARDS_H + _SUM_CARDS_GAP

        # ── Mini bar-chart strips ─────────────────────────────────────────────
        # Sensor health shading uses sensor_contamination_tier() and TIER_SOLID (globals)

        for strip_i, data_pg in enumerate(batch):
            pdata = _paginate_dashboard_data(d, data_pg)
            if pdata is None:
                continue

            lbl_top_frac   = _yf(y)
            lbl_h_frac     = _SUM_STRIP_LABEL / _SUM_PAGE_H
            chart_h_frac   = _SUM_STRIP_CHART / _SUM_PAGE_H
            chart_bot_frac = lbl_top_frac - lbl_h_frac - chart_h_frac

            # Date-range label bar
            ax_lbl = fig.add_axes([0.09, lbl_top_frac - lbl_h_frac,
                                   0.87, lbl_h_frac])
            ax_lbl.set_xlim(0, 1); ax_lbl.set_ylim(0, 1); ax_lbl.axis("off")
            ax_lbl.add_patch(plt.Rectangle(
                (0, 0), 1, 1, facecolor="#e8eaf6", edgecolor="#9fa8da",
                linewidth=0.8, transform=ax_lbl.transAxes))
            ax_lbl.text(0.012, 0.5, pdata["date_range"],
                        fontsize=8, fontweight="bold", va="center",
                        color="#1a237e", transform=ax_lbl.transAxes)
            n_h_strip = sum(pdata["highs_by_day"])
            n_m_strip = sum(pdata["meds_by_day"])
            ax_lbl.text(0.988, 0.5,
                        f"Critical: {n_h_strip}   Elevated: {n_m_strip}",
                        fontsize=7.5, va="center", ha="right",
                        color="#555", transform=ax_lbl.transAxes)

            # Mini bar chart
            _render_summary_bar_chart(fig, pdata,
                left=0.09, bottom=chart_bot_frac,
                width=0.87, height=chart_h_frac)

            y += _SUM_STRIP_LABEL + _SUM_STRIP_CHART + _SUM_STRIP_GAP

        # ── Params fingerprint footer ─────────────────────────────────────────
        fp = d.get("params_fingerprint", {})
        if fp:
            _fp_line = (
                f"Detection params  \u2014  "
                f"window: {fp.get('window_min',30):.0f}min  \u2022  "
                f"min reversals: {fp.get('min_reversals',2)}  \u2022  "
                f"incoherence ratio: {fp.get('incoh_ratio',0.35):.2f}  \u2022  "
                f"min amp: {fp.get('min_amp_mgdl',15):.0f} mg/dL  \u2022  "
                f"spike bump: {fp.get('spike_bump_mgdl',40):.0f} mg/dL  \u2022  "
                f"chain min: {fp.get('chain_min',3)}  \u2022  "
                f"merge gap: {fp.get('merge_gap_min',30):.0f}min  \u2022  "
                f"hypo: <{fp.get('hypo_thr_mgdl',70):.0f} "
                f"within {fp.get('hypo_window_hr',3):.0f}h"
            )
            fig.text(0.5, 0.012, _fp_line, fontsize=6.5,
                     ha="center", va="bottom", color="#999", style="italic")

        plt.savefig(out_file, dpi=150, facecolor="#fafafa")
        plt.close()
        print(f"Saved: {out_file}")
        written.append(out_file)

    return written


def _paginate_dashboard_data(d: Dict, page: int) -> Optional[Dict]:
    """
    Slice a full dashboard data dict into a single PAGE_SIZE window.
    Per-day arrays are padded to PAGE_SIZE so all pages share the same x-axis.
    Returns None when page is out of range.
    """
    import copy
    start   = page * PAGE_SIZE
    n_total = len(d["dates_str"])
    if start >= n_total:
        return None
    end    = min(start + PAGE_SIZE, n_total)
    actual = end - start
    pad0   = PAGE_SIZE - actual

    nd = copy.copy(d)

    # Slice + pad per-day arrays
    nd["dates_str"]    = list(d["dates_str"][start:end])    + [""]   * pad0
    nd["highs_by_day"]    = list(d["highs_by_day"][start:end])    + [0] * pad0
    nd["meds_by_day"]     = list(d["meds_by_day"][start:end])     + [0] * pad0
    nd["crit_min_by_day"] = list(d.get("crit_min_by_day", [0]*len(d["highs_by_day"]))[start:end]) + [0.0] * pad0
    nd["elev_min_by_day"] = list(d.get("elev_min_by_day", [0]*len(d["meds_by_day"]))[start:end])  + [0.0] * pad0
    nd["actual_days"]  = actual   # number of real data days on this page

    # Date range for title — use dates_full so year is preserved
    dful = d.get("dates_full", [])
    page_full = [f for f in dful[start:end] if f]
    if len(page_full) >= 2:
        def _fmt(s):
            return pd.Timestamp(s).strftime('%b %-d %Y')
        nd["date_range"] = f"{_fmt(page_full[0])} \u2013 {_fmt(page_full[-1])}"
    elif page_full:
        nd["date_range"] = page_full[0]
    else:
        nd["date_range"] = ""
    nd["dates_full"] = dful

    # Re-index hypo_circles
    nd["hypo_circles"] = {k - start: v for k, v in d["hypo_circles"].items()
                          if start <= k < end}

    # Re-index tx_structure (clip + offset indices)
    new_tx = []
    for tx in d.get("tx_structure", []):
        tx_si, tx_ei = tx["start_idx"], tx["end_idx"]
        if tx_ei < start or tx_si >= end:
            continue
        ntx = dict(tx)
        ntx["start_idx"] = max(0, tx_si - start)
        ntx["end_idx"]   = min(PAGE_SIZE - 1, tx_ei - start)
        new_sensors = []
        for s in tx["sensors"]:
            s_si, s_ei = s["start_idx"], s["end_idx"]
            if s_ei < start or s_si >= end:
                continue
            ns = dict(s)
            ns["start_idx"] = max(0, s_si - start)
            ns["end_idx"]   = min(PAGE_SIZE - 1, s_ei - start)
            new_sensors.append(ns)
        if new_sensors:
            ntx["sensors"] = new_sensors
            new_tx.append(ntx)
    nd["tx_structure"] = new_tx

    # Re-index change indices
    # Rebuild date_range from full dates using page window
    dful = d.get("dates_full", [])
    if dful:
        page_full = [f for f in dful[start:end] if f]
        _dfmt = lambda s: pd.Timestamp(s).strftime('%b %-d %Y')
        nd["date_range"] = (
            f"{_dfmt(page_full[0])} \u2013 {_dfmt(page_full[-1])}"
            if len(page_full) >= 2 else (page_full[0] if page_full else ""))
    nd["dates_full"] = dful   # carry through

    nd["tx_change_indices"]     = [i - start for i in d.get("tx_change_indices", [])
                                   if start < i <= end]
    nd["sensor_change_indices"] = [i - start for i in d.get("sensor_change_indices", [])
                                   if start < i <= end]

    # Hypo rows: only events that fall on this page
    page_nums = {en for evs in nd["hypo_circles"].values() for en in evs}
    nd["hypo_rows"] = [r for r in d["hypo_rows"] if r["event_num"] in page_nums]

    # Pagination metadata
    n_pages = -(-n_total // PAGE_SIZE)
    nd["n_pages"] = n_pages
    nd["page"]    = page + 1

    return nd


def render_dashboard(d: Dict, output_file: str):
    """Render a summary dashboard PNG from a data dict produced by _build_dashboard_data."""
    has_hypo = d["n_hypo_events"] > 0
    units = d["units"]

    fig = plt.figure(figsize=(8.5, 11))
    fig.patch.set_facecolor("#fafafa")

    fig.text(0.5, 0.99,
             f"CGM Sensor Integrity Dashboard  —  {d['date_range']}",
             fontsize=16, fontweight="bold", ha="center", va="top", color="#1a237e")
    patient_name = d.get("patient_name", "")
    if patient_name:
        fig.text(0.5, 0.962,
                 f"Name: {patient_name}",
                 fontsize=13, fontweight="bold", ha="center", va="top", color="#000000")

    # ── Cards ─────────────────────────────────────────────────────────────────
    _draw_card(fig, 0.03, 0.81, 0.22, 0.13, "Glucose Stats", [
        ("Average", f"{d['avg_bg']:.1f}"),
        ("Std Dev", f"{d['sd_bg']:.1f}"),
        ("CV%",     f"{d['cv_pct']:.1f}%"),
        ("eA1c",    f"{d['ea1c']:.1f}%")])
    _draw_card(fig, 0.27, 0.81, 0.22, 0.13, "Time in Range", [
        (">250",    f"{d['tir_very_high']:.1f}%"),
        ("181–250", f"{d['tir_high']:.1f}%"),
        ("70–180",  f"{d['tir_in_range']:.1f}%"),
        ("54–69",   f"{d['tir_low']:.1f}%"),
        ("<54",     f"{d['tir_very_low']:.1f}%")])
    _draw_card(fig, 0.51, 0.81, 0.22, 0.13, "Clusters", [
        ("Critical",    f"{d['n_high']}"),
        ("Elevated",    f"{d['n_med']}"),
        ("Total (M+H)", f"{d['n_high'] + d['n_med']}"),
        ("Per Day",     f"{(d['n_high'] + d['n_med']) / max(d['n_days'], 1):.1f}")])
    _dash_device_label = d["sensor_type_label"]
    if len(_dash_device_label) > 16:
        _dash_device_label = _dash_device_label[:14] + "…"
    _draw_card(fig, 0.75, 0.81, 0.22, 0.13, "Data Source", [
        ("Device",   _dash_device_label),
        ("Units",    units),
        ("Days",     str(d["n_days"])),
        ("Sensors",  str(d["n_sensors"]))])

    # ── Layout — fixed 8.5×11 page, all coords in figure fraction ───────────
    import matplotlib.transforms as mtransforms
    from matplotlib.patches import Rectangle as MplRect
    from matplotlib.ticker import MaxNLocator

    is_g7        = d.get("is_g7", False)
    tx_structure = d.get("tx_structure", [])
    hypo_circles = d.get("hypo_circles", {})

    # Layout — top anchor is the bottom of the cards (0.81 y + 0.00 = card bottom at 0.81)
    # Everything below flows from LABEL_TOP downward as a connected chain.
    CARD_Y         = 0.81    # card y anchor (bottom of card box)
    CARD_H         = 0.13    # card height
    CARD_GAP       = 0.008   # gap between card bottom and header row
    HEADER_H       = 0.028   # "Sensor Integrity" + legend row
    HEADER_GAP     = 0.004   # gap between header and sensor label row
    LABEL_TOP      = CARD_Y - CARD_GAP - HEADER_H - HEADER_GAP
    CHART_H        = 0.200
    XTICK_OVERFLOW = 0.048
    HYPO_GAP       = 0.028
    HYPO_HDR_H     = 0.040
    MAX_HYPO_ROWS_PER_COL = 15

    # ── "Sensor Integrity" title + Critical/Elevated legend, same row ─────────
    ax_hdr = fig.add_axes([0.09, CARD_Y - CARD_GAP - HEADER_H, 0.87, HEADER_H])
    ax_hdr.set_xlim(0, 1); ax_hdr.set_ylim(0, 1); ax_hdr.axis("off")
    ax_hdr.text(0.0, 0.5, "Sensor Integrity",
                fontsize=12, fontweight="bold", va="center", color="#1a237e")
    # Critical/Elevated bar legend — right justified
    from matplotlib.patches import Patch
    crit_patch = Patch(facecolor="#d32f2f", alpha=0.85, label="Critical")
    elev_patch = Patch(facecolor="#f9a825", alpha=0.85, label="Elevated")
    ax_hdr.legend(handles=[crit_patch, elev_patch],
                  loc="center right", fontsize=8.5,
                  frameon=True, framealpha=0.85,
                  ncol=2, handlelength=1.2, handleheight=0.9,
                  borderpad=0.4, columnspacing=0.8)

    max_stack_display = min(3, max((len(v) for v in hypo_circles.values()), default=0))
    circ_h = max(0.020, max_stack_display * 0.024)

    # Fixed positions top-down
    ROW_H   = 0.030
    ROW_GAP = 0.003
    # Show TX row only when there are real (non-Unknown) transmitter IDs
    known_txids = [tx["tx_id"] for tx in tx_structure if tx["tx_id"] != "Unknown"]
    show_tx_row = (not is_g7) and len(known_txids) > 0
    GRAD_STRIP_H = ROW_H          # gradient strip same height as one label row
    label_h   = (2 * ROW_H + ROW_GAP) if show_tx_row else ROW_H
    label_bot = LABEL_TOP - label_h
    grad_top  = label_bot         # gradient strip sits right below labels
    grad_bot  = grad_top - GRAD_STRIP_H
    chart_top = grad_bot          # bar chart sits right below gradient strip
    chart_bot = chart_top - CHART_H

    # Circles and hypo table stack upward from bottom_margin
    # (whatever space is left below chart_bot - XTICK_OVERFLOW)
    n_hypo_all   = len(d["hypo_rows"])
    n_hypo_shown = min(n_hypo_all, MAX_HYPO_ROWS_PER_COL * 2)
    rows_per_col = max(1, -(-n_hypo_shown // 2))
    HYPO_ROW_H   = 0.020
    hypo_tbl_h   = 0.030 + rows_per_col * HYPO_ROW_H
    if n_hypo_all > n_hypo_shown:
        hypo_tbl_h += HYPO_ROW_H

    # Circles and hypo table hang down from bar chart bottom
    circ_bot      = chart_bot - XTICK_OVERFLOW - circ_h
    circ_top      = circ_bot + circ_h
    hdr_block_bot = circ_bot - HYPO_GAP - HYPO_HDR_H
    hdr_block_top = hdr_block_bot + HYPO_HDR_H
    hypo_top      = hdr_block_bot
    hypo_bot      = hypo_top - hypo_tbl_h

    # ── Pre-compute per-sensor health tier colors ─────────────────────────────
    # Score = Critical×3 + Elevated×1. Used for both the bar chart background
    # shading (transparent) and the solid-color sensor header label boxes.
    _CRIT_D  = [(0.10,"green"),(0.30,"yellow"),(0.60,"red"),(None,"purple")]

    # ── Per-day tier colors for gradient rendering ────────────────────────────
    _DAY_RGBA  = TIER_RGBA
    _DAY_SOLID = TIER_SOLID
    def _day_tier(h, m):
        if h >= 2:   return "purple"
        if h >= 1:   return "red"
        if m >= 2:   return "yellow"
        if m >= 1:   return "yellow"
        return "green"

    import numpy as _np
    actual_days = d.get("actual_days", PAGE_SIZE)
    _day_tiers = [_day_tier(h, m) if i < actual_days else None
                  for i, (h, m) in enumerate(zip(d["highs_by_day"], d["meds_by_day"]))]
    _day_rgba  = [_DAY_RGBA[t] if t else (1.0, 1.0, 1.0, 1.0) for t in _day_tiers]

    # ── ax_lbl: sensor label boxes (solid, readable text) ─────────────────────
    ax_lbl = fig.add_axes([0.09, label_bot, 0.87, label_h])
    ax_lbl.set_xlim(-0.5, PAGE_SIZE - 0.5)
    ax_lbl.set_ylim(0, 1)
    ax_lbl.axis("off")

    # ── ax_grad: bold gradient color strip just below label boxes ─────────────
    ax_grad = fig.add_axes([0.09, grad_bot, 0.87, GRAD_STRIP_H])
    ax_grad.set_xlim(-0.5, PAGE_SIZE - 0.5)
    ax_grad.set_ylim(0, 1)
    ax_grad.axis("off")
    _grad_img = _np.array(_day_rgba, dtype=float).reshape(1, len(_day_rgba), 4)
    ax_grad.imshow(_grad_img, aspect="auto", interpolation="bilinear",
                   extent=(-0.5, PAGE_SIZE - 0.5, 0, 1),
                   zorder=1, clip_on=True)
    ax_grad.add_patch(MplRect((-0.5, 0), PAGE_SIZE, 1,
                     linewidth=0.8, edgecolor="#333",
                     facecolor="none", clip_on=False, zorder=3))

    # y-fraction bands within ax_lbl
    if show_tx_row:
        # TX occupies top ROW_H / label_h fraction, sensor the bottom
        s_frac = ROW_H / label_h
        tx_ybot = s_frac + ROW_GAP / label_h
        tx_ytop = 1.0
        s_ybot  = 0.0
        s_ytop  = s_frac
    else:
        tx_ybot = tx_ytop = 0      # unused
        s_ybot  = 0.0
        s_ytop  = 1.0

    for idx, tx in enumerate(tx_structure):
        si, ei = tx["start_idx"], tx["end_idx"]
        span   = ei - si + 1
        color  = COLORS_POOL[idx % len(COLORS_POOL)]

        if show_tx_row:
            # TX bordered box
            rect_tx = MplRect((si - 0.5, tx_ybot), span, tx_ytop - tx_ybot,
                              linewidth=1.2, edgecolor="#555",
                              facecolor=color, alpha=0.18, clip_on=True, zorder=1)
            ax_lbl.add_patch(rect_tx)
            tx_mid  = (si + ei) / 2
            tx_text = f"Trans: {tx['tx_id']}" if span >= 6 else f"TX:{tx['tx_id']}"
            ax_lbl.text(tx_mid, (tx_ybot + tx_ytop) / 2,
                        tx_text, fontsize=8, fontweight="bold",
                        ha="center", va="center", color="#111", clip_on=True)

        # Sensor boxes — solid color based on median day tier
        global_s_num = sum(len(earlier["sensors"]) for earlier in tx_structure[:idx])
        for s_idx, s in enumerate(tx["sensors"]):
            ss, se   = s["start_idx"], s["end_idx"]
            s_span   = se - ss + 1
            s_mid    = (ss + se) / 2
            short    = (f"S{global_s_num + s_idx + 1}" if not show_tx_row
                        else s["label"].split("·")[-1])

            # Solid color = contamination score for this sensor segment
            # score = (crit_minutes×1.5 + elev_minutes) / total_sensor_minutes
            _seg_tiers = [t for t in _day_tiers[ss:se+1] if t is not None]
            if not _seg_tiers:
                # entirely in padded region — white box, no label
                ax_lbl.add_patch(MplRect((ss - 0.5, s_ybot), s_span, s_ytop - s_ybot,
                                 linewidth=0.5, edgecolor="#ccc",
                                 facecolor="white", clip_on=True, zorder=2))
                continue

            _crit_min_seg = sum(d.get("crit_min_by_day", [0]*PAGE_SIZE)[ss:se+1])
            _elev_min_seg = sum(d.get("elev_min_by_day", [0]*PAGE_SIZE)[ss:se+1])
            _actual_seg   = sum(1 for t in _day_tiers[ss:se+1] if t is not None)
            _total_min    = max(_actual_seg * MINUTES_PER_DAY, 1)
            _sensor_tier  = sensor_contamination_tier(_crit_min_seg, _elev_min_seg, _total_min)
            solid_col = TIER_SOLID[_sensor_tier]
            txt_col   = TIER_TEXT[_sensor_tier]

            # Clip box to actual data days — don't draw into padded region
            se_clipped = min(se, actual_days - 1)
            if se_clipped < ss:
                continue
            s_span_clipped = se_clipped - ss + 1
            s_mid_clipped  = (ss + se_clipped) / 2

            rect_s = MplRect((ss - 0.5, s_ybot), s_span_clipped, s_ytop - s_ybot,
                             linewidth=1.0, edgecolor="#555",
                             facecolor=solid_col, alpha=1.0, clip_on=True, zorder=2)
            ax_lbl.add_patch(rect_s)

            box_mid_y = (s_ybot + s_ytop) / 2
            if s_span_clipped >= 3:
                ax_lbl.text(s_mid_clipped, box_mid_y, short,
                            fontsize=11, fontweight="bold",
                            ha="center", va="center", color=txt_col, clip_on=True)
            else:
                ax_lbl.text(ss + 0.05, box_mid_y, short,
                            fontsize=8, ha="left", va="center",
                            color=txt_col, clip_on=True)

    # ── ax_bar: Daily cluster bar chart (fixed 90-day x-axis) ────────────────
    ax_bar = fig.add_axes([0.09, chart_bot, 0.87, CHART_H])
    ax_bar.set_xlim(-0.5, PAGE_SIZE - 0.5)

    x = range(PAGE_SIZE)
    ax_bar.bar(x, d["highs_by_day"], color="#d32f2f", alpha=0.85,
               label="Critical", width=0.8)
    ax_bar.bar(x, d["meds_by_day"], bottom=d["highs_by_day"],
               color="#f9a825", alpha=0.85, label="Elevated", width=0.8)

    # Integer-only y-axis, fixed 0-13
    ax_bar.set_ylim(0, 12)
    ax_bar.yaxis.set_major_locator(MaxNLocator(integer=True, min_n_ticks=1))
    ax_bar.set_ylabel("Clusters", fontsize=10)
    ax_bar.tick_params(axis="y", labelsize=9)
    ax_bar.grid(True, axis="y", alpha=0.15)

    # X-tick labels: only for actual data dates, every ~20th slot
    step = max(1, PAGE_SIZE // 20)
    tick_pos = [i for i in range(0, PAGE_SIZE, step) if d["dates_str"][i]]
    ax_bar.set_xticks(tick_pos)
    ax_bar.set_xticklabels([d["dates_str"][i] for i in tick_pos],
                           rotation=45, ha="right", fontsize=7)



    # TX-band shading
    for idx, tx in enumerate(tx_structure):
        ax_bar.axvspan(tx["start_idx"] - 0.5, tx["end_idx"] + 0.5,
                       alpha=0.10, color=COLORS_POOL[idx % len(COLORS_POOL)])

    # Sensor divider lines — all sensor transitions
    all_sens_changes = list(d.get("sensor_change_indices", []))
    for tx in tx_structure:
        if tx["start_idx"] > 0:
            all_sens_changes.append(tx["start_idx"])
    for xi in sorted(set(all_sens_changes)):
        ax_bar.axvline(xi - 0.5, color="#2e7d32", linewidth=1.5,
                       linestyle=(0, (4, 3)), zorder=5)
        ax_grad.axvline(xi - 0.5, color="white", linewidth=1.0,
                        alpha=0.7, zorder=2)

    # ── ax_circ: yellow event circles, stacked below bar chart ───────────────
    ax_circ = fig.add_axes([0.09, circ_bot, 0.87, circ_h])
    ax_circ.set_xlim(-0.5, PAGE_SIZE - 0.5)
    ax_circ.set_ylim(0, 1)
    ax_circ.axis("off")

    circ_unit = 1.0 / max(max_stack_display, 1)
    blended_circ = mtransforms.blended_transform_factory(
        ax_bar.transData, ax_circ.transAxes)

    circle_stack: dict = {}
    for date_idx, ev_nums in sorted(hypo_circles.items()):
        for ev_num in ev_nums:
            depth = circle_stack.get(date_idx, 0)
            if depth >= max_stack_display:          # clip at cap — don't overflow into title
                circle_stack[date_idx] = depth + 1
                continue
            cy    = 1.0 - (depth + 0.5) * circ_unit
            row = next((r for r in d["hypo_rows"] if r["event_num"] == ev_num), None)
            badge = _badge_kwargs(row.get("nocturnal", False) if row else False)
            ax_circ.text(date_idx, cy, str(ev_num),
                         ha="center", va="center",
                         fontsize=6, fontweight="bold", color=badge["textcolor"], zorder=10,
                         transform=blended_circ, clip_on=False,
                         bbox=dict(boxstyle="circle,pad=0.22",
                                   facecolor=badge["facecolor"], edgecolor=badge["edgecolor"],
                                   linewidth=1.1))
            circle_stack[date_idx] = depth + 1

    # ── Divider between circles and hypo section ─────────────────────────────
    # Sits in the middle of the HYPO_GAP between circ_bot and hdr_block_top
    div_y = hdr_block_top + HYPO_GAP * 0.5
    ax_div = fig.add_axes([0.06, div_y, 0.91, 0.001])
    ax_div.set_xlim(0, 1); ax_div.set_ylim(0, 1); ax_div.axis("off")
    ax_div.add_patch(plt.Rectangle((0, 0), 1, 1,
                                   facecolor="#bbbbbb", edgecolor="none",
                                   transform=ax_div.transAxes))

    # ── Hypo section title with badge legend ─────────────────────────────────
    title_y = hdr_block_top - 0.016
    fig.text(0.06, title_y + 0.018,
             "Hypoglycemia Events that Occur After Clusters",
             fontsize=11, fontweight="bold", color="#c62828", va="center")
    _n_linked = len(d["hypo_rows"])
    _n_total  = d.get("n_hypo_events", _n_linked)
    fig.text(0.06, title_y + 0.004,
             f"Total hypos: {_n_total}  \u2022  Linked to clusters: {_n_linked}",
             fontsize=8, color="#444", va="center")
    from matplotlib.lines import Line2D as _Line2D
    day_handle = _Line2D([0], [0], marker="o", color="w", markerfacecolor="#FFD600",
                         markeredgecolor="black", markeredgewidth=1.1,
                         markersize=9, label="Daytime")
    noc_handle = _Line2D([0], [0], marker="o", color="w", markerfacecolor="#111111",
                         markeredgecolor="#111111", markeredgewidth=1.1,
                         markersize=9, label="Nocturnal (22:00–07:00)")
    ax_badge = fig.add_axes([0.50, title_y + 0.006, 0.47, 0.024])
    ax_badge.set_xlim(0, 1); ax_badge.set_ylim(0, 1); ax_badge.axis("off")
    ax_badge.legend(handles=[day_handle, noc_handle], loc="center right",
                    fontsize=8, frameon=False, ncol=2,
                    handletextpad=0.4, columnspacing=1.2, borderpad=0)

    # ── ax_hypo: styled alternating-row table ────────────────────────────────
    ax_h = fig.add_axes([0.06, hypo_bot, 0.91, hypo_tbl_h])
    ax_h.set_xlim(0, 1); ax_h.set_ylim(0, 1); ax_h.axis("off")

    if d["hypo_rows"]:
        rows     = d["hypo_rows"][:n_hypo_shown]
        half     = -(-len(rows) // 2)
        col_sets = [rows[:half], rows[half:]]

        # Two side-by-side sub-tables, each 0.47 wide with a small gutter
        for t_idx, (t_rows, t_x0) in enumerate(zip(col_sets, [0.00, 0.50])):
            if not t_rows:
                continue
            t_w   = 0.47
            t_x1  = t_x0 + t_w
            n_r   = len(t_rows)
            # Row heights in axes fraction: header + n data rows fill the axes
            h_hdr  = 1.0 / (n_r + 1.0)   # header row height
            h_row  = h_hdr                # data row height (equal)

            # Column x positions (relative to t_x0), widths
            # cols: # (circle), Date, Lag, Low BG
            CX = [t_x0 + 0.010, t_x0 + 0.075, t_x0 + 0.230, t_x0 + 0.355]
            CW = [t_w * 0.14,   t_w * 0.32,   t_w * 0.30,   t_w * 0.24]

            # Header row background
            from matplotlib.patches import FancyBboxPatch as FBP
            hdr_bg = plt.Rectangle((t_x0, 1.0 - h_hdr), t_w, h_hdr,
                                    facecolor="#dddddd", edgecolor="none",
                                    transform=ax_h.transAxes, zorder=1)
            ax_h.add_patch(hdr_bg)
            # Outer border
            border = plt.Rectangle((t_x0, 1.0 - h_hdr * (n_r + 1)), t_w, h_hdr * (n_r + 1),
                                    facecolor="none", edgecolor="#333",
                                    linewidth=0.8, transform=ax_h.transAxes, zorder=4)
            ax_h.add_patch(border)

            # Header text
            hdr_labels = ["#", "Date", "Lag", "Low BG"]
            hdr_y_center = 1.0 - h_hdr * 0.5
            for lbl, cx in zip(hdr_labels, CX):
                ax_h.text(cx + 0.008, hdr_y_center, lbl,
                          fontsize=8, fontweight="bold", color="#222",
                          ha="left", va="center", zorder=5)

            # Data rows
            ROW_COLORS = ["#ffffff", "#dbeeff"]  # alternating white / light blue
            for r_i, row in enumerate(t_rows):
                y_top = 1.0 - h_hdr * (r_i + 1)
                y_bot = y_top - h_row
                y_ctr = (y_top + y_bot) / 2

                # Row background
                bg = plt.Rectangle((t_x0, y_bot), t_w, h_row,
                                    facecolor=ROW_COLORS[r_i % 2], edgecolor="none",
                                    transform=ax_h.transAxes, zorder=1)
                ax_h.add_patch(bg)
                # Bottom rule
                ax_h.plot([t_x0, t_x1], [y_bot, y_bot],
                          color="#aaaaaa", linewidth=0.5, zorder=3)

                ev_num = row["event_num"]
                # Circle badge
                badge = _badge_kwargs(row.get("nocturnal", False))
                ax_h.text(CX[0] + 0.018, y_ctr, str(ev_num),
                          ha="center", va="center",
                          fontsize=6.5, fontweight="bold", color=badge["textcolor"], zorder=6,
                          bbox=dict(boxstyle="circle,pad=0.22",
                                    facecolor=badge["facecolor"], edgecolor=badge["edgecolor"],
                                    linewidth=1.1))
                ax_h.text(CX[1] + 0.006, y_ctr, row["date"],
                          fontsize=7.5, va="center", color="#111", zorder=5)
                ax_h.text(CX[2] + 0.006, y_ctr, row["lag"],
                          fontsize=7.5, va="center", color="#111", zorder=5)
                ax_h.text(CX[3] + 0.006, y_ctr, row.get("low_bg", ""),
                          fontsize=7.5, va="center", color="#b71c1c",
                          fontweight="bold", zorder=5)

        if n_hypo_all > n_hypo_shown:
            ax_h.text(0.0, -0.10,
                      f"\u2026 and {n_hypo_all - n_hypo_shown} more events (see daily reports)",
                      fontsize=7.5, va="top", color="#888", style="italic",
                      transform=ax_h.transAxes)
    else:
        ax_h.text(0.0, 0.70, "No qualifying events.", fontsize=11,
                  va="top", color="#888", style="italic")

    # ── Footer: version left, URL center, page number right ──────────────────
    fig.text(0.06, 0.012, "CGM Sensor Integrity Detector v6",
             fontsize=7.5, ha="left", va="bottom", color="#888", style="italic")
    fig.text(0.5, 0.012,
             "danheller.substack.com/p/the-cgm-patent-that-could-save-lives",
             fontsize=7.5, ha="center", va="bottom", color="#888", style="italic")
    n_pages = d.get("n_pages", 1)
    page_num = d.get("page", 1)
    fig.text(0.94, 0.012, f"Page {page_num} of {n_pages}",
             fontsize=11, ha="right", va="bottom", color="#000", fontweight="bold")

    plt.savefig(output_file, dpi=150, facecolor="#fafafa")
    plt.close()
    print(f"Saved: {output_file}")


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# MULTI-SENSOR PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

def split_by_sensor(egv: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """
    Split a merged egv DataFrame into per-transmitter streams.
    Preserves sensor_label values already assigned by _infer_sensor_labels
    during CSV loading — does NOT re-label, which would reset global S1/S2/...
    labels to local per-TX numbering.
    Returns an OrderedDict keyed by transmitter_id, sorted by stream start date.
    """
    from collections import OrderedDict
    streams: Dict[str, pd.DataFrame] = {}
    for tx_id, grp in egv.groupby("transmitter_id", sort=False):
        grp = grp.sort_values("dt").reset_index(drop=True)
        streams[str(tx_id)] = grp[["dt", "dt_mono", "glucose",
                                    "transmitter_id", "sensor_label"]]
    # Sort streams by their earliest reading
    return OrderedDict(
        sorted(streams.items(), key=lambda kv: kv[1]["dt"].min())
    )


def validate_streams(
    streams: Dict[str, pd.DataFrame],
    units: str,
) -> Tuple[Dict[str, pd.DataFrame], int]:
    """
    Enforce the no-sensor-ID policy.

    - "Unknown" keyed streams have no transmitter ID.
    - If the ONLY stream is Unknown → raise ValueError (whole file rejected).
    - If Unknown exists alongside identified streams → remove it, return its
      reading count as `unidentified_count` for the warning block.

    Returns (clean_streams, unidentified_count).
    """
    unknown = {k: v for k, v in streams.items() if k == "Unknown"}
    known   = {k: v for k, v in streams.items() if k != "Unknown"}

    unidentified_count = sum(len(v) for v in unknown.values())

    if not known:
        raise ValueError(
            f"This file contains {unidentified_count} CGM readings with no "
            "sensor ID (transmitter ID). Aborting — cannot produce a reliable "
            "report without sensor attribution.\n\n"
            "Exception: the 2023 paired G6/G7 Excel workbook is handled "
            "separately via --excel_workbook and does not require transmitter IDs."
        )
    return known, unidentified_count


def aggregate_global_stats(
    stream_results: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Combine per-stream dashboard data dicts into a single global stats dict
    for the multi-sensor summary cards.
    Glucose stats and TIR are reading-weighted averages across all streams.
    Cluster and hypo counts are simple sums.
    """
    all_glucose: List[float] = []
    n_high = n_med = n_hypo = n_noc_hypo = n_sensors = n_days = 0
    tir_keys = ["very_high", "high", "in_range", "low", "very_low"]
    tir_sums = {k: 0.0 for k in tir_keys}
    tir_weights = 0

    for d in stream_results:
        n_readings = d.get("n_readings", 0)
        all_glucose.extend([d["avg_bg"]] * max(n_readings, 1))  # weight by readings
        n_high     += d["n_high"]
        n_med      += d["n_med"]
        n_hypo     += d["n_hypo_events"]
        n_noc_hypo += d.get("n_nocturnal_hypo", 0)
        n_sensors  += d["n_sensors"]
        n_days     += d["n_days"]
        for k in tir_keys:
            tir_sums[k] += d[f"tir_{k}"] * n_readings
        tir_weights += n_readings

    all_g = pd.Series(all_glucose)
    avg   = float(all_g.mean()) if len(all_g) else 0.0
    sd    = float(all_g.std())  if len(all_g) > 1 else 0.0
    cv    = 100.0 * sd / avg if avg > 0 else 0.0

    tir_avg = {k: tir_sums[k] / tir_weights if tir_weights else 0.0
               for k in tir_keys}

    return {
        "avg_bg": avg, "sd_bg": sd, "cv_pct": cv, "ea1c": _ea1c(avg),
        "tir_very_high": tir_avg["very_high"], "tir_high": tir_avg["high"],
        "tir_in_range":  tir_avg["in_range"],  "tir_low": tir_avg["low"],
        "tir_very_low":  tir_avg["very_low"],
        "n_high": n_high, "n_med": n_med,
        "n_hypo_events": n_hypo, "n_nocturnal_hypo": n_noc_hypo,
        "n_sensors": n_sensors, "n_days": n_days,
    }


def render_multi_sensor_summary(
    stream_results: List[Tuple[str, Dict]],
    base_path: str,
    unidentified_count: int = 0,
    units: str = "mg/dL",
) -> List[str]:
    """
    Render one or more 8.5×11 summary pages for a multi-sensor dataset.

    stream_results: list of (sensor_id_label, dashboard_data_dict), sorted
                    chronologically by stream start date.

    Layout per page:
      - Title/subtitle header (all pages)
      - Red warning block if unidentified readings were dropped (first page)
      - Global stats cards across all streams (first page)
      - Fixed-height mini bar-chart strips — one per data page per stream,
        labeled "[Sensor ID]  •  [Date Range]  •  Critical: N  Elevated: N"
      - Params fingerprint footer (all pages)

    Empty calendar pages within each stream are skipped. Pages with no strips
    are not emitted.
    Returns list of written file paths.
    """
    from matplotlib.ticker import MaxNLocator
    from matplotlib.patches import Rectangle as MplRect

    # One strip per stream (sensor type), not per individual sensor.
    # Per-sensor health tiers are shown as color-coded backgrounds within each bar chart.
    Strip = Dict[str, Any]

    # ── Build shared global date grid ────────────────────────────────────────
    # All strips share the same x-axis so sensors worn simultaneously align visually.
    # Each stream's data is mapped onto the global grid; dates with no data get 0.
    from datetime import date as _date, timedelta as _td
    import datetime as _datetime

    all_date_strs = []
    for _, d in stream_results:
        all_date_strs.extend(d.get("dates_full", []))
    if all_date_strs:
        global_start = min(pd.Timestamp(s).date() for s in all_date_strs)
        global_end   = max(pd.Timestamp(s).date() for s in all_date_strs)
        global_dates: List[_date] = []
        _cur = global_start
        while _cur <= global_end:
            global_dates.append(_cur)
            _cur += _td(days=1)
    else:
        global_dates = []
    global_date_index = {d: i for i, d in enumerate(global_dates)}
    GLOBAL_SIZE = len(global_dates)

    def _remap_stream(d: Dict) -> Dict:
        """Remap a stream's per-day arrays onto the global date grid."""
        stream_dates = [pd.Timestamp(s).date() for s in d.get("dates_full", [])]
        highs_g  = [0]   * GLOBAL_SIZE
        meds_g   = [0]   * GLOBAL_SIZE
        critmn_g = [0.0] * GLOBAL_SIZE
        elevmn_g = [0.0] * GLOBAL_SIZE
        for i, dt in enumerate(stream_dates):
            gi = global_date_index.get(dt)
            if gi is not None:
                highs_g[gi]  = d["highs_by_day"][i]
                meds_g[gi]   = d["meds_by_day"][i]
                critmn_g[gi] = d.get("crit_min_by_day", [0.0]*len(stream_dates))[i]
                elevmn_g[gi] = d.get("elev_min_by_day", [0.0]*len(stream_dates))[i]

        # Remap tx_structure indices to global grid
        new_tx = []
        for tx in d.get("tx_structure", []):
            new_sensors = []
            for s in tx["sensors"]:
                # Map start/end day indices through global grid
                if s["start_idx"] < len(stream_dates) and s["end_idx"] < len(stream_dates):
                    gs = global_date_index.get(stream_dates[s["start_idx"]])
                    ge = global_date_index.get(stream_dates[s["end_idx"]])
                    if gs is not None and ge is not None:
                        new_sensors.append({**s, "start_idx": gs, "end_idx": ge})
            if new_sensors:
                new_tx.append({**tx, "sensors": new_sensors,
                               "start_idx": new_sensors[0]["start_idx"],
                               "end_idx":   new_sensors[-1]["end_idx"]})

        # Remap sensor_change_indices
        new_sci = []
        for idx in d.get("sensor_change_indices", []):
            if idx < len(stream_dates):
                gi = global_date_index.get(stream_dates[idx])
                if gi is not None:
                    new_sci.append(gi)

        dates_str_g = [str(dt)[5:] for dt in global_dates]
        return {
            **d,
            "highs_by_day":          highs_g,
            "meds_by_day":           meds_g,
            "crit_min_by_day":       critmn_g,
            "elev_min_by_day":       elevmn_g,
            "dates_str":             dates_str_g,
            "dates_full":            [str(dt) for dt in global_dates],
            "tx_structure":          new_tx,
            "sensor_change_indices": new_sci,
            "date_range":            f"{global_dates[0].strftime('%b %-d %Y') if global_dates else '?'}"
                                     f" \u2013 "
                                     f"{global_dates[-1].strftime('%b %-d %Y') if global_dates else '?'}",
        }

    all_strips: List[Strip] = []
    for stream_name, d in stream_results:
        d_remapped = _remap_stream(d)
        # Paginate using global size
        n_global_pages = max(1, -(-GLOBAL_SIZE // PAGE_SIZE))
        for pg in range(n_global_pages):
            start = pg * PAGE_SIZE
            end   = min(start + PAGE_SIZE, GLOBAL_SIZE)
            slice_highs  = d_remapped["highs_by_day"][start:end]
            slice_meds   = d_remapped["meds_by_day"][start:end]
            slice_dates  = d_remapped["dates_str"][start:end]
            slice_critmn = d_remapped.get("crit_min_by_day", [0.0]*GLOBAL_SIZE)[start:end]
            slice_elevmn = d_remapped.get("elev_min_by_day", [0.0]*GLOBAL_SIZE)[start:end]
            # Pad to PAGE_SIZE
            pad = PAGE_SIZE - len(slice_highs)
            pdata_pg = {
                **d_remapped,
                "highs_by_day":    slice_highs  + [0]*pad,
                "meds_by_day":     slice_meds   + [0]*pad,
                "crit_min_by_day": slice_critmn + [0.0]*pad,
                "elev_min_by_day": slice_elevmn + [0.0]*pad,
                "dates_str":       slice_dates  + [""]*pad,
                "actual_days":     len(slice_highs),
                "date_range":   (f"{slice_dates[0]} \u2013 {slice_dates[-1]}"
                                 if slice_dates else ""),
                "n_pages": n_global_pages,
                "page":    pg + 1,
                # Remap tx_structure for this page's window
                "tx_structure": [
                    {**tx, "sensors": [
                        {**s,
                         "start_idx": max(0, s["start_idx"] - start),
                         "end_idx":   min(PAGE_SIZE-1, s["end_idx"] - start)}
                        for s in tx["sensors"]
                        if s["start_idx"] < end and s["end_idx"] >= start
                    ],
                    "start_idx": max(0, tx["start_idx"] - start),
                    "end_idx":   min(PAGE_SIZE-1, tx["end_idx"] - start)}
                    for tx in d_remapped.get("tx_structure", [])
                    if tx["start_idx"] < end and tx["end_idx"] >= start
                ],
                "sensor_change_indices": [
                    idx - start for idx in d_remapped.get("sensor_change_indices", [])
                    if start <= idx < end
                ],
            }
            # Only include page if it has any data
            if any(h > 0 or m > 0 for h, m in zip(slice_highs, slice_meds)):
                all_strips.append({
                    "sensor_label": stream_name,
                    "pdata":        pdata_pg,
                    "fp":           d.get("params_fingerprint", {}),
                })

    if not all_strips:
        fig = plt.figure(figsize=(_SUM_PAGE_W, _SUM_PAGE_H))
        fig.patch.set_facecolor("#fafafa")
        fig.text(0.5, 0.5, "No cluster data across any sensor stream.",
                 ha="center", va="center", fontsize=14, color="#888")
        plt.savefig(base_path, dpi=150, facecolor="#fafafa")
        plt.close()
        print(f"Saved: {base_path}")
        return [base_path]

    # Global stats
    just_data = [d for _, d in stream_results]
    glob      = aggregate_global_stats(just_data)
    n_streams = len(stream_results)

    # Date range across all streams
    all_starts = [d["dates_full"][0]  for _, d in stream_results if d.get("dates_full")]
    all_ends   = [d["dates_full"][-1] for _, d in stream_results if d.get("dates_full")]
    if all_starts and all_ends:
        _fmt = lambda s: pd.Timestamp(s).strftime("%b %-d %Y")
        global_range = f"{_fmt(min(all_starts))} \u2013 {_fmt(max(all_ends))}"
    else:
        global_range = ""

    # Pagination — strips per page
    WARN_H      = 0.55   # warning block height (first page, only if needed)
    warn_on_p0  = unidentified_count > 0
    overhead_p0 = (_SUM_MARGIN + _SUM_HDR_H
                   + (WARN_H + 0.10 if warn_on_p0 else 0)
                   + _SUM_CARDS_H + _SUM_CARDS_GAP
                   + _SUM_FP_H + _SUM_MARGIN)
    strips_p0   = max(1, int((_SUM_PAGE_H - overhead_p0) / _SUM_STRIP_TOTAL))
    strips_rest = _sum_strips_per_page(first=False)

    batches: List[List[Strip]] = []
    rem = list(all_strips)
    batches.append(rem[:strips_p0]);  rem = rem[strips_p0:]
    while rem:
        batches.append(rem[:strips_rest]); rem = rem[strips_rest:]

    n_sum_pages = len(batches)
    base, ext   = (base_path.rsplit(".", 1) if "." in base_path
                   else (base_path, "png"))
    written: List[str] = []

    # Sensor health tier uses sensor_contamination_tier() — see module docstring
    # tier classification uses sensor_contamination_tier() and TIER_SOLID (globals)

    for sum_pg, batch in enumerate(batches):
        is_first = (sum_pg == 0)
        out_file = (base_path if n_sum_pages == 1
                    else f"{base}_p{sum_pg + 1}.{ext}")

        fig = plt.figure(figsize=(_SUM_PAGE_W, _SUM_PAGE_H))
        fig.patch.set_facecolor("#fafafa")

        def _yf(y_in: float) -> float:
            return 1.0 - y_in / _SUM_PAGE_H

        y = _SUM_MARGIN

        # ── Header ───────────────────────────────────────────────────────────
        pg_sfx = (f"  (page {sum_pg+1} of {n_sum_pages})"
                  if n_sum_pages > 1 else "")
        fig.text(0.5, _yf(y),
                 f"CGM Multi-Sensor Quality Summary  —  {global_range}{pg_sfx}",
                 fontsize=13, fontweight="bold", ha="center", va="top",
                 color="#1a237e")
        y += 0.28
        fig.text(0.5, _yf(y),
                 (f"{n_streams} sensor stream{'s' if n_streams != 1 else ''}  "
                  f"\u2022  {units}  \u2022  {glob['n_days']} days  "
                  f"\u2022  {glob['n_sensors']} sensors"),
                 fontsize=10, ha="center", va="top", color="#444")
        y += 0.22

        # ── Unidentified-data warning (first page only) ───────────────────
        if is_first and warn_on_p0:
            from matplotlib.patches import FancyBboxPatch as FBP
            warn_frac_top = _yf(y)
            warn_frac_h   = WARN_H / _SUM_PAGE_H
            ax_w = fig.add_axes([0.05, warn_frac_top - warn_frac_h,
                                  0.90, warn_frac_h])
            ax_w.set_xlim(0, 1); ax_w.set_ylim(0, 1); ax_w.axis("off")
            ax_w.add_patch(FBP((0.0, 0.0), 1.0, 1.0,
                               boxstyle="round,pad=0.02",
                               facecolor="#ffebee", edgecolor="#c62828",
                               linewidth=2.5))
            ax_w.text(0.5, 0.72,
                      "\u26a0  CGM DATA WITHOUT SENSOR ID DETECTED  \u26a0",
                      fontsize=10, fontweight="bold", color="#c62828",
                      ha="center", va="center")
            ax_w.text(0.5, 0.38,
                      f"{unidentified_count:,} readings had no transmitter ID "
                      "and were excluded from all reports.\n"
                      "Results below reflect only the identified sensor streams.",
                      fontsize=8.5, color="#333",
                      ha="center", va="center", linespacing=1.6)
            y += WARN_H + 0.10

        # ── Global stats cards (first page only) ─────────────────────────
        if is_first:
            has_hypo    = glob["n_hypo_events"] > 0
            card_top_frac = _yf(y)
            card_h_frac   = _SUM_CARDS_H / _SUM_PAGE_H
            _draw_card(fig, 0.03, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Glucose Stats (all)", [
                           ("Average", f"{glob['avg_bg']:.1f}"),
                           ("Std Dev", f"{glob['sd_bg']:.1f}"),
                           ("CV%",     f"{glob['cv_pct']:.1f}%"),
                           ("eA1c",    f"{glob['ea1c']:.1f}%")])
            _draw_card(fig, 0.27, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Time in Range (all)", [
                           (">250",    f"{glob['tir_very_high']:.1f}%"),
                           ("181\u2013250", f"{glob['tir_high']:.1f}%"),
                           ("70\u2013180",  f"{glob['tir_in_range']:.1f}%"),
                           ("54\u201369",   f"{glob['tir_low']:.1f}%"),
                           ("<54",     f"{glob['tir_very_low']:.1f}%")])
            _draw_card(fig, 0.51, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Clusters (all)", [
                           ("Critical", f"{glob['n_high']}"),
                           ("Elevated", f"{glob['n_med']}"),
                           ("Total",    f"{glob['n_high'] + glob['n_med']}"),
                           ("Per Day",  f"{(glob['n_high']+glob['n_med'])/max(glob['n_days'],1):.2f}")])
            _draw_card(fig, 0.75, card_top_frac - card_h_frac, 0.22, card_h_frac,
                       "Data Source", [
                           ("Sensors",      f"{glob['n_sensors']}"),
                           ("Days",         f"{glob['n_days']}"),
                           ("Hypo Events",  f"{glob['n_hypo_events']}"),
                           ("Nocturnal",    f"{glob['n_nocturnal_hypo']}")])
            y += _SUM_CARDS_H + _SUM_CARDS_GAP

        # ── Mini bar-chart strips ─────────────────────────────────────────
        for strip in batch:
            sensor_label = strip["sensor_label"]
            pdata        = strip["pdata"]

            lbl_top_frac   = _yf(y)
            lbl_h_frac     = _SUM_STRIP_LABEL / _SUM_PAGE_H
            chart_h_frac   = _SUM_STRIP_CHART  / _SUM_PAGE_H
            chart_bot_frac = lbl_top_frac - lbl_h_frac - chart_h_frac

            # Label bar — color-coded by overall stream health tier
            _d_strip   = max(1, sum(1 for v in pdata["highs_by_day"] if v is not None))
            _h_strip   = sum(pdata["highs_by_day"])
            _m_strip   = sum(pdata["meds_by_day"])
            _crit_min_strip = sum(pdata.get("crit_min_by_day", [0]*PAGE_SIZE))
            _elev_min_strip = sum(pdata.get("elev_min_by_day", [0]*PAGE_SIZE))
            _ft_s = sensor_contamination_tier(
                _crit_min_strip, _elev_min_strip, max(_d_strip * MINUTES_PER_DAY, 1))
            _strip_fill  = TIER_FILL[_ft_s]
            _strip_edge  = TIER_SOLID[_ft_s]
            _strip_text  = TIER_FILL_TEXT[_ft_s]
            ax_lbl = fig.add_axes([0.09, lbl_top_frac - lbl_h_frac,
                                   0.87, lbl_h_frac])
            ax_lbl.set_xlim(0, 1); ax_lbl.set_ylim(0, 1); ax_lbl.axis("off")
            ax_lbl.add_patch(plt.Rectangle(
                (0, 0), 1, 1, facecolor=_strip_fill, edgecolor=_strip_edge,
                linewidth=1.2, transform=ax_lbl.transAxes))
            ax_lbl.text(0.012, 0.5,
                        f"{sensor_label}  \u2022  {pdata['date_range']}",
                        fontsize=8, fontweight="bold", va="center",
                        color=_strip_text, transform=ax_lbl.transAxes)
            n_h_s = sum(pdata["highs_by_day"])
            n_m_s = sum(pdata["meds_by_day"])
            ax_lbl.text(0.988, 0.5,
                        f"Critical: {n_h_s}   Elevated: {n_m_s}",
                        fontsize=7.5, va="center", ha="right",
                        color=_strip_text, transform=ax_lbl.transAxes)

            # Sensor label row — colored boxes per sensor, between stream label and bar chart
            # Use a fraction of the chart height for the sensor row
            SENSOR_ROW_H  = _SUM_STRIP_CHART * 0.22   # 22% of strip chart height
            SENSOR_ROW_FR = SENSOR_ROW_H / _SUM_PAGE_H
            bar_h_frac    = chart_h_frac - SENSOR_ROW_FR
            sensor_row_bot = chart_bot_frac + bar_h_frac

            ax_slbl = fig.add_axes([0.09, sensor_row_bot, 0.87, SENSOR_ROW_FR])
            ax_slbl.set_xlim(-0.5, PAGE_SIZE - 0.5)
            ax_slbl.set_ylim(0, 1)
            ax_slbl.axis("off")

            # Compute tier colors per sensor using global log-progressive scoring
            _s_tier_color = {}
            for _tx in pdata.get("tx_structure", []):
                for _s in _tx["sensors"]:
                    _d = max(1, _s["end_idx"] - _s["start_idx"] + 1)
                    _total_m = _d * 24 * 60
                    _crit_m  = sum(pdata.get("crit_min_by_day", [0]*PAGE_SIZE)
                                   [_s["start_idx"]:_s["end_idx"]+1])
                    _elev_m  = sum(pdata.get("elev_min_by_day", [0]*PAGE_SIZE)
                                   [_s["start_idx"]:_s["end_idx"]+1])
                    _ft = sensor_contamination_tier(_crit_m, _elev_m, _total_m)
                    _s_tier_color[_s["label"]] = (TIER_SOLID[_ft], TIER_TEXT[_ft])

            global_s_num = 0
            for idx, tx in enumerate(pdata.get("tx_structure", [])):
                for s_idx, s in enumerate(tx["sensors"]):
                    ss, se  = s["start_idx"], s["end_idx"]
                    s_span  = se - ss + 1
                    s_mid   = (ss + se) / 2
                    short   = f"S{global_s_num + s_idx + 1}"
                    solid, txt_col = _s_tier_color.get(s["label"], ("#888", "#fff"))
                    ax_slbl.add_patch(MplRect(
                        (ss - 0.5, 0.0), s_span, 1.0,
                        linewidth=0.8, edgecolor="#555",
                        facecolor=solid, alpha=1.0, clip_on=True, zorder=2))
                    if s_span >= 3:
                        ax_slbl.text(s_mid, 0.5, short, fontsize=7,
                                     fontweight="bold", ha="center", va="center",
                                     color=txt_col, clip_on=True)
                global_s_num += len(tx["sensors"])

            # Gradient color strip — per-day tier colors between sensor row and bar chart
            GRAD_H_FRAC = _SUM_STRIP_CHART * 0.10 / _SUM_PAGE_H
            grad_bot    = sensor_row_bot - GRAD_H_FRAC
            ax_grad = fig.add_axes([0.09, grad_bot, 0.87, GRAD_H_FRAC])
            ax_grad.set_xlim(-0.5, PAGE_SIZE - 0.5)
            ax_grad.set_ylim(0, 1)
            ax_grad.axis("off")
            _day_tiers_strip = [
                (lambda h, m: "purple" if h >= 2 else ("red" if h >= 1 else
                 ("yellow" if m >= 1 else "green")))(
                    pdata["highs_by_day"][i], pdata["meds_by_day"][i])
                if (pdata["highs_by_day"][i] + pdata["meds_by_day"][i]) > 0
                else (None if i >= _d_strip else "green")
                for i in range(PAGE_SIZE)
            ]
            import numpy as _np2
            _grad_rgba = [TIER_RGBA[t] if t else (1.0,1.0,1.0,0.0)
                          for t in _day_tiers_strip]
            _grad_img  = _np2.array(_grad_rgba, dtype=float).reshape(1, PAGE_SIZE, 4)
            ax_grad.imshow(_grad_img, aspect="auto",
                           extent=[-0.5, PAGE_SIZE-0.5, 0, 1],
                           interpolation="bilinear", zorder=2)

            # Adjust bar chart height to account for gradient strip
            bar_h_frac_adj = bar_h_frac - GRAD_H_FRAC

            # Mini bar chart
            _render_summary_bar_chart(fig, pdata,
                left=0.09, bottom=chart_bot_frac,
                width=0.87, height=bar_h_frac_adj)

            y += _SUM_STRIP_LABEL + _SUM_STRIP_CHART + _SUM_STRIP_GAP

        # ── Footer — same as dashboard ────────────────────────────────────────
        fig.text(0.06, 0.012, "CGM Sensor Integrity Detector v6",
                 fontsize=7.5, ha="left", va="bottom", color="#888", style="italic")
        fig.text(0.5, 0.012,
                 "danheller.substack.com/p/the-cgm-patent-that-could-save-lives",
                 fontsize=7.5, ha="center", va="bottom", color="#888", style="italic")
        fig.text(0.94, 0.012, f"Page {sum_pg+1} of {n_sum_pages}",
                 fontsize=11, ha="right", va="bottom", color="#000", fontweight="bold")

        plt.savefig(out_file, dpi=150, facecolor="#fafafa")
        plt.close()
        print(f"Saved: {out_file}")
        written.append(out_file)

    return written


def main():
    """CLI entry point — parse arguments and dispatch to the appropriate render path."""
    p = argparse.ArgumentParser(
        description="CGM Report Renderer v6 — produces daily reports and dashboards",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--clarity_csv",    metavar="FILE", nargs="+",
                     help="One or more Dexcom Clarity export CSVs (streams split by sensor ID)")
    src.add_argument("--g6g7_excel", metavar="FILE",
                     help="Paired G6/G7 Excel workbook — Dan Heller's 2023 study format (not a generic Excel file)")
    src.add_argument("--libre_csv",      metavar="FILE",
                     help="Abbott FreeStyle Libre 3 CSV export")
    src.add_argument("--androidaps_dir", metavar="DIR",
                     help="AndroidAPS Open Humans export folder (contains BgReadings.json)")
    src.add_argument("--sugarmate", metavar="FILE",
                     help="Sugarmate Excel report export (.xlsx)")
    src.add_argument("--tconnect_csv",   metavar="FILE", nargs="+",
                     help="One or more Tandem Source Daily Timeline CSV exports")
    p.add_argument("--sensor_type", choices=["G6", "G7", "both"], default="both",
                   help="Excel workbook: which stream(s) to render (default: both)")

    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--date",      metavar="YYYY-MM-DD",
                      help="Render a daily report for this date (single-stream CSVs only)")
    mode.add_argument("--dashboard", action="store_true",
                      help="Render full dashboards for all sensor streams")

    p.add_argument("--out",            metavar="FILE", default="output.png",
                   help="Output base path (default: output.png)")
    p.add_argument("--patient_name",   metavar="NAME", default="",
                   help="Patient name shown on report (Excel workbooks only; CSVs extract it automatically)")
    p.add_argument("--sensor_labels",  metavar="OVERRIDES", default="",
                   help="Override inferred sensor sessions. Format: 'S1:YYYY-MM-DD:YYYY-MM-DD,S2:...' "
                        "Use when gap-based detection produces wrong session boundaries.")
    p.add_argument("--hypo_threshold", type=float, default=70.0)
    p.add_argument("--window_hours",   type=float, default=3.0)
    p.add_argument("--min_confidence", choices=["low", "medium", "high"], default="medium")
    p.add_argument("--hide_smb",       action="store_true", default=False,
                   help="Hide SMB micro-bolus bars on daily charts (default: shown)")

    args = p.parse_args()
    base, ext = (args.out.rsplit(".", 1) if "." in args.out else (args.out, "png"))

    # ── Excel path (two named streams, no TX IDs required) ───────────────────
    if args.g6g7_excel:
        # Extract BGM readings from the dedicated BGM sheet (has real timestamps)
        try:
            _bgm_sheet = pd.read_excel(args.g6g7_excel, sheet_name="BGM")
            _bgm_sheet["dt"] = pd.to_datetime(
                _bgm_sheet["Date and"].astype(str) + " " + _bgm_sheet["Time"].astype(str),
                errors="coerce")
            _bgm_sheet["glucose"] = pd.to_numeric(_bgm_sheet["BGValue[mg/dL]"], errors="coerce")
            bgm_xl = _bgm_sheet.dropna(subset=["dt","glucose"])[["dt","glucose"]].sort_values("dt").reset_index(drop=True)
        except Exception:
            bgm_xl = pd.DataFrame()

        sensor_types = (["G6", "G7"] if args.sensor_type == "both"
                        else [args.sensor_type])
        if args.date:
            # Daily report — single stream only
            st = sensor_types[0]
            egv, units, label, carb_xl, bolus_xl = load_excel_workbook(args.g6g7_excel, st)
            if args.sensor_labels:
                egv = _apply_sensor_label_overrides(egv, args.sensor_labels)
            data = _build_daily_data(egv, units, args.date,
                                     sensor_type_label=label,
                                     patient_name=args.patient_name,
                                     bgm_df=bgm_xl,
                                     carb_df=carb_xl,
                                     bolus_df=bolus_xl,
                                     hypo_threshold=args.hypo_threshold,
                                     window_hours=args.window_hours,
                                     min_confidence=args.min_confidence)
            render_daily_report(data, args.out)
            return

        stream_results = []
        for st in sensor_types:
            egv, units, label, carb_xl, bolus_xl = load_excel_workbook(args.g6g7_excel, st)
            if args.sensor_labels:
                egv = _apply_sensor_label_overrides(egv, args.sensor_labels)
            d = _build_dashboard_data(egv, units, sensor_type_label=label,
                                      patient_name=args.patient_name,
                                      hypo_threshold=args.hypo_threshold,
                                      window_hours=args.window_hours,
                                      min_confidence=args.min_confidence)
            stream_results.append((f"{st} (Excel)", d))
            pgs = _data_pages(d)
            for pg in pgs:
                pdata = _paginate_dashboard_data(d, pg)
                sfx = f"_{st}_p{pg+1}" if len(pgs) > 1 else f"_{st}"
                render_dashboard(pdata, f"{base}{sfx}.{ext}")

        if len(stream_results) > 1:
            render_multi_sensor_summary(stream_results, f"{base}_summary.{ext}",
                                        units=units)
        elif stream_results:
            _, d = stream_results[0]
            if len(_data_pages(d)) > 1:
                render_dashboard_summary(d, f"{base}_summary.{ext}")
        return

    # ── AndroidAPS JSON path ──────────────────────────────────────────────────
    if args.androidaps_dir:
        import importlib.util as _ilu, os as _os
        _aaps_spec = _ilu.spec_from_file_location(
            "load_androidaps_json",
            _os.path.join(_os.path.dirname(__file__), "load_androidaps_json.py"))
        _aaps = _ilu.module_from_spec(_aaps_spec); _aaps_spec.loader.exec_module(_aaps)

        bg_path = _os.path.join(args.androidaps_dir, "BgReadings.json")
        tx_path = _os.path.join(args.androidaps_dir, "Treatments.json")
        donor_id = _os.path.basename(args.androidaps_dir.rstrip("/\\")) or "donor"
        patient_name = donor_id

        egv = _aaps.load_androidaps_bgreadings(bg_path, donor_id=donor_id)
        bolus_df = _aaps.load_androidaps_treatments(tx_path)
        units = "mg/dL"
        sensor_type_label = "AndroidAPS"
        bgm_all = pd.DataFrame()

        # Add dt_mono and sensor_label columns expected by downstream functions
        egv["dt_mono"] = egv["dt"]
        from cgm_render_report_v6 import _infer_sensor_labels
        egv = _infer_sensor_labels(egv, sensor_type_label=sensor_type_label)

        if args.date:
            data = _build_daily_data(egv, units, args.date,
                                     sensor_type_label=sensor_type_label,
                                     patient_name=patient_name,
                                     bgm_df=bgm_all,
                                     bolus_df=bolus_df,
                                     show_smb=not args.hide_smb,
                                     hypo_threshold=args.hypo_threshold,
                                     window_hours=args.window_hours,
                                     min_confidence=args.min_confidence)
            render_daily_report(data, args.out)
            return

        d = _build_dashboard_data(egv, units,
                                  sensor_type_label=sensor_type_label,
                                  patient_name=patient_name,
                                  hypo_threshold=args.hypo_threshold,
                                  window_hours=args.window_hours,
                                  min_confidence=args.min_confidence)
        pgs = _data_pages(d)
        for pg in pgs:
            pdata = _paginate_dashboard_data(d, pg)
            sfx = f"_p{pg+1}" if len(pgs) > 1 else ""
            render_dashboard(pdata, f"{base}{sfx}.{ext}")
        if len(_data_pages(d)) > 1:
            render_dashboard_summary(d, f"{base}_summary.{ext}")
        return

    # ── Libre CSV path ────────────────────────────────────────────────────────
    if args.libre_csv:
        egv, units, sensor_type_label, patient_name, bgm_all = load_libre_csv(args.libre_csv)
        streams = split_by_sensor(egv)
        try:
            streams, _ = validate_streams(streams, units)
        except ValueError as e:
            # Libre has no TX IDs enforced — treat entire dataset as one stream
            streams = {"Libre": egv}

        if args.date:
            import datetime as _dt
            req_date = _dt.date.fromisoformat(args.date)
            egv_s = None
            for egv_candidate in streams.values():
                if req_date in egv_candidate["dt"].dt.date.values:
                    egv_s = egv_candidate; break
            if egv_s is None:
                egv_s = egv
            data = _build_daily_data(egv_s, units, args.date,
                                     sensor_type_label=sensor_type_label,
                                     patient_name=patient_name,
                                     bgm_df=bgm_all,
                                     hypo_threshold=args.hypo_threshold,
                                     window_hours=args.window_hours,
                                     min_confidence=args.min_confidence)
            render_daily_report(data, args.out)
            return

        # Dashboard — split by sensor when sensors are separated by > 60 days.
        # Uses the same general large-gap logic as the Clarity CSV path.
        sensor_streams_sorted = sorted(
            streams.items(), key=lambda kv: kv[1]["dt"].min())
        large_gap = len(sensor_streams_sorted) > 1 and any(
            (sensor_streams_sorted[i][1]["dt"].min() -
             sensor_streams_sorted[i-1][1]["dt"].max()).days > 60
            for i in range(1, len(sensor_streams_sorted))
        )
        if large_gap:
            stream_results = []
            for tx_id, tx_egv in sensor_streams_sorted:
                short = tx_id[:8] if len(tx_id) > 8 else tx_id
                d_s = _build_dashboard_data(tx_egv, units,
                                            sensor_type_label=sensor_type_label,
                                            patient_name=patient_name,
                                            hypo_threshold=args.hypo_threshold,
                                            window_hours=args.window_hours,
                                            min_confidence=args.min_confidence)
                stream_results.append((f"{sensor_type_label} [{short}]", d_s))
                pgs = _data_pages(d_s)
                for pg in pgs:
                    pdata = _paginate_dashboard_data(d_s, pg)
                    sfx = f"_{short}_p{pg+1}" if len(pgs) > 1 else f"_{short}"
                    render_dashboard(pdata, f"{base}{sfx}.{ext}")
            render_multi_sensor_summary(stream_results,
                                        f"{base}_summary.{ext}", units=units)
        else:
            d = _build_dashboard_data(egv, units,
                                      sensor_type_label=sensor_type_label,
                                      patient_name=patient_name,
                                      hypo_threshold=args.hypo_threshold,
                                      window_hours=args.window_hours,
                                      min_confidence=args.min_confidence)
            pgs = _data_pages(d)
            for pg in pgs:
                pdata = _paginate_dashboard_data(d, pg)
                sfx = f"_p{pg+1}" if len(pgs) > 1 else ""
                render_dashboard(pdata, f"{base}{sfx}.{ext}")
            if len(_data_pages(d)) > 1:
                render_dashboard_summary(d, f"{base}_summary.{ext}")
        return

    # ── Sugarmate xlsx path ──────────────────────────────────────────────────
    if args.sugarmate:
        from load_sugarmate_xlsx import load_sugarmate_xlsx
        egv, units, sensor_type_label, patient_name, bgm_all, bolus_all = load_sugarmate_xlsx(args.sugarmate)
        egv['sensor_label']   = 'S1'
        egv['tx_id']          = 'Sugarmate'
        egv['transmitter_id'] = 'Sugarmate'
        if args.date:
            data = _build_daily_data(egv, units, args.date,
                                     sensor_type_label=sensor_type_label,
                                     patient_name=patient_name,
                                     bgm_df=bgm_all, bolus_df=bolus_all,
                                     hypo_threshold=args.hypo_threshold,
                                     window_hours=args.window_hours,
                                     min_confidence=args.min_confidence)
            render_daily_report(data, args.out)
            return
        d = _build_dashboard_data(egv, units,
                                  sensor_type_label=sensor_type_label,
                                  patient_name=patient_name,
                                  hypo_threshold=args.hypo_threshold,
                                  window_hours=args.window_hours,
                                  min_confidence=args.min_confidence)
        for pg in _data_pages(d):
            pdata = _paginate_dashboard_data(d, pg)
            sfx = f'_p{pg+1}' if len(_data_pages(d)) > 1 else ''
            render_dashboard(pdata, f'{base}{sfx}.{ext}')
        return

    # ── Tandem Source CSV path ────────────────────────────────────────────────
    if args.tconnect_csv:
        from load_tconnect_csv import load_tconnect_csv
        all_egv, all_bgm, all_bolus = [], [], []
        pump_algo = ''
        for path in args.tconnect_csv:
            egv_f, u_f, sl_f, pn_f, bgm_f, bol_f = load_tconnect_csv(path)
            if not pump_algo and 'Control-IQ' in sl_f: pump_algo = 'Control-IQ'
            all_egv.append(egv_f); all_bgm.append(bgm_f); all_bolus.append(bol_f)
        import pandas as _pd
        egv = _pd.concat(all_egv).drop_duplicates(subset=['dt']).sort_values('dt').reset_index(drop=True)
        bgm_all   = _pd.concat(all_bgm).drop_duplicates(subset=['dt']).sort_values('dt').reset_index(drop=True)
        bolus_all = _pd.concat(all_bolus).drop_duplicates(subset=['dt','insulin']).sort_values('dt').reset_index(drop=True)
        egv['sensor_label']   = 'S1'
        egv['tx_id']          = egv_f['tx_id'].iloc[0] if 'tx_id' in egv_f.columns else 'Unknown'
        egv['transmitter_id'] = egv['tx_id']
        _, _, sensor_type_label, patient_name, _, _ = load_tconnect_csv(args.tconnect_csv[0])
        sensor_type_label = 'Tandem t:slim X2'
        display_name = f'{patient_name}  •  {pump_algo}' if pump_algo else patient_name
        if args.date:
            data = _build_daily_data(egv, 'mg/dL', args.date,
                                     sensor_type_label=sensor_type_label,
                                     patient_name=display_name,
                                     bgm_df=bgm_all, bolus_df=bolus_all,
                                     hypo_threshold=args.hypo_threshold,
                                     window_hours=args.window_hours,
                                     min_confidence=args.min_confidence)
            render_daily_report(data, args.out)
            return
        d = _build_dashboard_data(egv, 'mg/dL',
                                  sensor_type_label=sensor_type_label,
                                  patient_name=display_name,
                                  hypo_threshold=args.hypo_threshold,
                                  window_hours=args.window_hours,
                                  min_confidence=args.min_confidence)
        for pg in _data_pages(d):
            pdata = _paginate_dashboard_data(d, pg)
            sfx = f'_p{pg+1}' if len(_data_pages(d)) > 1 else ''
            render_dashboard(pdata, f'{base}{sfx}.{ext}')
        return

    # ── Clarity CSV path (one or more files, split by sensor ID) ─────────────
    # Load all CSVs; if they represent different sensor types, treat as separate
    # streams for multi-sensor summary (like the Excel workbook path).
    all_frames, units_seen, label_seen, names_seen, bgm_frames = [], set(), set(), [], []
    per_file: list = []   # [(egv, units, label, name, bgm)] one per file
    for path in args.clarity_csv:
        egv_f, units_f, label_f, name_f, bgm_f = load_clarity_csv(path)
        all_frames.append(egv_f)
        bgm_frames.append(bgm_f)
        units_seen.add(units_f)
        label_seen.add(label_f)
        if name_f:
            names_seen.append(name_f)
        per_file.append((egv_f, units_f, label_f, name_f, bgm_f))

    if len(units_seen) > 1:
        print(f"WARNING: mixed units across files {units_seen} — using first.")
    units = next(iter(units_seen))
    sensor_type_label = " / ".join(sorted(label_seen))
    patient_name = names_seen[0] if names_seen else ""
    bgm_all = pd.concat(bgm_frames, ignore_index=True).sort_values("dt").reset_index(drop=True) if bgm_frames else pd.DataFrame()

    # If multiple CSVs with different sensor types AND dashboard mode → multi-sensor summary
    if args.dashboard and len(label_seen) > 1 and len(per_file) > 1:
        stream_results = []
        for egv_f, units_f, label_f, name_f, bgm_f in per_file:
            d_s = _build_dashboard_data(egv_f, units_f,
                                        sensor_type_label=label_f,
                                        patient_name=name_f or patient_name,
                                        hypo_threshold=args.hypo_threshold,
                                        window_hours=args.window_hours,
                                        min_confidence=args.min_confidence)
            stream_results.append((label_f, d_s))
            pgs = _data_pages(d_s)
            for pg in pgs:
                pdata = _paginate_dashboard_data(d_s, pg)
                # Derive a short suffix from sensor type label (e.g. "Dexcom G7" → "G7")
                short = label_f.replace("Dexcom ", "").replace(" ", "_")
                sfx = f"_{short}_p{pg+1}" if len(pgs) > 1 else f"_{short}"
                render_dashboard(pdata, f"{base}{sfx}.{ext}")
        render_multi_sensor_summary(stream_results, f"{base}_summary.{ext}", units=units)
        return

    egv_all = (pd.concat(all_frames, ignore_index=True)
               .sort_values("dt").reset_index(drop=True))

    # Split by sensor ID and enforce no-ID policy
    streams = split_by_sensor(egv_all)
    try:
        streams, unidentified_count = validate_streams(streams, units)
    except ValueError as e:
        print(f"ERROR: {e}")
        raise SystemExit(1)

    multi = len(streams) > 1

    # Auto-load matching Treatments CSV if present alongside the BgReadings CSV
    # (OpenAPS merged exports produce *_BgReadings.csv and *_Treatments.csv together)
    bolus_all = pd.DataFrame()
    if len(args.clarity_csv) == 1:
        import os as _os
        bg_path = args.clarity_csv[0]
        tx_path = bg_path.replace("_BgReadings.csv", "_Treatments.csv")
        if tx_path != bg_path and _os.path.exists(tx_path):
            try:
                _tx = pd.read_csv(tx_path)
                if "Timestamp" in _tx.columns:
                    _tx["dt"] = pd.to_datetime(_tx["Timestamp"], errors="coerce")
                    _tx["insulin"] = pd.to_numeric(_tx.get("Insulin (U)", 0), errors="coerce").fillna(0)
                    _tx["is_smb"]  = _tx.get("Is SMB",  False).astype(bool)
                    _tx["is_meal"] = _tx.get("Is Meal Bolus", False).astype(bool)
                    bolus_all = _tx.dropna(subset=["dt"])[["dt","insulin","is_smb","is_meal"]]
            except Exception as _e:
                print(f"Note: could not load Treatments CSV: {_e}")

    if args.date:
        # Find whichever stream contains the requested date
        import datetime as _dt
        req_date = _dt.date.fromisoformat(args.date)
        egv_s, tx_id = None, None
        for tid, egv_candidate in streams.items():
            if req_date in egv_candidate["dt"].dt.date.values:
                egv_s, tx_id = egv_candidate, tid
                break
        if egv_s is None:
            # Fall back to full dataset (handles multi-TX days)
            egv_s, tx_id = egv_all, "all"
        data = _build_daily_data(egv_s, units, args.date,
                                 sensor_type_label=sensor_type_label,
                                 patient_name=patient_name,
                                 bgm_df=bgm_all,
                                 bolus_df=bolus_all if not bolus_all.empty else None,
                                 show_smb=not args.hide_smb,
                                 hypo_threshold=args.hypo_threshold,
                                 window_hours=args.window_hours,
                                 min_confidence=args.min_confidence)
        render_daily_report(data, args.out)
        return

    # Dashboard — one chart for the entire dataset, all transmitters within it.
    # Exception: if transmitters are separated by > 60 days, render each as its
    # own dashboard and produce a multi-sensor summary — same as the Libre path.
    # This applies to any data source (Clarity, Libre, Nightscout) that spans
    # disconnected sensor sessions in a single export.
    sensor_streams_sorted = sorted(
        streams.items(), key=lambda kv: kv[1]["dt"].min())
    large_gap = any(
        (sensor_streams_sorted[i][1]["dt"].min() -
         sensor_streams_sorted[i-1][1]["dt"].max()).days > 60
        for i in range(1, len(sensor_streams_sorted))
    )

    if large_gap and len(sensor_streams_sorted) > 1:
        stream_results = []
        for tx_id, tx_egv in sensor_streams_sorted:
            short = tx_id[:8] if len(tx_id) > 8 else tx_id
            d_s = _build_dashboard_data(tx_egv, units,
                                        sensor_type_label=sensor_type_label,
                                        patient_name=patient_name,
                                        hypo_threshold=args.hypo_threshold,
                                        window_hours=args.window_hours,
                                        min_confidence=args.min_confidence)
            stream_results.append((f"{sensor_type_label} [{short}]", d_s))
            pgs = _data_pages(d_s)
            for pg in pgs:
                pdata = _paginate_dashboard_data(d_s, pg)
                sfx = f"_{short}_p{pg+1}" if len(pgs) > 1 else f"_{short}"
                render_dashboard(pdata, f"{base}{sfx}.{ext}")
        render_multi_sensor_summary(stream_results,
                                    f"{base}_summary.{ext}", units=units)
    else:
        d = _build_dashboard_data(egv_all, units,
                                  sensor_type_label=sensor_type_label,
                                  patient_name=patient_name,
                                  hypo_threshold=args.hypo_threshold,
                                  window_hours=args.window_hours,
                                  min_confidence=args.min_confidence)
        pgs = _data_pages(d)
        for pg in pgs:
            pdata = _paginate_dashboard_data(d, pg)
            sfx = f"_p{pg+1}" if len(pgs) > 1 else ""
            render_dashboard(pdata, f"{base}{sfx}.{ext}")
        if len(_data_pages(d)) > 1:
            render_dashboard_summary(d, f"{base}_summary.{ext}")


if __name__ == "__main__":
    main()
